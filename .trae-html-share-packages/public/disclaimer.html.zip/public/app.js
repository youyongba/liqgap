'use strict';

/**
 * Liquidity Gap 仪表盘 · 前端控制器
 * (Liquidity Gap dashboard - frontend controller)
 *
 * 职责 (Responsibilities)：
 *   - 每 10 秒轮询后端 /api 接口 (poll /api endpoints every 10s, configurable)
 *   - 在主图绘制 K 线 + VWAP + FVG + 流动性空白
 *     (render main candlestick chart with VWAP, FVG, liquidity voids)
 *   - 副图：成交量直方图 + CVD 累积曲线
 *     (sub charts: volume histogram + CVD line)
 *   - Chart.js 水平条形图绘制订单簿深度
 *     (order book Chart.js horizontal bar chart)
 *   - 右侧信号面板 + 流动性预警
 *     (signal panel + alerts)
 */

(function () {
  let lastCandles = [];
  const els = {
    symbol: document.getElementById('symbol'),
    market: document.getElementById('market'),
    interval: document.getElementById('interval'),
    refresh: document.getElementById('refresh'),
    status: document.getElementById('status'),
    mainChart: document.getElementById('main-chart'),
    volumePane: document.getElementById('volume-pane'),
    cvdPane: document.getElementById('cvd-pane'),
    // 同一副图模块内上下拆分：oi-pane 在上（持仓量），cvd-pane 在下（CVD）
    oiPane: document.getElementById('oi-pane'),
    orderbookCanvas: document.getElementById('orderbook-chart'),
    mainMeta: document.getElementById('main-meta'),
    volTitle: document.getElementById('vol-title'),
    cvdTitle: document.getElementById('cvd-title'),
    oiTitle: document.getElementById('oi-title'),
    obTitle: document.getElementById('ob-title'),
    obBaseline: document.getElementById('ob-baseline'),
    obBaselineInfo: document.getElementById('ob-baseline-info'),
    heatmapCanvas: document.getElementById('heatmap-canvas'),
    heatmapTooltip: document.getElementById('heatmap-tooltip'),
    heatmapEmpty: document.getElementById('heatmap-empty'),
    heatmapMeta: document.getElementById('heatmap-meta'),
    heatmapWindow: document.getElementById('heatmap-window'),
    heatmapKlineInterval: document.getElementById('heatmap-kline-interval'),
    heatmapRange: document.getElementById('heatmap-range'),
    liqHeatmapCanvas: document.getElementById('liq-heatmap-canvas'),
    liqHeatmapTooltip: document.getElementById('liq-heatmap-tooltip'),
    liqHeatmapEmpty: document.getElementById('liq-heatmap-empty'),
    liqHeatmapMeta: document.getElementById('liq-heatmap-meta'),
    liqHeatmapWindow: document.getElementById('liq-heatmap-window'),
    liqHeatmapRange: document.getElementById('liq-heatmap-range'),
    liqHeatmapThreshold: document.getElementById('liq-heatmap-threshold'),
    liqHeatmapThresholdVal: document.getElementById('liq-heatmap-threshold-val'),
    liqHeatmapMeasure: document.getElementById('liq-heatmap-measure'),
    liqHeatmapAlert: document.getElementById('liq-heatmap-alert'),
    subCard: document.getElementById('sub-card'),
    mainCard: document.getElementById('main-card'),
    fitContentBtn: document.getElementById('fit-content-btn')
  };

  // ============================================================
  // 图表 loading 遮罩 (Per-chart loading overlay)
  // 切换周期 / 时间窗时盖住对应图表，等该图表的新数据渲染完成后各自揭开。
  // 兜底：请求失败时 20s 后自动隐藏，避免永远转圈。
  // ============================================================
  const _chartLoadings = new Map(); // host 元素 → overlay 节点
  const CHART_LOADING_MAX_MS = 20_000;
  function showChartLoading(host, text) {
    if (!host) return;
    let ov = _chartLoadings.get(host);
    if (!ov) {
      ov = document.createElement('div');
      ov.className = 'chart-loading';
      ov.innerHTML = '<div class="spinner"></div><div class="txt"></div>';
      try {
        // overlay 用 absolute 定位，宿主必须是定位上下文
        if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
      } catch (_) { /* noop */ }
      host.appendChild(ov);
      _chartLoadings.set(host, ov);
    }
    ov.querySelector('.txt').textContent = text || '加载中… / Loading…';
    ov.classList.add('on');
    clearTimeout(ov._hideTimer);
    ov._hideTimer = setTimeout(() => ov.classList.remove('on'), CHART_LOADING_MAX_MS);
  }
  function hideChartLoading(host) {
    const ov = host && _chartLoadings.get(host);
    if (!ov) return;
    clearTimeout(ov._hideTimer);
    ov.classList.remove('on');
  }
  // 主图周期（顶部 interval 下拉）影响的全部图表一起盖 loading
  function showIntervalLoading() {
    showChartLoading(els.mainChart);
    showChartLoading(els.volumePane);
    showChartLoading(els.oiPane);
    showChartLoading(els.cvdPane);
    if (els.orderbookCanvas) showChartLoading(els.orderbookCanvas.parentElement);
  }

  // ============================================================
  // 全局警报模块（"清算热图"卡）
  // - 一个 alertEnabled 开关 + 一个 localStorage key，所有按钮联动
  // - 价格穿越主峰 = 清算热图 _checkCross() 触发（声音 + 后端飞书 cross 卡）
  // - 同一来源 5 分钟内只响 1 次，避免吵
  // ============================================================
  const GLOBAL_ALERT_LS_KEY = 'liq-heatmap-alert-enabled';
  // 默认 ON（用户多次表达需求；首次访问就能听到声音验证设置正确）
  let _globalAlertEnabled;
  try {
    const raw = localStorage.getItem(GLOBAL_ALERT_LS_KEY);
    _globalAlertEnabled = raw == null ? true : raw === '1';
  } catch (_) { _globalAlertEnabled = true; }
  let _globalAudioCtx = null;
  function ensureAudioCtx() {
    if (_globalAudioCtx) return _globalAudioCtx;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (Ctx) _globalAudioCtx = new Ctx();
    } catch (_) { /* noop */ }
    return _globalAudioCtx;
  }
  // 6 个 0.18s "嘟"，频率 880↔1320 Hz 交替，模拟电子警报（cross 事件）
  function playAlertSound() {
    const ctx2 = ensureAudioCtx();
    if (!ctx2) return;
    try { if (ctx2.state === 'suspended') ctx2.resume(); } catch (_) {}
    const now = ctx2.currentTime;
    for (let i = 0; i < 6; i += 1) {
      const t0 = now + i * 0.28;
      const t1 = t0 + 0.18;
      const osc = ctx2.createOscillator();
      const gain = ctx2.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(i % 2 === 0 ? 880 : 1320, t0);
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(0.85, t0 + 0.01);
      gain.gain.setValueAtTime(0.85, t1 - 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t1);
      osc.connect(gain).connect(ctx2.destination);
      osc.start(t0);
      osc.stop(t1 + 0.02);
    }
  }
  // Reclaim (sweep + 收回) 音效：3 段渐强的三角波 660 → 990 → 1320 Hz
  // 听感与 cross 警报明显不同：温和但有"上升解决感"，提示反转 setup 而非破位事件
  function playReclaimSound() {
    const ctx2 = ensureAudioCtx();
    if (!ctx2) return;
    try { if (ctx2.state === 'suspended') ctx2.resume(); } catch (_) {}
    const now = ctx2.currentTime;
    const notes = [
      { f: 660,  start: 0.00, dur: 0.22 },
      { f: 990,  start: 0.18, dur: 0.22 },
      { f: 1320, start: 0.36, dur: 0.32 }
    ];
    for (const n of notes) {
      const t0 = now + n.start;
      const t1 = t0 + n.dur;
      const osc = ctx2.createOscillator();
      const gain = ctx2.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n.f, t0);
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(0.7, t0 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t1);
      osc.connect(gain).connect(ctx2.destination);
      osc.start(t0);
      osc.stop(t1 + 0.02);
    }
  }
  const _alertButtons = new Set();
  function _renderAlertButton(btn) {
    btn.classList.toggle('active', _globalAlertEnabled);
    btn.textContent = _globalAlertEnabled ? '🔔 警报 / Alert: ON' : '🔔 警报 / Alert: OFF';
  }
  function isAlertEnabled() { return _globalAlertEnabled; }
  function setAlertEnabled(on) {
    _globalAlertEnabled = !!on;
    try { localStorage.setItem(GLOBAL_ALERT_LS_KEY, _globalAlertEnabled ? '1' : '0'); } catch (_) {}
    _alertButtons.forEach(_renderAlertButton);
    if (_globalAlertEnabled) {
      // unlock audio context on user interaction
      const ctx2 = ensureAudioCtx();
      if (ctx2 && ctx2.state === 'suspended') {
        try { ctx2.resume(); } catch (_) {}
      }
    }
  }
  function registerAlertButton(btn) {
    if (!btn || _alertButtons.has(btn)) return;
    _alertButtons.add(btn);
    _renderAlertButton(btn);
    btn.addEventListener('click', () => setAlertEnabled(!_globalAlertEnabled));
  }

  // 交易信号窗口闸门逻辑已随信号面板移除；三阶窗口闸门（FULL / NOTIFY / 屏蔽）
  // 仍由后端 routes/liqSignal.js + routes/resonanceSignal.js 用 .env 变量控制，
  // 信号轮询由 services/signalPoller.js 在服务端定时执行。

  // 当前周期下两个副图的取数策略
  // (Per-interval policy for sub-chart data fetching.)
  //   - CVD 是从 K 线 takerBuyBase 派生，直接跟主图同步，所以这里的"interval"
  //     就是用户在 header 里选的那个；
  //   - 订单簿是即时快照，但不同周期下展示的档位深度不同（短周期看贴盘细盘、
  //     长周期看更深的盘口墙），由 depth 决定。后端会自动把 depth 对齐到
  //     Binance 允许的合法档位 (5/10/20/50/100/500/1000) 再切片返回。
  const INTERVAL_OB_DEPTH = { '15m': 20, '1h': 50, '4h': 100, '1d': 200 };
  function obDepthForInterval(interval) {
    return INTERVAL_OB_DEPTH[interval] || 50;
  }
  function intervalLabel(interval) {
    return ({ '1s': '1 秒', '15m': '15 分钟', '1h': '1 小时', '4h': '4 小时', '1d': '1 天' }[interval]) || interval;
  }

  // Binance OI hist 仅支持 5m/15m/30m/1h/2h/4h/6h/12h/1d，其余 fallback 5m
  // (Mirror of backend mapping; used only for the title hint.)
  const OI_SUPPORTED = new Set(['5m', '15m', '30m', '1h', '2h', '4h', '6h', '12h', '1d']);
  function effectiveOiPeriod(interval) {
    return OI_SUPPORTED.has(interval) ? interval : '5m';
  }

  function refreshSubTitles() {
    const itv = els.interval.value;
    const itvLab = intervalLabel(itv);
    const market = els.market ? els.market.value : 'futures';
    if (els.volTitle) els.volTitle.textContent = `成交量 / Volume · ${itvLab}`;
    // 持仓量(上) + CVD(下) 上下拆分图：标题保持简洁，各档位由头部按钮自身文案体现
    if (els.cvdTitle) els.cvdTitle.textContent = `持仓量(上) + CVD(下) · ${itvLab}`;
    if (els.obTitle)  els.obTitle.textContent  = `订单簿深度图 / Order Book Depth · 前 ${obDepthForInterval(itv)} 档`;
    if (els.oiTitle) {
      if (market !== 'futures') {
        els.oiTitle.textContent = '持仓量 / Open Interest（仅合约 · 现货无此数据）';
      } else {
        const oiP = effectiveOiPeriod(itv);
        const note = oiP === itv ? '' : `（接口最小 5m，已聚合）`;
        els.oiTitle.textContent = `持仓量 / Open Interest · ${intervalLabel(oiP)}${note}`;
      }
    }
  }

  const POLL_INTERVAL_MS = 10000;
  // 主图初始 K 线根数（更早历史通过向左拖拽动态加载，见 histState）。
  const KLINE_LIMIT = 200;
  // 每次向左拖拽翻页加载的历史根数
  const HIST_CHUNK = 200;
  // 历史缓冲上限（约 25 页），防止无限拖拽内存膨胀
  const HIST_MAX_BARS = 5000;
  // 副图 OI / CVD 单次拉取根数（OI 币安接口上限 500，无翻页历史）
  const SUBCHART_LIMIT = 500;
  let pollTimer = null;

  // ===== 东八区时间统一格式化 (Beijing-time formatters · UTC+8) =====
  // 项目要求所有时间显示采用东八区，避免不同终端时区导致解读不一致。
  // (Project mandates Beijing time everywhere to keep readings consistent
  //  regardless of the viewer's local timezone.)
  const BJ_OFFSET_MS = 8 * 60 * 60 * 1000;
  function _bjShift(ms) { return new Date(Number(ms) + BJ_OFFSET_MS); }
  function _pad2(n) { return String(n).padStart(2, '0'); }
  function fmtBJDateTime(ms) {
    if (ms == null || !Number.isFinite(Number(ms))) return '-';
    const d = _bjShift(ms);
    return `${d.getUTCFullYear()}-${_pad2(d.getUTCMonth() + 1)}-${_pad2(d.getUTCDate())} ` +
           `${_pad2(d.getUTCHours())}:${_pad2(d.getUTCMinutes())}`;
  }
  function fmtBJShortDateTime(ms) {
    if (ms == null || !Number.isFinite(Number(ms))) return '-';
    const d = _bjShift(ms);
    return `${_pad2(d.getUTCMonth() + 1)}/${_pad2(d.getUTCDate())} ` +
           `${_pad2(d.getUTCHours())}:${_pad2(d.getUTCMinutes())}`;
  }
  function fmtBJDate(ms) {
    if (ms == null || !Number.isFinite(Number(ms))) return '-';
    const d = _bjShift(ms);
    return `${_pad2(d.getUTCMonth() + 1)}/${_pad2(d.getUTCDate())}`;
  }
  function fmtBJTimeHMS(ms) {
    if (ms == null || !Number.isFinite(Number(ms))) return '-';
    const d = _bjShift(ms);
    return `${_pad2(d.getUTCHours())}:${_pad2(d.getUTCMinutes())}:${_pad2(d.getUTCSeconds())}`;
  }
  // 给状态栏/小时间戳用：HH:mm:ss (BJ)
  function nowBJTimeHMS() { return fmtBJTimeHMS(Date.now()); }

  // 星期几（东八区），用于时间轴日期刻度和十字线浮窗
  const _WEEKDAYS_CN = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  function bjWeekday(ms) { return _WEEKDAYS_CN[_bjShift(ms).getUTCDay()]; }

  // lightweight-charts 时间轴 tick 格式化：
  // tickMarkType 枚举 0=Year, 1=Month, 2=DayOfMonth, 3=Time, 4=TimeWithSeconds
  // 日期级刻度（跨日边界）带星期几；小时/分钟刻度保持简短不加。
  function lwTickFormatter(timeSec, tickMarkType) {
    const ms = Number(timeSec) * 1000;
    const d = _bjShift(ms);
    switch (Number(tickMarkType)) {
      case 0: return String(d.getUTCFullYear());
      case 1: return `${d.getUTCFullYear()}-${_pad2(d.getUTCMonth() + 1)}`;
      case 2: return `${_pad2(d.getUTCMonth() + 1)}-${_pad2(d.getUTCDate())} ${bjWeekday(ms)}`;
      case 3: return `${_pad2(d.getUTCHours())}:${_pad2(d.getUTCMinutes())}`;
      case 4:
      default:
        return `${_pad2(d.getUTCHours())}:${_pad2(d.getUTCMinutes())}:${_pad2(d.getUTCSeconds())}`;
    }
  }
  // crosshair 浮窗里的时间 (整段 datetime + 星期几)
  const lwLocalization = {
    timeFormatter: (timeSec) => {
      const ms = Number(timeSec) * 1000;
      return `${fmtBJDateTime(ms)} ${bjWeekday(ms)}`;
    },
    dateFormat: 'yyyy-MM-dd'
  };

  // ---- 主图 K 线 (Main candlestick chart · Lightweight Charts) ----
  const mainChart = LightweightCharts.createChart(els.mainChart, {
    layout: {
      background: { color: 'transparent' },
      textColor: '#9aa7b8'
    },
    grid: {
      vertLines: { color: '#1f2837' },
      horzLines: { color: '#1f2837' }
    },
    crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
    rightPriceScale: { borderColor: '#1f2837' },
    timeScale: {
      borderColor: '#1f2837',
      timeVisible: true,
      secondsVisible: false,
      tickMarkFormatter: lwTickFormatter
    },
    localization: lwLocalization
  });
  const candleSeries = mainChart.addCandlestickSeries({
    upColor: '#4ade80',
    downColor: '#f87171',
    borderUpColor: '#4ade80',
    borderDownColor: '#f87171',
    wickUpColor: '#4ade80',
    wickDownColor: '#f87171'
  });
  const vwapSeries = mainChart.addLineSeries({
    color: '#facc15',
    lineWidth: 2,
    title: 'VWAP'
  });

  // ---- 副图：成交量 (Volume chart · separate Lightweight Charts instance) ----
  const volumeChart = LightweightCharts.createChart(els.volumePane, {
    layout: { background: { color: 'transparent' }, textColor: '#9aa7b8' },
    grid: {
      vertLines: { color: '#1f2837' },
      horzLines: { color: '#1f2837' }
    },
    timeScale: {
      timeVisible: true,
      secondsVisible: false,
      borderColor: '#1f2837',
      tickMarkFormatter: lwTickFormatter
    },
    rightPriceScale: { borderColor: '#1f2837' },
    localization: lwLocalization
  });
  const volumeSeries = volumeChart.addHistogramSeries({
    color: '#60a5fa',
    priceFormat: { type: 'volume' }
  });
  const volumeMASeries = volumeChart.addLineSeries({
    color: 'rgba(250, 204, 21, 0.8)', // 黄色均线
    lineWidth: 1.5,
    crosshairMarkerVisible: false,
    priceLineVisible: false,
    lastValueVisible: false
  });

  // ---- 副图：持仓量(上) + CVD(下) 上下拆分 (Stacked OI-over-CVD charts) ----
  // 同一个副图模块内两张图上下排列：上 = 持仓量 OI（隐藏时间轴省空间），
  // 下 = CVD（显示时间轴）。两图时间轴 / 十字线联动，配合判断资金方向：
  //   OI ↑ + CVD ↓ → 新空单进场 (short build-up)
  //   OI ↑ + CVD ↑ → 新多单进场 (long build-up)
  //   OI ↓ + CVD ↑ → 空头平仓 (short covering)
  //   OI ↓ + CVD ↓ → 多头平仓 (long unwind)
  const cvdChart = LightweightCharts.createChart(els.cvdPane, {
    layout: { background: { color: 'transparent' }, textColor: '#9aa7b8' },
    grid: {
      vertLines: { color: '#1f2837' },
      horzLines: { color: '#1f2837' }
    },
    timeScale: {
      timeVisible: true,
      secondsVisible: false,
      borderColor: '#1f2837',
      tickMarkFormatter: lwTickFormatter
    },
    rightPriceScale: { borderColor: '#1f2837' },
    localization: lwLocalization
  });
  // CVD 纵轴 / 十字线数值格式化：带符号的紧凑缩写（K/M/B），避免出现
  // -2,611,409,630.31 这种又长又难读的整额。负值也正确缩写。
  // (Signed compact formatter so the CVD axis reads -2.61B instead of a
  //  full 13-digit number; handles negatives which the built-in 'volume'
  //  formatter does not.)
  function _cvdCompact(n) {
    if (!Number.isFinite(n)) return '';
    const sign = n < 0 ? '-' : '';
    const abs = Math.abs(n);
    if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(2)}B`;
    if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(2)}M`;
    if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(2)}K`;
    if (abs >= 1) return `${sign}${abs.toFixed(2)}`;
    return `${sign}${abs.toFixed(4)}`;
  }
  const cvdSeries = cvdChart.addLineSeries({
    color: '#4ade80',
    lineWidth: 2,
    priceFormat: { type: 'custom', formatter: _cvdCompact, minMove: 0.01 }
  });

  // ---- 持仓量 OI：上方独立图 ----
  // 时间轴隐藏（visible:false），由下方 CVD 图统一显示时间标签；
  // 隐藏的时间轴仍参与 allTimeScales 联动（setVisibleRange 照常生效）。
  const oiChart = LightweightCharts.createChart(els.oiPane, {
    layout: { background: { color: 'transparent' }, textColor: '#9aa7b8' },
    grid: {
      vertLines: { color: '#1f2837' },
      horzLines: { color: '#1f2837' }
    },
    timeScale: {
      visible: false,
      timeVisible: true,
      secondsVisible: false,
      borderColor: '#1f2837',
      tickMarkFormatter: lwTickFormatter
    },
    rightPriceScale: { borderColor: '#1f2837' },
    localization: lwLocalization
  });
  // 半透明面积线，颜色与 CVD 区分（橙色），强调"持仓量"金额维度
  const oiSeries = oiChart.addAreaSeries({
    lineColor: '#fbbf24',
    topColor: 'rgba(251, 191, 36, 0.35)',
    bottomColor: 'rgba(251, 191, 36, 0.02)',
    lineWidth: 2,
    priceFormat: { type: 'volume' }
  });
  // 持仓量 K 线：用相邻周期合成 OHLC（open=上一周期 OI，close=本周期 OI）
  //   close ≥ open → 绿（增仓）；close < open → 红（减仓）
  // 与面积图共用同一价格刻度（右轴），通过 visible 切换显示，默认显示 K 线。
  const oiCandleSeries = oiChart.addCandlestickSeries({
    upColor: '#22c55e',
    downColor: '#ef4444',
    borderUpColor: '#22c55e',
    borderDownColor: '#ef4444',
    wickUpColor: '#22c55e',
    wickDownColor: '#ef4444',
    priceFormat: { type: 'volume' }
  });
  oiSeries.applyOptions({ visible: false }); // 默认 K 线模式，面积图隐藏

  // 窗口尺寸变化重排 (Resize handlers) -------------------------------------
  function fitCharts() {
    _safeResize(mainChart, els.mainChart.clientWidth, els.mainChart.clientHeight);
    _safeResize(volumeChart, els.volumePane.clientWidth, els.volumePane.clientHeight);
    _safeResize(cvdChart, els.cvdPane.clientWidth, els.cvdPane.clientHeight);
    _safeResize(oiChart, els.oiPane.clientWidth, els.oiPane.clientHeight);
  }
  window.addEventListener('resize', fitCharts);

  // ---- 主动 ResizeObserver：根本性解决 sub-pane 全屏/退出 chart 不重排 ----
  // 关键修复：lightweight-charts 不自带容器监听；Chart.js 自带的 ResizeObserver
  // 是 throttled，sub-pane 全屏 ↔ 退出过程中可能漏一次。我们显式监控每个 chart
  // 父容器尺寸变化 → 立刻 resize 对应 chart，且 Chart.js 显式带 width/height
  // 强制更新 canvas 像素缓冲区。配合 rAF 防 reentry 循环。
  // 同时也覆盖窗口缩放、grid 响应式断点切换等其他场景。
  function _attachChartResizeObserver(el, onResize) {
    if (!el || typeof ResizeObserver !== 'function') return null;
    let pending = false;
    const ro = new ResizeObserver(() => {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => {
        pending = false;
        try { onResize(); } catch (_) { /* noop */ }
      });
    });
    ro.observe(el);
    return ro;
  }
  // 防御：grid 重排 race 中可能瞬时拿到 0 宽/高，给 chart resize(0,0) 会让
  // 内部 state 记录为 0 → 下次再 resize 到正常值前会渲染异常 / canvas
  // attribute 残留旧值进而把 grid 列撑大。低于 8px 直接跳过本次。
  const chartSizes = new WeakMap();
  function _safeResize(chart, w, h) {
    const previous = chartSizes.get(chart);
    if (w >= 8 && h >= 8 && (!previous || previous.w !== w || previous.h !== h)) {
      chartSizes.set(chart, { w, h });
      chart.resize(w, h);
    }
  }
  _attachChartResizeObserver(els.mainChart,  () => _safeResize(mainChart,  els.mainChart.clientWidth,   els.mainChart.clientHeight));
  _attachChartResizeObserver(els.volumePane, () => _safeResize(volumeChart, els.volumePane.clientWidth, els.volumePane.clientHeight));
  _attachChartResizeObserver(els.cvdPane,    () => _safeResize(cvdChart,    els.cvdPane.clientWidth,    els.cvdPane.clientHeight));
  _attachChartResizeObserver(els.oiPane,     () => _safeResize(oiChart,     els.oiPane.clientWidth,     els.oiPane.clientHeight));
  // Chart.js orderbook：监控 canvas 父元素 (.pane-body)，显式带 w/h resize
  // 否则 Chart.js 内部 ResizeObserver 偶尔漏更新会导致 canvas 像素缓冲区
  // 与 CSS 显示尺寸不一致 → 全屏退出后 chart 内容只画在右上角 / 缩在一角。
  if (els.orderbookCanvas) {
    const obParent = els.orderbookCanvas.parentElement;
    _attachChartResizeObserver(obParent, () => {
      if (!orderbookChart) return;
      const w = obParent.clientWidth;
      const h = obParent.clientHeight;
      if (w >= 8 && h >= 8) orderbookChart.resize(w, h);
    });
  }

  // ---- 时间轴联动 (Time-scale sync across main + sub charts) ----
  // 主图拖动 / 缩放 → 三个副图跟随，副图数据变化不反向修改主图。
  // (Keep volume / CVD / OI panes locked to the same visible range as the
  //  main chart so reading three indicators side-by-side is intuitive.)
  //
  // 实现要点：
  //   1) 用 *时间范围* (visible time range) 而非 logical range 同步。
  //      logical range 是各图自己的 bar 索引；副图 bar 数和主图不一定一致
  //      （OI 5m/1h fallback、空数据等场景），用 logical 会错位。
  //      time range 用 UTC 秒，跨图通用。
  //   2) 用 `_syncingTime` 防止 A → B → A 的回环触发。
  //   3) 空数据图（如现货模式下 OI 没数据）setVisibleRange 会抛 / no-op，
  //      用 try/catch 吞掉。
  const allTimeScales = [
    mainChart.timeScale(),
    volumeChart.timeScale(),
    cvdChart.timeScale(),
    oiChart.timeScale()  // 时间轴隐藏但仍参与联动
  ];
  let _syncingTime = false;
  let _timeSyncFrame = null;
  function _broadcastTimeRange(srcScale, range) {
    // Data changes in a shorter subchart must never change the main viewport.
    if (srcScale !== mainChart.timeScale()) return;
    if (_syncingTime || !range || range.from == null || range.to == null) return;
    _syncingTime = true;
    try {
      for (const ts of allTimeScales) {
        if (ts === srcScale) continue;
        try { ts.setVisibleRange({ from: range.from, to: range.to }); }
        catch (_) { /* 该图为空 / 范围不在数据内 */ }
      }
    } finally {
      // 关键：lightweight-charts 4.x 的 visibleTimeRangeChange 回调是
      // 下一帧异步触发。如果立刻 reset _syncingTime=false，副图的反向回调
      // 跑到时锁已开 → 反向 broadcast 回主图 → setVisibleRange 修改主图
      // width → 视觉上"拖动时横向放大"。延迟到下一帧 reset 阻断该回环。
      if (_timeSyncFrame) cancelAnimationFrame(_timeSyncFrame);
      _timeSyncFrame = requestAnimationFrame(() => { _syncingTime = false; _timeSyncFrame = null; });
    }
  }
  for (const ts of allTimeScales) {
    ts.subscribeVisibleTimeRangeChange((r) => _broadcastTimeRange(ts, r));
  }

  /**
   * 主动把所有副图拉到主图当前的可见范围。
   * 用于副图 setData 之后（新数据可能让副图自身的"自然范围"改变），
   * 以及渲染流程末尾兜底，避免副图任何隐式 fit 把主图 zoom 也带跑。
   */
  function syncSubChartsToMain() {
    const range = mainChart.timeScale().getVisibleRange();
    if (!range) return;
    _syncingTime = true;
    try {
      for (const ts of [volumeChart.timeScale(), cvdChart.timeScale(), oiChart.timeScale()]) {
        try { ts.setVisibleRange(range); } catch (_) { /* empty data */ }
      }
    } finally {
      if (_timeSyncFrame) cancelAnimationFrame(_timeSyncFrame);
      _timeSyncFrame = requestAnimationFrame(() => { _syncingTime = false; _timeSyncFrame = null; });
    }
  }

  // ---- 流动性热图 (Liquidity Heatmap) ------------------------------------
  // 设计 (Design):
  //   - X 轴 = 时间桶（与录盘 1min 对齐，可放大到 5/15min）
  //   - Y 轴 = 价格桶（围绕中价的对称窗，自适应 ~200 桶）
  //   - 颜色 = 该 (time,price) 桶内 USDT 名义额峰值，log scale
  //     bid 区域偏绿，ask 区域偏红，更亮 = 更厚的"墙"
  //   - 时间轴跟随主图 visibleTimeRange，主图缩放 / 拖动会触发热图重拉。
  //   - 数据回放窗口由 obRecorder 决定（默认 25h）；超出 / 现货 / 非 BTC
  //     场景下显示"无数据"提示，不影响其它面板。
  // 仅 BTCUSDT futures 录盘 → 其他 symbol/market 隐藏整个 section。
  // -------------------------------------------------------------------------
  const heatmap = (function initHeatmap() {
    const canvas  = els.heatmapCanvas;
    const tooltip = els.heatmapTooltip;
    const empty   = els.heatmapEmpty;
    const meta    = els.heatmapMeta;
    const card    = document.getElementById('heatmap-card');
    if (!canvas || !card) return null;
    const ctx = canvas.getContext('2d');

    function _readPriceRange() {
      const v = els.heatmapRange ? els.heatmapRange.value : 'auto';
      if (v === 'auto' || v === '') return 'auto';
      const n = Number(v);
      return (Number.isFinite(n) && n > 0) ? n : 'auto';
    }

    const state = {
      windowMs: Number((els.heatmapWindow && els.heatmapWindow.value) || 3_600_000),
      priceRange: _readPriceRange(),
      klineInterval: (els.heatmapKlineInterval && els.heatmapKlineInterval.value) || '5m',
      // anchorMs：热图 to 时刻（默认 null = 跟实时 now，主图 hover 时锁定到 hover 时间）
      anchorMs: null,
      dragPanMs: 0, // 手动拖拽平移的毫秒数
      data: null,
      heatmapKlines: [],
      pixelRatio: window.devicePixelRatio || 1,
      cssWidth: 0,
      cssHeight: 0,
      lastFetchKey: '',
      lastFetchAt: 0,
      pendingTimer: null,
      plot: { x: 56, y: 6, w: 0, h: 0 },
      hoverCell: null
    };

    /*
     * canvas 尺寸同步：
     * - 用 parentElement 的 clientWidth/Height（不含 border / scrollbar）量纲，
     *   不读 getBoundingClientRect().height（受 transform / sub-pixel 影响）。
     * - 仅在与上次记录的 cssWidth/cssHeight 真的不同时，才触发 canvas 重设
     *   + 重绘，避免 ResizeObserver 与 canvas style 写入 互相触发的死循环
     *   （之前页面会被持续拉长就是这条 loop 的副作用）。
     */
    function _resizeCanvas() {
      const parent = canvas.parentElement;
      if (!parent) return;
      const w = Math.max(20, Math.floor(parent.clientWidth));
      const h = Math.max(20, Math.floor(parent.clientHeight));
      if (w === state.cssWidth && h === state.cssHeight) return;
      state.cssWidth = w;
      state.cssHeight = h;
      const dpr = window.devicePixelRatio || 1;
      state.pixelRatio = dpr;
      canvas.width  = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      // 不再写 canvas.style.width/height —— canvas 已经是 absolute inset:0,
      // 100% 跟随 .pane-body，让父容器单向决定尺寸，避免反向反馈。
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      state.plot.x = 64;
      state.plot.y = 8;
      state.plot.w = Math.max(20, w - state.plot.x - 12);
      state.plot.h = Math.max(20, h - state.plot.y - 22);
      _draw();
    }

    function _isApplicable() {
      // 只要是 futures 就可以尝试拉取，如果没有录盘数据会返回空并显示拉取失败
      const mkt = els.market ? els.market.value : '';
      return mkt === 'futures';
    }

    function _setVisibility() {
      card.style.display = _isApplicable() ? '' : 'none';
    }

    function _updateMeta(extra) {
      if (!meta) return;
      const d = state.data;
      if (!d) { meta.textContent = extra || '等待数据… / Loading…'; return; }
      const tFmt = (ms) => fmtBJShortDateTime(ms);
      const cells = (d.times ? d.times.length : 0) * (d.prices ? d.prices.length : 0);
      const rangeTxt = d.autoRange && Number.isFinite(d.priceRange)
        ? `±${(d.priceRange * 100).toFixed(2)}% (auto)`
        : (Number.isFinite(d.priceRange) ? `±${(d.priceRange * 100).toFixed(2)}%` : '-');
      meta.textContent = `${tFmt(d.fromMs)} → ${tFmt(d.toMs)} · 桶 ${(d.bucketMs/60_000).toFixed(0)}m × ${d.priceBucket || '-'} USDT · 范围 ${rangeTxt} · 快照 ${d.snapshotCount || 0}` + (extra ? ` · ${extra}` : '');
    }

    /*
     * 颜色映射 — Viridis colormap (CoinGlass 风格):
     *   - 同一格内 bid+ask 合并取强度，整图统一用 viridis (紫→蓝→青→绿→黄)
     *   - bid/ask 通过 tooltip 区分，不靠颜色（CoinGlass 也是不分方向）
     *   - P95 归一化避免极端墙吃对比度
     */
    function _colorFor(value, normMax /*, _isBid */) {
      return viridisFromValue(value, normMax);
    }

    /*
     * 挂单墙检测 (Wall detection)：
     *   - 每个价位行取时间维度的峰值 (row-max)，行峰值 ≥ P95 的视为"墙"
     *   - bid 墙取中价下方 top3、ask 墙取中价上方 top3（相邻 2 桶内去重）
     *   - 墙线从"墙首次出现"的时间桶向右延伸；
     *     当叠加 K 线穿过该价位（bid: low≤墙价 / ask: high≥墙价）即断开
     * 结果缓存到 state._walls，仅在 data / K线 变化时重算（拖拽重绘不重算）。
     */
    function _detectWalls(d, klines) {
      if (!d || !d.times || !d.times.length || !d.prices || !d.prices.length) return [];
      const T = d.times.length;
      const P = d.prices.length;
      const half = (d.priceBucket || 0) / 2;
      const mid = Number.isFinite(d.midPrice) ? d.midPrice : NaN;
      const threshold = (Number.isFinite(d.p95) && d.p95 > 0) ? d.p95 : (d.maxValue || 0) * 0.5;
      if (!(threshold > 0) || !Number.isFinite(mid)) return [];

      // 行峰值 + 首次达到 60% 行峰值的时间桶
      const cand = { bid: [], ask: [] };
      for (let pi = 0; pi < P; pi += 1) {
        let bidMax = 0, askMax = 0;
        for (let ti = 0; ti < T; ti += 1) {
          const bv = d.bidMatrix[ti] ? (d.bidMatrix[ti][pi] || 0) : 0;
          const av = d.askMatrix[ti] ? (d.askMatrix[ti][pi] || 0) : 0;
          if (bv > bidMax) bidMax = bv;
          if (av > askMax) askMax = av;
        }
        const price = d.prices[pi] + half;
        if (bidMax >= threshold && price < mid) cand.bid.push({ pi, price, value: bidMax });
        if (askMax >= threshold && price > mid) cand.ask.push({ pi, price, value: askMax });
      }

      const intervalMs = (klines && klines.length > 1)
        ? Number(klines[1].openTime) - Number(klines[0].openTime)
        : 60_000;

      const out = [];
      for (const side of ['bid', 'ask']) {
        cand[side].sort((a, b) => b.value - a.value);
        const picked = [];
        for (const c of cand[side]) {
          if (picked.length >= 3) break;
          if (picked.some((p) => Math.abs(p.pi - c.pi) <= 2)) continue; // 相邻桶属于同一面墙
          picked.push(c);
        }
        for (const c of picked) {
          // 首次成墙时间：该行第一次达到 60% 行峰值
          const matrix = side === 'bid' ? d.bidMatrix : d.askMatrix;
          let firstTi = 0;
          for (let ti = 0; ti < T; ti += 1) {
            const v = matrix[ti] ? (matrix[ti][c.pi] || 0) : 0;
            if (v >= c.value * 0.6) { firstTi = ti; break; }
          }
          const startMs = d.times[firstTi];
          // K 线穿墙 → 断开
          let endMs = d.toMs;
          let broken = false;
          if (klines && klines.length) {
            for (const k of klines) {
              const ts = Number(k.openTime);
              if (ts < startMs) continue;
              const pierced = side === 'bid'
                ? Number(k.low) <= c.price
                : Number(k.high) >= c.price;
              if (pierced) {
                endMs = Math.min(d.toMs, ts + intervalMs);
                broken = true;
                break;
              }
            }
          }
          out.push({ side, price: c.price, value: c.value, startMs, endMs, broken });
        }
      }
      return out;
    }

    /** 选好看的价格 tick 步长（1/2/5 ×10^k 系列） */
    function _niceStep(rawStep) {
      if (!(rawStep > 0)) return 1;
      const exp = Math.pow(10, Math.floor(Math.log10(rawStep)));
      const norm = rawStep / exp;
      let factor;
      if (norm < 1.5) factor = 1;
      else if (norm < 3.5) factor = 2;
      else if (norm < 7.5) factor = 5;
      else factor = 10;
      return factor * exp;
    }

    function _draw(offsetX = 0, offsetY = 0) {
      if (!ctx) return;
      const W = state.cssWidth, H = state.cssHeight;
      ctx.clearRect(0, 0, W, H);
      // Viridis 起始色 (深紫 #1a0033) 作背景，与色阶最低端衔接自然
      ctx.fillStyle = '#1a0033';
      ctx.fillRect(0, 0, W, H);

      const d = state.data;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;

      if (!d || !d.times || !d.times.length || !d.prices || !d.prices.length || !(d.maxValue > 0)) {
        if (empty) empty.style.display = 'flex';
        return;
      }
      if (empty) empty.style.display = 'none';

      const T = d.times.length;
      const P = d.prices.length;
      const cellW = pw / T;
      const cellH = ph / P;

      // === 以下内容随鼠标拖动进行视觉平移 ===
      ctx.save();
      ctx.beginPath();
      // 向下稍微放宽一点 clip 区域，以便把底部的"时间刻度"也一起平移
      ctx.rect(ox, oy, pw, ph + 20);
      ctx.clip();
      ctx.translate(offsetX, offsetY);

      // 色块：合并 bid+ask 取较大值（同价位通常只会有一边有挂单）
      const normMax = (Number.isFinite(d.p95) && d.p95 > 0) ? d.p95 : d.maxValue;
      for (let ti = 0; ti < T; ti += 1) {
        const x = ox + ti * cellW;
        for (let pi = 0; pi < P; pi += 1) {
          const yTop = oy + (P - 1 - pi) * cellH;
          const bidV = d.bidMatrix[ti] ? d.bidMatrix[ti][pi] : 0;
          const askV = d.askMatrix[ti] ? d.askMatrix[ti][pi] : 0;
          const v = Math.max(bidV, askV);
          if (v <= 0) continue;
          const color = _colorFor(v, normMax);
          if (!color) continue;
          ctx.fillStyle = color;
          ctx.fillRect(x, yTop, cellW + 1, cellH + 1);
        }
      }

    // ---- (1.5) K线叠加 (Overlay K-lines) -------------------
    if (state.heatmapKlines && state.heatmapKlines.length > 0) {
      let intervalMs = 60000;
      if (state.heatmapKlines.length > 1) {
          intervalMs = Number(state.heatmapKlines[1].openTime) - Number(state.heatmapKlines[0].openTime);
      }
      const candleW = Math.max(1, (intervalMs / (d.toMs - d.fromMs)) * pw * 0.5);
      for (const c of state.heatmapKlines) {
        const ts = Number(c.openTime);
        if (ts < d.fromMs - intervalMs || ts > d.toMs + intervalMs) continue;
        
        const x = ox + ((ts - d.fromMs) / (d.toMs - d.fromMs)) * pw;
        const open = Number(c.open);
        const high = Number(c.high);
        const low = Number(c.low);
        const close = Number(c.close);
        
        const yO = oy + ph - ((open - d.priceMin) / (d.priceMax - d.priceMin)) * ph;
        const yH = oy + ph - ((high - d.priceMin) / (d.priceMax - d.priceMin)) * ph;
        const yL = oy + ph - ((low - d.priceMin) / (d.priceMax - d.priceMin)) * ph;
        const yC = oy + ph - ((close - d.priceMin) / (d.priceMax - d.priceMin)) * ph;
        
        const isUp = close >= open;
        // 半透明K线，避免完全遮挡热图
        ctx.strokeStyle = isUp ? 'rgba(74, 222, 128, 0.85)' : 'rgba(248, 113, 113, 0.85)';
        ctx.fillStyle = isUp ? 'rgba(74, 222, 128, 0.85)' : 'rgba(248, 113, 113, 0.85)';
        
        // 影线
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(x, yH);
        ctx.lineTo(x, yL);
        ctx.stroke();
        
        // 实体
        const bodyTop = Math.min(yO, yC);
        const bodyBottom = Math.max(yO, yC);
        const bodyHeight = Math.max(2, bodyBottom - bodyTop);
        const hw = Math.max(1, candleW / 2);
        
        ctx.fillRect(x - hw, bodyTop, hw * 2, bodyHeight);
      }
    }

    // ---- (1.6) 挂单墙延伸线 (Wall extension lines) -------------------
    // 墙从形成时刻向右延伸，被 K 线穿过即断开；缓存避免拖拽重绘时重算。
    if (state._wallsSrc !== d || state._wallsKlines !== state.heatmapKlines) {
      state._walls = _detectWalls(d, state.heatmapKlines);
      state._wallsSrc = d;
      state._wallsKlines = state.heatmapKlines;
    }
    if (state._walls && state._walls.length) {
      const span = d.toMs - d.fromMs;
      const pSpan = d.priceMax - d.priceMin;
      ctx.save();
      ctx.setLineDash([6, 3]);
      ctx.lineWidth = 1.5;
      ctx.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.textBaseline = 'bottom';
      for (const wl of state._walls) {
        const y = oy + ph - ((wl.price - d.priceMin) / pSpan) * ph;
        if (y < oy || y > oy + ph) continue;
        const x1 = ox + Math.max(0, (wl.startMs - d.fromMs) / span) * pw;
        const x2 = ox + Math.min(1, (wl.endMs - d.fromMs) / span) * pw;
        if (x2 - x1 < 2) continue;
        const color = wl.side === 'bid' ? 'rgba(74, 222, 128, 0.9)' : 'rgba(248, 113, 113, 0.9)';
        ctx.strokeStyle = color;
        ctx.beginPath();
        ctx.moveTo(x1, y);
        ctx.lineTo(x2, y);
        ctx.stroke();
        // 断开处画一个小 ✕，表示墙被 K 线穿过
        if (wl.broken) {
          ctx.save();
          ctx.setLineDash([]);
          ctx.beginPath();
          ctx.moveTo(x2 - 3, y - 3); ctx.lineTo(x2 + 3, y + 3);
          ctx.moveTo(x2 - 3, y + 3); ctx.lineTo(x2 + 3, y - 3);
          ctx.stroke();
          ctx.restore();
        }
        // 起点标签：墙厚度（USDT 名义额，紧凑格式）
        const v = wl.value;
        const label = v >= 1e9 ? `${(v / 1e9).toFixed(1)}B`
          : v >= 1e6 ? `${(v / 1e6).toFixed(1)}M`
          : v >= 1e3 ? `${(v / 1e3).toFixed(0)}K` : `${Math.round(v)}`;
        ctx.fillStyle = color;
        ctx.textAlign = 'left';
        ctx.fillText(label, x1 + 2, y - 2);
      }
      ctx.restore();
    }

    ctx.restore();

    // === 2. 价格刻度和网格 (仅 Y 轴平移) ===
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, oy, W, ph); // 限制在图表高度内
    ctx.clip();
    ctx.translate(0, offsetY);

      // ---- (2) 水平价格 grid（暗色虚线） ---------------------
      const priceSpan = d.priceMax - d.priceMin;
      const targetTicks = Math.max(6, Math.min(12, Math.floor(ph / 36)));
      const step = _niceStep(priceSpan / targetTicks);
      const startTick = Math.ceil(d.priceMin / step) * step;
      ctx.save();
      ctx.strokeStyle = 'rgba(255,255,255,0.05)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 4]);
      ctx.beginPath();
      for (let p = startTick; p <= d.priceMax; p += step) {
        const y = oy + ph * (1 - (p - d.priceMin) / priceSpan);
        ctx.moveTo(ox, y);
        ctx.lineTo(ox + pw, y);
      }
      ctx.stroke();
      ctx.restore();

      // ---- (3) 价格刻度 (左侧) -------------------------------
      ctx.fillStyle = 'rgba(220,228,240,0.95)';
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      const priceFmt = (p) => p >= 1000 ? p.toFixed(0) : p.toFixed(2);
      for (let p = startTick; p <= d.priceMax; p += step) {
        const y = oy + ph * (1 - (p - d.priceMin) / priceSpan);
        ctx.fillText(priceFmt(p), ox - 6, y);
      }

      // ---- (4) 中价线 + 中价标签（白色实线 + 价签） --------------
      if (Number.isFinite(d.midPrice)) {
        const yMid = oy + ph * (1 - (d.midPrice - d.priceMin) / priceSpan);
        if (yMid > oy && yMid < oy + ph) {
          ctx.save();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
          ctx.lineWidth = 1;
          ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(ox, yMid);
          ctx.lineTo(ox + pw, yMid);
          ctx.stroke();
          ctx.setLineDash([]);
          // 中价 tag：右侧
          const tagText = priceFmt(d.midPrice);
          ctx.font = 'bold 11px ui-monospace, SFMono-Regular, Menlo, monospace';
          const tagW = ctx.measureText(tagText).width + 8;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.fillRect(ox + pw - tagW - 2, yMid - 8, tagW, 16);
          ctx.fillStyle = '#0b0e16';
          ctx.textAlign = 'center';
          ctx.fillText(tagText, ox + pw - tagW / 2 - 2, yMid);
          ctx.restore();
        }
      }
      
    ctx.restore();

    // === 3. 时间刻度和垂直线 (仅 X 轴平移) ===
    ctx.save();
    ctx.beginPath();
    ctx.rect(ox, oy, pw, ph + 30);
    ctx.clip();
    ctx.translate(offsetX, 0);

      // ---- (5) 时间刻度 (底部) -------------------------------
      ctx.fillStyle = 'rgba(220,228,240,0.95)';
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      const timeTicks = Math.max(4, Math.min(10, Math.floor(pw / 90)));
      for (let i = 0; i <= timeTicks; i += 1) {
        const frac = i / timeTicks;
        const t = d.fromMs + (d.toMs - d.fromMs) * frac;
        const x = ox + pw * frac;
        const text = fmtBJTimeHMS(t).slice(0, 5); // HH:mm
        ctx.fillText(text, Math.max(ox + 14, Math.min(ox + pw - 14, x)), oy + ph + 4);
        // 底部小竖线
        ctx.strokeStyle = 'rgba(255,255,255,0.15)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 0.5, oy + ph);
        ctx.lineTo(x + 0.5, oy + ph + 3);
        ctx.stroke();
      }

      // ---- (6) anchor 锁定线（主图 hover 时）-----------------
      if (Number.isFinite(state.anchorMs) && state.anchorMs >= d.fromMs && state.anchorMs <= d.toMs) {
        const xA = ox + pw * ((state.anchorMs - d.fromMs) / (d.toMs - d.fromMs));
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 215, 0, 0.7)';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(xA, oy);
        ctx.lineTo(xA, oy + ph);
        ctx.stroke();
        ctx.restore();
      }
      
      // 结束 X 轴平移上下文
      ctx.restore();

      // ---- (7) 边框 + hover 高亮 ------------------------------
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1;
      ctx.strokeRect(ox + 0.5, oy + 0.5, pw, ph);

      if (state.hoverCell && !isDragging) {
        const { ti, pi } = state.hoverCell;
        if (ti >= 0 && ti < T && pi >= 0 && pi < P) {
          const x = ox + ti * cellW;
          const y = oy + (P - 1 - pi) * cellH;
          if (x >= ox && x <= ox + pw) {
            ctx.save();
            ctx.strokeStyle = 'rgba(255,255,255,0.85)';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(x + 0.5, y + 0.5, cellW, cellH);
            ctx.restore();
          }
        }
      }
      
      // 如果有平移，右上角绘制一个复位小提示
      if ((state.dragPanMs > 0 || Math.abs(state.dragPanPrice) > 0) && !isDragging) {
        ctx.fillStyle = 'rgba(251, 191, 36, 0.15)';
        ctx.fillRect(ox + pw - 90, oy + 4, 86, 20);
        ctx.fillStyle = '#fbbf24';
        ctx.font = '11px ui-monospace, SFMono-Regular';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('双击复位 (Reset)', ox + pw - 47, oy + 14);
      }
    }

    function _hitTest(clientX, clientY) {
      const rect = canvas.getBoundingClientRect();
      const cx = clientX - rect.left;
      const cy = clientY - rect.top;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;
      const d = state.data;
      if (!d || cx < ox || cx > ox + pw || cy < oy || cy > oy + ph) return null;
      const T = d.times.length;
      const P = d.prices.length;
      if (!T || !P) return null;
      const ti = Math.floor((cx - ox) / (pw / T));
      const pi = P - 1 - Math.floor((cy - oy) / (ph / P));
      if (ti < 0 || ti >= T || pi < 0 || pi >= P) return null;
      return { ti, pi, cx, cy };
    }

    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragStartPan = 0;
    let dragStartPanPrice = 0;
    let dragOffsetPx = 0;
    let dragOffsetYPx = 0;

    canvas.addEventListener('mousedown', (e) => {
      isDragging = true;
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      dragStartPan = state.dragPanMs || 0;
      dragStartPanPrice = state.dragPanPrice || 0;
      dragOffsetPx = 0;
      dragOffsetYPx = 0;
      canvas.style.cursor = 'grabbing';
    });

    window.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        canvas.style.cursor = 'crosshair';
        if (Math.abs(dragOffsetPx) > 0 || Math.abs(dragOffsetYPx) > 0) {
          const msPerPixel = state.windowMs / state.plot.w;
          state.dragPanMs = dragStartPan + dragOffsetPx * msPerPixel;
          if (state.dragPanMs < -state.windowMs * 0.8) state.dragPanMs = -state.windowMs * 0.8;
          
          if (state.data && state.data.priceMax && state.data.priceMin) {
             const pricePerPixel = (state.data.priceMax - state.data.priceMin) / state.plot.h;
             state.dragPanPrice = dragStartPanPrice + dragOffsetYPx * pricePerPixel;
          }
          
          dragOffsetPx = 0;
          dragOffsetYPx = 0;
          // 当发生拖拽后，强制切换到 custom 价格范围，以维持平移后的视角
          if (state.priceRange === 'auto' && Math.abs(state.dragPanPrice) > 0) {
              state.priceRange = 'custom';
              if (els.heatmapRange) els.heatmapRange.value = 'custom';
          }
          scheduleFetch(0);
        }
      }
    });

    canvas.addEventListener('mousemove', (e) => {
      if (isDragging) {
        dragOffsetPx = e.clientX - dragStartX;
        dragOffsetYPx = e.clientY - dragStartY;
        // 拖动时，做视觉平移
        _draw(dragOffsetPx, dragOffsetYPx);
        return;
      }
      
      const hit = _hitTest(e.clientX, e.clientY);
      state.hoverCell = hit;
      if (!hit) {
        tooltip.style.display = 'none';
        _draw();
        return;
      }
      const d = state.data;
      const t  = d.times[hit.ti];
      const p  = d.prices[hit.pi];
      const bid = (d.bidMatrix[hit.ti] || [])[hit.pi] || 0;
      const ask = (d.askMatrix[hit.ti] || [])[hit.pi] || 0;
      const fmtMoney = (v) => v >= 1e6
        ? (v / 1e6).toFixed(2) + 'M'
        : v >= 1e3 ? (v / 1e3).toFixed(2) + 'K' : v.toFixed(0);
      tooltip.innerHTML =
        `<div><b>${fmtBJDateTime(t)} (UTC+8)</b></div>` +
        `<div>价格 / Price: <b>${p.toFixed(p >= 1000 ? 1 : 2)}</b></div>` +
        `<div>买墙 / Bid: <span style="color:#4ade80">${fmtMoney(bid)} USDT</span></div>` +
        `<div>卖墙 / Ask: <span style="color:#f87171">${fmtMoney(ask)} USDT</span></div>` +
        `<div style="opacity:0.7;font-size:10px">合计: ${fmtMoney(bid + ask)} USDT</div>`;
      tooltip.style.display = 'block';
      const rect = canvas.parentElement.getBoundingClientRect();
      const ttX = Math.min(rect.width - 220, hit.cx + 10);
      const ttY = Math.max(0, hit.cy + 10);
      tooltip.style.left = ttX + 'px';
      tooltip.style.top  = ttY + 'px';
      _draw();
    });
    canvas.addEventListener('dblclick', () => {
      state.dragPanMs = 0;
      state.dragPanPrice = 0;
      state.windowMs = Number(els.heatmapWindow ? els.heatmapWindow.value : 3_600_000) || 3_600_000;
      if (els.heatmapRange) els.heatmapRange.value = 'auto';
      state.priceRange = 'auto';
      scheduleFetch(0);
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      
      const isZoom = e.ctrlKey || e.metaKey || (!e.deltaX && !e.shiftKey && Math.abs(e.deltaY) > 0);
      
      if (isZoom) {
        // 放大缩小 (Zoom)
        const zoomFactor = e.deltaY > 0 ? 1.1 : 1 / 1.1;
        const oldWindowMs = state.windowMs;
        const newWindowMs = Math.max(5 * 60_000, Math.min(180 * 86400_000, oldWindowMs * zoomFactor));
        
        // 保持鼠标所在位置的时间不变 (Zoom around cursor)
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const { x: ox, w: pw } = state.plot;
        if (x >= ox && x <= ox + pw) {
          const ratio = (x - ox) / pw;
          state.dragPanMs += (1 - ratio) * (oldWindowMs - newWindowMs);
        }
        
        state.windowMs = newWindowMs;
        if (state.dragPanMs < -state.windowMs * 0.8) state.dragPanMs = -state.windowMs * 0.8;
        scheduleFetch(50);
      } else {
        // 使用触控板双指滑动进行平移
        const dx = e.deltaX || (e.shiftKey ? e.deltaY : 0);
        if (Math.abs(dx) > 0) {
          const msPerPixel = state.windowMs / state.plot.w;
          state.dragPanMs -= dx * msPerPixel;
          if (state.dragPanMs < -state.windowMs * 0.8) state.dragPanMs = -state.windowMs * 0.8;
          scheduleFetch(150);
        }
      }
    });

    canvas.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const y = e.clientY - rect.top;
      const { y: oy, h: ph } = state.plot;
      const d = state.data;
      if (d && y >= oy && y <= oy + ph) {
        const price = d.priceMax - ((y - oy) / ph) * (d.priceMax - d.priceMin);
        const priceStr = price >= 1000 ? price.toFixed(1) : price.toFixed(4);
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(priceStr).then(() => {
            _showToast(`已复制价格: ${priceStr}`);
          });
        } else {
          // fallback
          const textArea = document.createElement("textarea");
          textArea.value = priceStr;
          document.body.appendChild(textArea);
          textArea.select();
          document.execCommand("Copy");
          textArea.remove();
          _showToast(`已复制价格: ${priceStr}`);
        }
      }
    });

    function _showToast(msg) {
      let toast = document.getElementById('heatmap-toast');
      if (!toast) {
        toast = document.createElement('div');
        toast.id = 'heatmap-toast';
        toast.style.position = 'absolute';
        toast.style.top = '10px';
        toast.style.right = '10px';
        toast.style.background = 'rgba(11, 14, 22, 0.9)';
        toast.style.color = '#4ade80';
        toast.style.padding = '8px 16px';
        toast.style.borderRadius = '4px';
        toast.style.fontFamily = 'ui-monospace, SFMono-Regular, monospace';
        toast.style.fontSize = '12px';
        toast.style.zIndex = '9999';
        toast.style.pointerEvents = 'none';
        toast.style.transition = 'opacity 0.3s';
        toast.style.border = '1px solid rgba(74, 222, 128, 0.3)';
        canvas.parentElement.appendChild(toast);
      }
      toast.textContent = msg;
      toast.style.opacity = '1';
      setTimeout(() => {
        toast.style.opacity = '0';
      }, 1500);
    }

    canvas.addEventListener('mouseleave', () => {
      state.hoverCell = null;
      tooltip.style.display = 'none';
      _draw();
    });

    /*
     * 取数策略 (Range strategy):
     *   - 用户在 toolbar 选的 windowMs 直接决定窗口长度（15m/1h/4h/24h），
     *     不再被主图 visibleTimeRange 覆盖 —— 这是之前"切窗口没反应"的根因。
     *   - to = anchorMs（主图 hover 锁定的时刻）|| Date.now()。
     *   - bucket 自适应：力求每图约 60~90 个时间桶，可读性最佳。
     */
    function _resolveRange() {
      const baseToMs = Number.isFinite(state.anchorMs) ? state.anchorMs : Date.now();
      const toMs = baseToMs - state.dragPanMs;
      const fromMs = toMs - state.windowMs;
      const span = toMs - fromMs;
      let bucketMs;
      if (span <= 15 * 60_000)        bucketMs = 60_000;          // 15m → 1m × 15
      else if (span <= 60 * 60_000)   bucketMs = 60_000;          // 1h  → 1m × 60
      else if (span <= 4 * 3600_000)  bucketMs = 2 * 60_000;      // 4h  → 2m × 120
      else if (span <= 12 * 3600_000) bucketMs = 10 * 60_000;     // 12h → 10m × 72
      else if (span <= 24 * 3600_000) bucketMs = 15 * 60_000;     // 24h → 15m × 96
      else if (span <= 7 * 86400_000) bucketMs = 2 * 3600_000;    // 1w  → 2h × 84
      else if (span <= 14 * 86400_000) bucketMs = 4 * 3600_000;   // 2w  → 4h × 84
      else if (span <= 21 * 86400_000) bucketMs = 6 * 3600_000;   // 3w  → 6h × 84
      else if (span <= 31 * 86400_000) bucketMs = 8 * 3600_000;   // 1mo → 8h × 93
      else if (span <= 62 * 86400_000) bucketMs = 12 * 3600_000;  // 2mo → 12h × 124
      else                            bucketMs = 24 * 3600_000;   // 3mo+ → 24h
      return { fromMs, toMs, bucketMs };
    }

    /**
     * 主图 hover 时的锚定回调。hoverMs 为 null 表示恢复到实时 now。
     */
    function setHeatmapAnchor(hoverMs) {
      // 只有在没被用户手动拖动平移的时候，才响应主图的锚定
      if (state.dragPanMs > 0) return;
      
      const next = Number.isFinite(hoverMs) ? Math.floor(hoverMs) : null;
      if (next === state.anchorMs) return;
      state.anchorMs = next;
      state.lastFetchKey = '';
      scheduleFetch(next == null ? 0 : 200);
    }

    async function _fetch() {
      if (!_isApplicable()) return;
      const { fromMs, toMs, bucketMs } = _resolveRange();
      const symbol = els.symbol.value.toUpperCase();
      const market = els.market.value;
      const key = `${symbol}|${market}|${fromMs}|${toMs}|${bucketMs}|${state.priceRange === 'auto' ? 'auto' : String(state.priceRange)}|${state.klineInterval}`;
      // 同一参数 5s 内不重拉
      const now = Date.now();
      if (key === state.lastFetchKey && now - state.lastFetchAt < 5_000) return;
      state.lastFetchKey = key;
      state.lastFetchAt = now;
      try {
        const params = new URLSearchParams({
          symbol, market,
          from: String(fromMs),
          to: String(toMs),
          bucketMs: String(bucketMs)
        });
        if (state.priceRange === 'auto') {
          params.set('priceRange', 'auto');
        } else if (state.priceRange === 'custom' && state.data && state.data.priceMax && state.data.priceMin) {
          params.set('priceRange', 'custom');
          // 将平移后的中心价和原本的跨度传过去
          const span = state.data.priceMax - state.data.priceMin;
          params.set('priceMin', String(state.data.priceMin + state.dragPanPrice));
          params.set('priceMax', String(state.data.priceMax + state.dragPanPrice));
        } else {
          params.set('priceRange', String(state.priceRange));
        }
        
        // 并发请求热图和K线
        const heatmapUrl = `/api/orderbook/heatmap?${params.toString()}`;
        
        const klineLimit = 1500;
        const klineUrl = `/api/klines?symbol=${symbol}&interval=${state.klineInterval}&limit=${klineLimit}&market=${market}&endTime=${toMs}&detectPatterns=false`;

        const [data, klineRes] = await Promise.all([
          fetchJsonSoft(heatmapUrl),
          fetchJsonSoft(klineUrl)
        ]);

        if (!data) {
          _updateMeta('拉取失败 / Fetch failed');
          return;
        }
        state.data = data;
        state.heatmapKlines = (klineRes && klineRes.candles) ? klineRes.candles : [];
        _updateMeta();
        _draw();
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[heatmap] fetch err:', err.message);
        _updateMeta('错误 / Error: ' + err.message);
      } finally {
        // 成功 / 失败都揭开 loading（失败时 meta 已显示原因）
        hideChartLoading(canvas.parentElement);
      }
    }

    function scheduleFetch(delay) {
      if (state.pendingTimer) clearTimeout(state.pendingTimer);
      state.pendingTimer = setTimeout(() => {
        state.pendingTimer = null;
        _fetch();
      }, delay != null ? delay : 250);
    }

    // 控件变化 → 立即刷新（盖 loading，_fetch 完成后揭开）
    if (els.heatmapWindow) {
      els.heatmapWindow.addEventListener('change', () => {
        state.windowMs = Number(els.heatmapWindow.value) || 3_600_000;
        state.dragPanMs = 0; // 切换窗口大小时，重置拖动平移，回到实时或锚定位置
        state.lastFetchKey = ''; // 强制重拉
        showChartLoading(canvas.parentElement);
        scheduleFetch(0);
      });
    }
    if (els.heatmapKlineInterval) {
      els.heatmapKlineInterval.addEventListener('change', () => {
        state.klineInterval = els.heatmapKlineInterval.value || '5m';
        state.lastFetchKey = ''; // 强制重拉
        showChartLoading(canvas.parentElement);
        scheduleFetch(0);
      });
    }

    if (els.heatmapRange) {
      els.heatmapRange.addEventListener('change', () => {
        state.priceRange = _readPriceRange();
        state.lastFetchKey = '';
        scheduleFetch(0);
      });
    }

    // 容器尺寸跟随：用 ResizeObserver 监控 .pane-body
    // rAF 包一层 + 防重入，避免触发 "ResizeObserver loop limit exceeded" 警告
    // 与可能的页面缓慢拉长副作用。
    let _roPending = false;
    const ro = new ResizeObserver(() => {
      if (_roPending) return;
      _roPending = true;
      requestAnimationFrame(() => {
        _roPending = false;
        _resizeCanvas();
      });
    });
    ro.observe(canvas.parentElement);
    // 兜底：窗口尺寸变化时也校准一次（某些浏览器 RO 触发不稳）
    window.addEventListener('resize', () => {
      if (_roPending) return;
      _roPending = true;
      requestAnimationFrame(() => {
        _roPending = false;
        _resizeCanvas();
      });
    });

    // 周期性自动刷新（每 60s 一次，确保即使主图没动热图也跟最新录盘）
    setInterval(() => scheduleFetch(0), 60_000);

    _setVisibility();
    _resizeCanvas();
    // 首次延迟拉一次（等主图 setData 后 visibleRange 才靠谱）
    scheduleFetch(800);

    return {
      refresh: () => scheduleFetch(0),
      redraw: () => _draw(),
      setAnchor: setHeatmapAnchor,
      resize: () => _resizeCanvas(),
      onSymbolMarketChange: () => {
        _setVisibility();
        state.data = null;
        state.lastFetchKey = '';
        state.anchorMs = null;
        _draw();
        if (_isApplicable()) scheduleFetch(300);
      }
    };
  })();

  // ---- 清算热力图 (Liquidation Heatmap · Predictive only) ---------------
  // 数据源 (Data source):
  //   GET /api/predictive/liquidations 基于 K 线 × 杠杆估算"潜在清算价位"
  //   (CoinGlass 风格，longMatrix / shortMatrix · USDT 累计名义额)。
  //   已扫消耗：未来 K 线穿过清算线时，从那一刻起从矩阵剔除该批仓位，
  //   保证图上只显示"还活着的潜在清算"，不画无意义残影。
  // 视觉 (Visual):
  //   - viridis 配色（紫 → 蓝 → 青 → 绿 → 黄）
  //   - 主峰=黄；alpha 用 P95 归一化 + sqrt 拉伸，避免极端值吃对比度
  // 联动 (Linkage):
  //   主图 hover → 锁定 anchor 时刻；hover 离开 → 实时 now。
  // 仅 BTCUSDT futures 显示。
  // -------------------------------------------------------------------------
  const liqHeatmap = (function initLiqHeatmap() {
    const canvas  = els.liqHeatmapCanvas;
    const tooltip = els.liqHeatmapTooltip;
    const empty   = els.liqHeatmapEmpty;
    const meta    = els.liqHeatmapMeta;
    const card    = document.getElementById('liq-heatmap-card');
    if (!canvas || !card) return null;
    const ctx = canvas.getContext('2d');

    function _readPriceRange() {
      const v = els.liqHeatmapRange ? els.liqHeatmapRange.value : 'auto';
      if (v === 'auto' || v === '') return 'auto';
      const n = Number(v);
      return (Number.isFinite(n) && n > 0) ? n : 'auto';
    }

    const state = {
      windowMs: Number((els.liqHeatmapWindow && els.liqHeatmapWindow.value) || 86_400_000),
      priceRange: _readPriceRange(),
      // 流动性阈值 (CoinGlass 风格)：只显示 v / max ≥ threshold 的 cell。
      // 滑块与右侧数字框双向同步；默认 0.5，0 = 显示全部，0.85 = 仅强清算墙。
      threshold: (() => {
        const v = els.liqHeatmapThresholdVal
          ? Number(els.liqHeatmapThresholdVal.value)
          : (els.liqHeatmapThreshold ? Number(els.liqHeatmapThreshold.value) : 0.5);
        return Number.isFinite(v) && v >= 0 && v < 1 ? v : 0.5;
      })(),
      anchorMs: null,
      data: null,
      cssWidth: 0,
      cssHeight: 0,
      lastFetchKey: '',
      lastFetchAt: 0,
      pendingTimer: null,
      plot: { x: 64, y: 8, w: 0, h: 0 },
      hoverCell: null
    };

    function _resizeCanvas() {
      const parent = canvas.parentElement;
      if (!parent) return;
      const w = Math.max(20, Math.floor(parent.clientWidth));
      const h = Math.max(20, Math.floor(parent.clientHeight));
      if (w === state.cssWidth && h === state.cssHeight) return;
      state.cssWidth = w;
      state.cssHeight = h;
      const dpr = window.devicePixelRatio || 1;
      canvas.width  = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      state.plot.x = 64;
      state.plot.y = 8;
      state.plot.w = Math.max(20, w - state.plot.x - 12);
      state.plot.h = Math.max(20, h - state.plot.y - 22);
      _draw();
    }

    function _isApplicable() {
      const mkt = els.market ? els.market.value : '';
      return mkt === 'futures';
    }
    function _setVisibility() {
      card.style.display = _isApplicable() ? '' : 'none';
    }

    const fmtMoney = (v) => v >= 1e6
      ? (v / 1e6).toFixed(2) + 'M'
      : v >= 1e3 ? (v / 1e3).toFixed(2) + 'K' : v.toFixed(0);

    function _updateMeta(extra) {
      if (!meta) return;
      const d = state.data;
      if (!d) { meta.textContent = extra || '等待数据… / Loading…'; return; }
      const tFmt = (ms) => fmtBJShortDateTime(ms);
      const rangeTxt = d.autoRange && Number.isFinite(d.priceRange)
        ? `±${(d.priceRange * 100).toFixed(2)}% (auto)`
        : (Number.isFinite(d.priceRange) ? `±${(d.priceRange * 100).toFixed(2)}%` : '-');
      const totalLong  = fmtMoney(d.totalLong  || 0);
      const totalShort = fmtMoney(d.totalShort || 0);
      const modeTag = '预测 / Predicted';
      const sourceTag = d.sourceInterval ? ` · 源 ${d.sourceInterval}` : '';
      const cntLabel = 'K线';
      const cntVal = d.candleCount || 0;
      const thrPct = (state.threshold * 100).toFixed(0);
      const thrTxt = state.threshold > 0
        ? ` · 阈值 ${thrPct}%（≥${thrPct}% max 才显示）`
        : '';
      const candleTxt = (d.candles && d.candles.length && d.candleInterval)
        ? ` · K线 ${d.candleInterval}×${d.candles.length}`
        : '';
      // 主峰文本（_draw 里同时计算了 row-max 和 row-sum 两组）。
      //   MAX = 单格最强 = 图上视觉最亮 = tooltip 数值最大 → 警报/信号触发
      //   SUM = 累计最深 = 该价位时间窗内总累积清算 USDT → 长期堆积参考
      // 同价位时合并显示，避免噪音；不同价位时两组都列出。
      // 箭头方向：S↑ = 空头墙在当前价上方；L↓ = 多头墙在当前价下方。
      const fmtPx = (v) => v >= 1000 ? v.toFixed(0) : v.toFixed(2);
      const peakTxt = (() => {
        const maxSp = state._peakShortPi    >= 0 && d.prices ? d.prices[state._peakShortPi]    : null;
        const maxLp = state._peakLongPi     >= 0 && d.prices ? d.prices[state._peakLongPi]     : null;
        const sumSp = state._peakShortSumPi >= 0 && d.prices ? d.prices[state._peakShortSumPi] : null;
        const sumLp = state._peakLongSumPi  >= 0 && d.prices ? d.prices[state._peakLongSumPi]  : null;
        const out = [];
        // 空头：MAX + 不同时附 SUM；同价位则合并为 MAX=SUM
        if (Number.isFinite(maxSp)) {
          if (Number.isFinite(sumSp) && sumSp === maxSp) {
            out.push(`S↑ MAX=SUM ${fmtPx(maxSp)}`);
          } else {
            let s = `S↑ MAX ${fmtPx(maxSp)}`;
            if (Number.isFinite(sumSp)) s += ` · SUM ${fmtPx(sumSp)}`;
            out.push(s);
          }
        }
        // 多头：MAX + 不同时附 SUM；同价位则合并为 MAX=SUM
        if (Number.isFinite(maxLp)) {
          if (Number.isFinite(sumLp) && sumLp === maxLp) {
            out.push(`L↓ MAX=SUM ${fmtPx(maxLp)}`);
          } else {
            let s = `L↓ MAX ${fmtPx(maxLp)}`;
            if (Number.isFinite(sumLp)) s += ` · SUM ${fmtPx(sumLp)}`;
            out.push(s);
          }
        }
        return out.length ? ` · 主峰 ${out.join(' / ')}` : '';
      })();
      meta.textContent =
        `${modeTag} · ${tFmt(d.fromMs)} → ${tFmt(d.toMs)} · 桶 ${(d.bucketMs/60_000).toFixed(0)}m × ${d.priceBucket || '-'} USDT · 范围 ${rangeTxt}${sourceTag} · ${cntLabel} ${cntVal} (多 ${totalLong} · 空 ${totalShort} USDT)${candleTxt}${peakTxt}${thrTxt}`
        + (extra ? ` · ${extra}` : '');
    }

    function _colorFor(value, normMax) {
      return viridisFromValue(value, normMax);
    }

    function _niceStep(rawStep) {
      if (!(rawStep > 0)) return 1;
      const exp = Math.pow(10, Math.floor(Math.log10(rawStep)));
      const norm = rawStep / exp;
      let factor;
      if (norm < 1.5) factor = 1;
      else if (norm < 3.5) factor = 2;
      else if (norm < 7.5) factor = 5;
      else factor = 10;
      return factor * exp;
    }

    function _draw() {
      if (!ctx) return;
      const W = state.cssWidth, H = state.cssHeight;
      ctx.clearRect(0, 0, W, H);
      // CoinGlass 风格深紫背景，与 viridis 起始色衔接
      ctx.fillStyle = '#1a0033';
      ctx.fillRect(0, 0, W, H);

      const d = state.data;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;
      if (!d || !d.times || !d.times.length || !d.prices || !d.prices.length || !(d.maxValue > 0)) {
        if (empty) {
          if (d && d.reason) empty.textContent = d.reason;
          else empty.textContent = '等待数据… / Loading predictive heatmap…';
          empty.style.display = 'flex';
        }
        return;
      }
      if (empty) empty.style.display = 'none';

      const T = d.times.length;
      const P = d.prices.length;
      const cellW = pw / T;
      const cellH = ph / P;

      // 用 p95 做色阶分母：让 5% 极值"爆顶为黄色"（明确的最强清算线），
      // 95% 普通信号铺底为青蓝/青绿，形成 CoinGlass 那种"少数亮黄主峰 +
      // 大量底色晕染"的层次。之前用 p95×1.6 会把黄色推到只剩 1~2 格。
      const normMax = (Number.isFinite(d.p95) && d.p95 > 0) ? d.p95 : d.maxValue;
      // 流动性阈值：用 maxValue 作分母（不是 normMax），threshold 直接对应
      // 用户感知的"占最强清算的百分比"。比如 0.85 = 只显示强度 ≥ 85% 最大值
      // 的格子，这才是 CoinGlass "突出最重要集群" 的语义。
      const thrAbs = (Number.isFinite(d.maxValue) && d.maxValue > 0)
        ? state.threshold * d.maxValue
        : 0;
      let _shownCells = 0;
      // 色块：合并 long+short 总强度（与 CoinGlass 一致——颜色不分方向，
      // 方向通过 tooltip 区分）
      for (let ti = 0; ti < T; ti += 1) {
        const x = ox + ti * cellW;
        for (let pi = 0; pi < P; pi += 1) {
          const yTop = oy + (P - 1 - pi) * cellH;
          const lv = d.longMatrix[ti]  ? d.longMatrix[ti][pi]  : 0;
          const sv = d.shortMatrix[ti] ? d.shortMatrix[ti][pi] : 0;
          const v = lv + sv;
          if (v <= 0) continue;
          // 阈值过滤：低于 threshold * maxValue 的弱集群直接跳过
          if (v < thrAbs) continue;
          const color = _colorFor(v, normMax);
          if (!color) continue;
          ctx.fillStyle = color;
          ctx.fillRect(x, yTop, cellW + 1, cellH + 1);
          _shownCells += 1;
        }
      }
      state._lastShownCells = _shownCells;

      // 价格 grid
      const priceSpan = d.priceMax - d.priceMin;
      const targetTicks = Math.max(6, Math.min(12, Math.floor(ph / 36)));
      const step = _niceStep(priceSpan / targetTicks);
      const startTick = Math.ceil(d.priceMin / step) * step;
      ctx.save();
      ctx.strokeStyle = 'rgba(255,255,255,0.05)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 4]);
      ctx.beginPath();
      for (let p = startTick; p <= d.priceMax; p += step) {
        const y = oy + ph * (1 - (p - d.priceMin) / priceSpan);
        ctx.moveTo(ox, y);
        ctx.lineTo(ox + pw, y);
      }
      ctx.stroke();
      ctx.restore();

      // 价格刻度
      ctx.fillStyle = 'rgba(220,228,240,0.95)';
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      const priceFmt = (p) => p >= 1000 ? p.toFixed(0) : p.toFixed(2);
      for (let p = startTick; p <= d.priceMax; p += step) {
        const y = oy + ph * (1 - (p - d.priceMin) / priceSpan);
        ctx.fillText(priceFmt(p), ox - 6, y);
      }

      // 中价线 + tag
      if (Number.isFinite(d.midPrice)) {
        const yMid = oy + ph * (1 - (d.midPrice - d.priceMin) / priceSpan);
        if (yMid > oy && yMid < oy + ph) {
          ctx.save();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
          ctx.lineWidth = 1;
          ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(ox, yMid);
          ctx.lineTo(ox + pw, yMid);
          ctx.stroke();
          ctx.setLineDash([]);
          const tagText = priceFmt(d.midPrice);
          ctx.font = 'bold 11px ui-monospace, SFMono-Regular, Menlo, monospace';
          const tagW = ctx.measureText(tagText).width + 8;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.fillRect(ox + pw - tagW - 2, yMid - 8, tagW, 16);
          ctx.fillStyle = '#0b0e16';
          ctx.textAlign = 'center';
          ctx.fillText(tagText, ox + pw - tagW / 2 - 2, yMid);
          ctx.restore();
        }
      }

      // 多空主峰高亮：按金融语义约束方向。
      //   多头清算 = 多头开仓后价格跌穿清算价 → 必在当前价【下方】
      //   空头清算 = 空头开仓后价格涨穿清算价 → 必在当前价【上方】
      //
      // 同时计算两种代表强度，让用户能对比：
      //   • row-max  = 该价位"最强单格"，等价于图上视觉最亮的横线 / tooltip 数值最大
      //   • row-sum  = 该价位所有时间桶的累计 USDT，反映"清算池长期堆积深度"
      //
      // 警报判定和后端信号触发墙都跟 row-max（活墙最适合做反转/触墙判定）；
      // row-sum 仅做视觉对比，标在图上和 meta 行供参考。
      //
      // ⚠️ 存活闸门：后端 sweepMode='clip' 后，被 K 线扫穿的清算带会以
      // "断带"形式留在历史列里（CoinGlass 视觉）。这些已消耗的残段不能再
      // 参与 S↑/L↓ 主峰候选 —— 只有"最后一个时间桶仍非零"的价位才是活墙。
      {
        const Tlen = d.times.length;
        const Plen = d.prices.length;
        const longMaxRow  = new Array(Plen).fill(0);
        const shortMaxRow = new Array(Plen).fill(0);
        const longSumRow  = new Array(Plen).fill(0);
        const shortSumRow = new Array(Plen).fill(0);
        // nonZeroCount = 该价位有多少个时间桶非零 → 反映"亮带长度 / 持续时间"。
        // 用来加权 row-max，避免单瞬时尖峰胜过长亮带（视觉感知 vs 单格最大值）。
        const longHits  = new Array(Plen).fill(0);
        const shortHits = new Array(Plen).fill(0);
        for (let ti = 0; ti < Tlen; ti += 1) {
          const lr = d.longMatrix[ti];
          const sr = d.shortMatrix[ti];
          if (!lr || !sr) continue;
          for (let pi = 0; pi < Plen; pi += 1) {
            const lv = lr[pi] || 0;
            const sv = sr[pi] || 0;
            if (lv > longMaxRow[pi])  longMaxRow[pi]  = lv;
            if (sv > shortMaxRow[pi]) shortMaxRow[pi] = sv;
            longSumRow[pi]  += lv;
            shortSumRow[pi] += sv;
            if (lv > 0) longHits[pi]  += 1;
            if (sv > 0) shortHits[pi] += 1;
          }
        }
        // 存活闸门：最后一列为 0 的价位 = 已被扫断/从未有墙 → 清零出局，
        // 保证 S↑/L↓ 标线和警报只锚定"当前还活着"的清算墙。
        {
          const lastLr = (Tlen > 0 && d.longMatrix[Tlen - 1])  || [];
          const lastSr = (Tlen > 0 && d.shortMatrix[Tlen - 1]) || [];
          for (let pi = 0; pi < Plen; pi += 1) {
            if (!(lastLr[pi] > 0)) { longMaxRow[pi] = 0;  longSumRow[pi] = 0;  longHits[pi] = 0; }
            if (!(lastSr[pi] > 0)) { shortMaxRow[pi] = 0; shortSumRow[pi] = 0; shortHits[pi] = 0; }
          }
        }
        // 优先用主图 SSE 推送的最新 K 线 close 作为 mid（更新最高频），
        // 否则退回 fetch 时刻的 d.midPrice 快照。这样在价格剧烈波动时主峰
        // 的"上方/下方"边界能跟着价格走，避免出现"S 标到了 mid 下方"的错位。
        let mid = null;
        try {
          if (Array.isArray(lastCandles) && lastCandles.length) {
            const v = Number(lastCandles[lastCandles.length - 1].close);
            if (Number.isFinite(v) && v > 0) mid = v;
          }
        } catch (_) { /* noop */ }
        if (mid == null && Number.isFinite(d.midPrice)) mid = d.midPrice;

        // 3-tap 平滑：减少 priceBucket 切割造成的"亮带边缘 vs 中心"漂移。
        // 一条"粗黄线"通常跨越 3-5 个相邻 bucket，argmax 在原始 row 上跑
        // 容易选到亮带边缘的小尖峰；在平滑后的 row 上跑会更倾向选中心。
        // 平滑只用来定位（argmax），显示的强度数值仍引用原始 row 的真实值
        // —— 这样 tooltip 数值 / 标签数值依然严格一致。
        function _smooth3(row) {
          const n = row.length;
          if (n < 3) return row.slice();
          const out = new Array(n);
          out[0]     = row[0] * 0.75 + row[1] * 0.25;
          out[n - 1] = row[n - 1] * 0.75 + row[n - 2] * 0.25;
          for (let i = 1; i < n - 1; i += 1) {
            out[i] = row[i - 1] * 0.25 + row[i] * 0.5 + row[i + 1] * 0.25;
          }
          return out;
        }

        // 多头主峰：在 longRow 里找 mid 下方 argmax
        // 空头主峰：在 shortRow 里找 mid 上方 argmax
        // 注意 long/short 是两套独立矩阵，不能用同一个数组算两侧。
        // refRow 是用来定位（argmax）的数组（通常是平滑后的），
        // valRow 是用来取数值的数组（原始 row，与 tooltip 一致）。
        function _argmaxLong(refRow, valRow) {
          let arg = -1, refMax = 0;
          for (let pi = 0; pi < Plen; pi += 1) {
            const v = refRow[pi];
            if (!(v > 0)) continue;
            if (mid != null && d.prices[pi] >= mid) continue;
            if (v > refMax) { refMax = v; arg = pi; }
          }
          if (arg < 0) for (let pi = 0; pi < Plen; pi += 1) {
            if (refRow[pi] > refMax) { refMax = refRow[pi]; arg = pi; }
          }
          return { arg, max: arg >= 0 ? (valRow[arg] || 0) : 0 };
        }
        function _argmaxShort(refRow, valRow) {
          let arg = -1, refMax = 0;
          for (let pi = 0; pi < Plen; pi += 1) {
            const v = refRow[pi];
            if (!(v > 0)) continue;
            if (mid != null && d.prices[pi] <= mid) continue;
            if (v > refMax) { refMax = v; arg = pi; }
          }
          if (arg < 0) for (let pi = 0; pi < Plen; pi += 1) {
            if (refRow[pi] > refMax) { refMax = refRow[pi]; arg = pi; }
          }
          return { arg, max: arg >= 0 ? (valRow[arg] || 0) : 0 };
        }
        // MAX 主峰定位 = "持续度加权 row-max" 的 3-tap 平滑后 argmax。
        // 持续度因子 = 1 + α × √(hits / T)，hits = 该价位非零时间桶数：
        //   • 单瞬尖峰   hits=1,  T=96 → 因子 ≈ 1.15（基本不被推高）
        //   • 半窗亮带   hits=48, T=96 → 因子 ≈ 2.06
        //   • 满窗亮带   hits=96, T=96 → 因子 ≈ 2.50
        // sqrt 曲线在中段比 ln 更陡，能稳定让"亮+长"胜过"很亮+单瞬"。
        // α=1.5 校准点：
        //   • 700/长带(70桶)  胜过 1000/单瞬(5桶)   ✓ 解决用户反馈的视觉错位
        //   • 800/中度(80桶)  胜过 1000/中度(30桶)  ✓ 长带优先
        //   • 100/弱长(96桶)  输给 800/中等(20桶)   ✓ 弱噪声不会反客为主
        //   • 700/长带(70桶)  仍输给 3000/极强尖峰   ✓ 真信号能压倒
        // 显示的强度数值仍取该位置的原始 row-max（与 tooltip 严格一致）。
        // SUM 主峰按"整窗累积深度"选位，不加持续度（row-sum 已自带时间维度）。
        const PERSIST_ALPHA = 1.5;
        const persistRow = (maxRow, hits) => {
          const out = new Array(Plen);
          const denom = Math.max(1, Tlen);
          for (let pi = 0; pi < Plen; pi += 1) {
            const persist = 1 + PERSIST_ALPHA * Math.sqrt(hits[pi] / denom);
            out[pi] = maxRow[pi] * persist;
          }
          return out;
        };
        const longMaxScored  = persistRow(longMaxRow,  longHits);
        const shortMaxScored = persistRow(shortMaxRow, shortHits);
        const longMaxSmooth  = _smooth3(longMaxScored);
        const shortMaxSmooth = _smooth3(shortMaxScored);
        const longSumSmooth  = _smooth3(longSumRow);
        const shortSumSmooth = _smooth3(shortSumRow);
        const maxLongPeak  = _argmaxLong(longMaxSmooth,   longMaxRow);
        const maxShortPeak = _argmaxShort(shortMaxSmooth, shortMaxRow);
        const sumLongPeak  = _argmaxLong(longSumSmooth,   longSumRow);
        const sumShortPeak = _argmaxShort(shortSumSmooth, shortSumRow);

        const fmtMoneyShort = (v) => v >= 1e9
          ? (v / 1e9).toFixed(2) + 'B'
          : v >= 1e6 ? (v / 1e6).toFixed(2) + 'M'
          : v >= 1e3 ? (v / 1e3).toFixed(2) + 'K' : v.toFixed(0);
        const drawPeak = (pi, totalVal, sideTag, opts) => {
          if (pi < 0 || !(totalVal > 0)) return;
          const price = d.prices[pi];
          if (!Number.isFinite(price)) return;
          const yPeak = oy + ph * (1 - (price - d.priceMin) / priceSpan);
          if (yPeak < oy - 0.5 || yPeak > oy + ph + 0.5) return;
          const isSum = opts && opts.kind === 'sum';
          ctx.save();
          ctx.shadowColor = 'rgba(0,0,0,0.85)';
          ctx.shadowBlur = 4;
          ctx.strokeStyle = isSum ? '#ff9800' : '#ffeb3b';
          ctx.lineWidth = isSum ? 1.5 : 2;
          if (isSum) ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(ox, Math.round(yPeak) + 0.5);
          ctx.lineTo(ox + pw, Math.round(yPeak) + 0.5);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.shadowBlur = 0;
          ctx.font = 'bold 10px ui-monospace, SFMono-Regular, Menlo, monospace';
          const tagText = `${sideTag} ${priceFmt(price)} · ${fmtMoneyShort(totalVal)}`;
          const tagW = ctx.measureText(tagText).width + 8;
          // SUM 标签放右侧，避免与 MAX 标签重叠
          const tagX = isSum ? (ox + pw - tagW - 4) : (ox + 4);
          const tagY = yPeak - 8;
          ctx.fillStyle = isSum ? 'rgba(255, 152, 0, 0.95)' : 'rgba(255, 235, 59, 0.95)';
          ctx.fillRect(tagX, tagY, tagW, 16);
          ctx.fillStyle = '#0b0e16';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(tagText, tagX + 4, tagY + 8);
          ctx.restore();
        };
        // MAX（实线 · 黄）：用户视觉感受 + 警报 / 信号触发墙
        // SUM（虚线 · 橙）：累计深度，仅参考；与 MAX 同价位时合并标签为 MAX=SUM
        // 表明该价位"既亮又长期堆积"（最强活墙 + 最深累积一致 → 最稳）
        const shortMerged = (sumShortPeak.arg === maxShortPeak.arg);
        const longMerged  = (sumLongPeak.arg  === maxLongPeak.arg);
        drawPeak(maxShortPeak.arg, maxShortPeak.max, shortMerged ? 'S↑ MAX=SUM' : 'S↑ MAX');
        drawPeak(maxLongPeak.arg,  maxLongPeak.max,  longMerged  ? 'L↓ MAX=SUM' : 'L↓ MAX');
        if (!shortMerged) {
          drawPeak(sumShortPeak.arg, sumShortPeak.max, 'S↑ SUM', { kind: 'sum' });
        }
        if (!longMerged) {
          drawPeak(sumLongPeak.arg, sumLongPeak.max, 'L↓ SUM', { kind: 'sum' });
        }
        // 警报 / 信号 / 跨越判定永远跟 row-max（活墙）
        state._peakLongPi  = maxLongPeak.arg;
        state._peakShortPi = maxShortPeak.arg;
        state._peakLongVal  = maxLongPeak.max;
        state._peakShortVal = maxShortPeak.max;
        // 把 SUM 主峰也存下来，给 meta / tooltip 显示用
        state._peakLongSumPi  = sumLongPeak.arg;
        state._peakShortSumPi = sumShortPeak.arg;
        state._peakLongSumVal  = sumLongPeak.max;
        state._peakShortSumVal = sumShortPeak.max;
        // 把 row-sum 数组也存下来供 tooltip 显示该价位的累计值
        state._longSumRow  = longSumRow;
        state._shortSumRow = shortSumRow;
      }

      // 时间刻度
      ctx.fillStyle = 'rgba(220,228,240,0.95)';
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      const timeTicks = Math.max(4, Math.min(10, Math.floor(pw / 90)));
      for (let i = 0; i <= timeTicks; i += 1) {
        const frac = i / timeTicks;
        const t = d.fromMs + (d.toMs - d.fromMs) * frac;
        const x = ox + pw * frac;
        const text = fmtBJTimeHMS(t).slice(0, 5);
        ctx.fillText(text, Math.max(ox + 14, Math.min(ox + pw - 14, x)), oy + ph + 4);
        ctx.strokeStyle = 'rgba(255,255,255,0.15)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 0.5, oy + ph);
        ctx.lineTo(x + 0.5, oy + ph + 3);
        ctx.stroke();
      }

      // K 线叠加 (CoinGlass 风格)：在热力图上画半透明蜡烛，让背景流动性可视化
      if (d.candles && d.candles.length && priceSpan > 0) {
        ctx.save();
        const span = d.toMs - d.fromMs;
        const xOf = (t) => ox + pw * ((t - d.fromMs) / span);
        const yOf = (p) => oy + ph * (1 - (p - d.priceMin) / priceSpan);
        const N = d.candles.length;
        // 蜡烛体宽：取相邻 candle 间距的 70%，再 clamp
        let stepPx;
        if (N >= 2) {
          stepPx = (xOf(d.candles[1].t) - xOf(d.candles[0].t));
        } else {
          stepPx = pw / Math.max(1, N);
        }
        const bodyW = Math.max(1, Math.min(12, stepPx * 0.7));
        const halfBody = bodyW / 2;
        const wickAlpha = 0.85;
        const bodyAlpha = 0.78;
        // CoinGlass 风格：青绿涨 / 品红跌；颜色比 K 线主图更暖更亮，
        // 因为要从紫色背景里凸显出来。
        const upStroke = `rgba(50, 230, 180, ${wickAlpha})`;
        const upFill   = `rgba(50, 230, 180, ${bodyAlpha})`;
        const dnStroke = `rgba(255, 90, 130, ${wickAlpha})`;
        const dnFill   = `rgba(255, 90, 130, ${bodyAlpha})`;
        for (let i = 0; i < N; i += 1) {
          const c = d.candles[i];
          if (!c || !Number.isFinite(c.o) || !Number.isFinite(c.c)) continue;
          // 越界裁剪：超出价格窗的不画
          if (c.h < d.priceMin || c.l > d.priceMax) continue;
          const cx = xOf(c.t + (i + 1 < N ? (d.candles[i + 1].t - c.t) / 2 : (c.t - d.candles[i - 1 < 0 ? 0 : i - 1].t) / 2));
          if (cx < ox - halfBody || cx > ox + pw + halfBody) continue;
          const isUp = c.c >= c.o;
          ctx.strokeStyle = isUp ? upStroke : dnStroke;
          ctx.fillStyle   = isUp ? upFill   : dnFill;
          // 影线
          const yH = yOf(Math.min(d.priceMax, c.h));
          const yL = yOf(Math.max(d.priceMin, c.l));
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(Math.round(cx) + 0.5, yH);
          ctx.lineTo(Math.round(cx) + 0.5, yL);
          ctx.stroke();
          // 实体
          const yO = yOf(c.o);
          const yC = yOf(c.c);
          const yTop = Math.min(yO, yC);
          const bodyH = Math.max(1, Math.abs(yC - yO));
          ctx.fillRect(Math.round(cx - halfBody), Math.round(yTop), Math.max(1, Math.round(bodyW)), Math.round(bodyH));
          if (bodyW >= 2) {
            ctx.strokeRect(Math.round(cx - halfBody) + 0.5, Math.round(yTop) + 0.5,
              Math.max(1, Math.round(bodyW)) - 1, Math.max(1, Math.round(bodyH)) - 1);
          }
        }
        ctx.restore();
      }

      // anchor 锁定线
      if (Number.isFinite(state.anchorMs) && state.anchorMs >= d.fromMs && state.anchorMs <= d.toMs) {
        const xA = ox + pw * ((state.anchorMs - d.fromMs) / (d.toMs - d.fromMs));
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 215, 0, 0.7)';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(xA, oy);
        ctx.lineTo(xA, oy + ph);
        ctx.stroke();
        ctx.restore();
      }

      // 边框
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1;
      ctx.strokeRect(ox + 0.5, oy + 0.5, pw, ph);

      // hover 高亮
      if (state.hoverCell) {
        const { ti, pi } = state.hoverCell;
        if (ti >= 0 && ti < T && pi >= 0 && pi < P) {
          const x = ox + ti * cellW;
          const y = oy + (P - 1 - pi) * cellH;
          ctx.save();
          ctx.strokeStyle = 'rgba(255,255,255,0.85)';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(x + 0.5, y + 0.5, cellW, cellH);
          ctx.restore();
        }
      }
    }

    function _hitTest(clientX, clientY) {
      const rect = canvas.getBoundingClientRect();
      const cx = clientX - rect.left;
      const cy = clientY - rect.top;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;
      const d = state.data;
      if (!d || cx < ox || cx > ox + pw || cy < oy || cy > oy + ph) return null;
      const T = d.times.length;
      const P = d.prices.length;
      if (!T || !P) return null;
      const ti = Math.floor((cx - ox) / (pw / T));
      const pi = P - 1 - Math.floor((cy - oy) / (ph / P));
      if (ti < 0 || ti >= T || pi < 0 || pi >= P) return null;
      return { ti, pi, cx, cy };
    }

    canvas.addEventListener('mousemove', (e) => {
      const hit = _hitTest(e.clientX, e.clientY);
      state.hoverCell = hit;
      if (!hit) {
        tooltip.style.display = 'none';
        _draw();
        return;
      }
      const d = state.data;
      const t  = d.times[hit.ti];
      const p  = d.prices[hit.pi];
      const lv = (d.longMatrix[hit.ti]  || [])[hit.pi] || 0;
      const sv = (d.shortMatrix[hit.ti] || [])[hit.pi] || 0;
      // 该价位（横向）在整个时间窗内的累计清算 USDT（row-sum）
      const lvSum = (state._longSumRow  || [])[hit.pi] || 0;
      const svSum = (state._shortSumRow || [])[hit.pi] || 0;
      const longLab  = '潜在多头清算 / Long liq pot.';
      const shortLab = '潜在空头清算 / Short liq pot.';
      // 顺序：空头在上、多头在下 —— 与 K 线热图上"空头墙在当前价上方、
      // 多头墙在当前价下方"的视觉直觉一致。
      // MAX = 当前格强度（图上视觉亮度）；SUM = 整窗该价位累积深度。
      tooltip.innerHTML =
        `<div><b>${fmtBJDateTime(t)} (UTC+8)</b></div>` +
        `<div>价格 / Price: <b>${p.toFixed(p >= 1000 ? 1 : 2)}</b></div>` +
        `<div>${shortLab}: <span style="color:#5dc863">${fmtMoney(sv)} USDT</span></div>` +
        `<div style="opacity:0.7;font-size:10px;margin-left:8px">└ SUM 累计: ${fmtMoney(svSum)} USDT</div>` +
        `<div>${longLab}: <span style="color:#fde725">${fmtMoney(lv)} USDT</span></div>` +
        `<div style="opacity:0.7;font-size:10px;margin-left:8px">└ SUM 累计: ${fmtMoney(lvSum)} USDT</div>` +
        `<div style="opacity:0.7;font-size:10px;margin-top:2px">合计本格: ${fmtMoney(lv + sv)} USDT</div>`;
      tooltip.style.display = 'block';
      const rect = canvas.parentElement.getBoundingClientRect();
      const ttX = Math.min(rect.width - 230, hit.cx + 10);
      const ttY = Math.max(0, hit.cy + 10);
      tooltip.style.left = ttX + 'px';
      tooltip.style.top  = ttY + 'px';
      _draw();
    });
    // 右键复制：根据鼠标位置反推 (price, time)，把价格 / OHLC / 清算数据
    // 一并放进自定义菜单，与主图右键菜单体感保持一致。
    canvas.addEventListener('contextmenu', (ev) => {
      const d = state.data;
      if (!d || !(d.priceMax > d.priceMin)) return;
      ev.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const cx = ev.clientX - rect.left;
      const cy = ev.clientY - rect.top;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;
      const inPlot = cx >= ox && cx <= ox + pw && cy >= oy && cy <= oy + ph;
      const meta = (typeof getMainSymbolMeta === 'function')
        ? getMainSymbolMeta()
        : { symbol: 'BTCUSDT', market: 'futures', interval: '' };
      const items = [];
      let header = `${meta.symbol} · ${meta.market} · 清算热力图 / Liq Heatmap`;
      if (inPlot) {
        const cursorPrice = d.priceMin + (d.priceMax - d.priceMin) * (1 - (cy - oy) / ph);
        if (Number.isFinite(cursorPrice)) {
          const v = fmtPrice(cursorPrice);
          items.push({ label: '光标价 / Cursor Price', value: v, display: v });
        }
        const tFrac = (cx - ox) / pw;
        const tMs = d.fromMs + (d.toMs - d.fromMs) * tFrac;
        if (Number.isFinite(tMs) && d.times && d.times.length) {
          let bestIdx = 0, bestDiff = Infinity;
          for (let i = 0; i < d.times.length; i += 1) {
            const diff = Math.abs(d.times[i] - tMs);
            if (diff < bestDiff) { bestDiff = diff; bestIdx = i; }
          }
          const ti = bestIdx;
          let pi = -1;
          if (d.prices && d.prices.length) {
            const pFrac = 1 - (cy - oy) / ph;
            pi = Math.round(pFrac * (d.prices.length - 1));
            if (pi < 0) pi = 0;
            if (pi >= d.prices.length) pi = d.prices.length - 1;
          }
          if (pi >= 0) {
            const lv = (d.longMatrix[ti]  || [])[pi] || 0;
            const sv = (d.shortMatrix[ti] || [])[pi] || 0;
            const longLab  = '潜在多头清算 / Long liq pot.';
            const shortLab = '潜在空头清算 / Short liq pot.';
            const fmt = (v) => v >= 1e6
              ? (v / 1e6).toFixed(2) + 'M'
              : v >= 1e3 ? (v / 1e3).toFixed(2) + 'K' : v.toFixed(0);
            if (lv > 0 || sv > 0) {
              items.push('divider');
              // 顺序与 tooltip 保持一致：空头在上、多头在下
              if (sv > 0) items.push({ label: shortLab, value: sv.toFixed(0), display: fmt(sv) + ' USDT' });
              if (lv > 0) items.push({ label: longLab,  value: lv.toFixed(0), display: fmt(lv) + ' USDT' });
              items.push({ label: '合计 / Total',    value: (lv + sv).toFixed(0), display: fmt(lv + sv) + ' USDT' });
            }
          }
          if (d.candles && d.candles.length) {
            let bestC = null, bestCD = Infinity;
            for (let i = 0; i < d.candles.length; i += 1) {
              const cd = Math.abs(d.candles[i].t - tMs);
              if (cd < bestCD) { bestCD = cd; bestC = d.candles[i]; }
            }
            if (bestC) {
              items.push('divider');
              items.push({ label: '开 / Open',  value: fmtPrice(bestC.o), display: fmtPrice(bestC.o) });
              items.push({ label: '高 / High',  value: fmtPrice(bestC.h), display: fmtPrice(bestC.h) });
              items.push({ label: '低 / Low',   value: fmtPrice(bestC.l), display: fmtPrice(bestC.l) });
              items.push({ label: '收 / Close', value: fmtPrice(bestC.c), display: fmtPrice(bestC.c) });
            }
          }
          if (typeof fmtBJShortDateTime === 'function') {
            header += ` · ${fmtBJShortDateTime(d.times[ti])} (UTC+8)`;
          }
        }
      }
      if (items.length === 0) {
        items.push({ label: '无价格 / No price', value: '', display: '-' });
      }
      if (typeof showCtxMenuAt === 'function') {
        showCtxMenuAt(ev.clientX, ev.clientY, items, header);
      }
    });
    canvas.addEventListener('wheel', () => {
      if (typeof hideCtxMenu === 'function') hideCtxMenu();
    }, { passive: true });
    canvas.addEventListener('mouseleave', () => {
      state.hoverCell = null;
      tooltip.style.display = 'none';
      _draw();
    });

    function _resolveRange() {
      const toMs = Number.isFinite(state.anchorMs) ? state.anchorMs : Date.now();
      const fromMs = toMs - state.windowMs;
      const span = toMs - fromMs;
      let bucketMs;
      if (span <= 15 * 60_000)        bucketMs = 60_000;
      else if (span <= 60 * 60_000)   bucketMs = 60_000;
      else if (span <= 4 * 3600_000)  bucketMs = 2 * 60_000;
      else if (span <= 12 * 3600_000) bucketMs = 10 * 60_000;
      else                            bucketMs = 15 * 60_000;
      return { fromMs, toMs, bucketMs };
    }

    function setLiqHeatmapAnchor(hoverMs) {
      const next = Number.isFinite(hoverMs) ? Math.floor(hoverMs) : null;
      if (next === state.anchorMs) return;
      state.anchorMs = next;
      state.lastFetchKey = '';
      scheduleFetch(next == null ? 0 : 200);
    }

    async function _fetch() {
      if (!_isApplicable()) return;
      const symbol = els.symbol.value.toUpperCase();
      const market = els.market.value;
      const key = `${symbol}|${market}|${state.windowMs}|${state.priceRange === 'auto' ? 'auto' : String(state.priceRange)}`;
      const now = Date.now();
      if (key === state.lastFetchKey && now - state.lastFetchAt < 5_000) return;
      state.lastFetchKey = key;
      state.lastFetchAt = now;
      try {
        // 预测性接口按 windowMs + 实时 now 自己定窗口（不接受 from/to）
        const params = new URLSearchParams({
          symbol, market,
          windowMs: String(state.windowMs)
        });
        if (state.priceRange !== 'auto') params.set('priceRange', String(state.priceRange));
        const url = `/api/predictive/liquidations?${params.toString()}`;
        const data = await fetchJsonSoft(url);
        if (!data) {
          _updateMeta('拉取失败 / Fetch failed');
          return;
        }
        state.data = data;
        _updateMeta();
        _draw();
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[liqHeatmap] fetch err:', err.message);
        _updateMeta('错误 / Error: ' + err.message);
      } finally {
        hideChartLoading(canvas.parentElement);
      }
    }

    function scheduleFetch(delay) {
      if (state.pendingTimer) clearTimeout(state.pendingTimer);
      state.pendingTimer = setTimeout(() => {
        state.pendingTimer = null;
        _fetch();
      }, delay != null ? delay : 250);
    }

    if (els.liqHeatmapWindow) {
      els.liqHeatmapWindow.addEventListener('change', () => {
        state.windowMs = Number(els.liqHeatmapWindow.value) || 86_400_000;
        state.lastFetchKey = '';
        if (typeof _clearCurrentMeasure === 'function') _clearCurrentMeasure();
        showChartLoading(canvas.parentElement);
        scheduleFetch(0);
      });
    }
    if (els.liqHeatmapRange) {
      els.liqHeatmapRange.addEventListener('change', () => {
        state.priceRange = _readPriceRange();
        state.lastFetchKey = '';
        if (typeof _clearCurrentMeasure === 'function') _clearCurrentMeasure();
        scheduleFetch(0);
      });
    }
    if (els.liqHeatmapThreshold || els.liqHeatmapThresholdVal) {
      const applyThreshold = (raw, { rewriteInput } = {}) => {
        const n = Number(raw);
        if (!Number.isFinite(n)) return false;
        state.threshold = Math.max(0, Math.min(0.99, n));
        const shown = state.threshold.toFixed(2);
        if (els.liqHeatmapThreshold) els.liqHeatmapThreshold.value = shown;
        if (rewriteInput && els.liqHeatmapThresholdVal) {
          els.liqHeatmapThresholdVal.value = shown;
        }
        // 纯本地过滤：不重新 fetch，仅重绘 + 同步 meta
        _updateMeta();
        _draw();
        return true;
      };
      if (els.liqHeatmapThreshold) {
        els.liqHeatmapThreshold.addEventListener('input', () => {
          applyThreshold(els.liqHeatmapThreshold.value, { rewriteInput: true });
        });
      }
      if (els.liqHeatmapThresholdVal) {
        // 输入中只更新图和滑块，不改写文本（否则小数点打不进去）
        els.liqHeatmapThresholdVal.addEventListener('input', () => {
          applyThreshold(els.liqHeatmapThresholdVal.value, { rewriteInput: false });
        });
        const commit = () => {
          if (!applyThreshold(els.liqHeatmapThresholdVal.value, { rewriteInput: true })) {
            applyThreshold(state.threshold, { rewriteInput: true });
          }
        };
        els.liqHeatmapThresholdVal.addEventListener('change', commit);
        els.liqHeatmapThresholdVal.addEventListener('blur', commit);
        els.liqHeatmapThresholdVal.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter') {
            ev.preventDefault();
            commit();
            els.liqHeatmapThresholdVal.blur();
          }
        });
      }
    }

    let _roPending = false;
    const ro = new ResizeObserver(() => {
      if (_roPending) return;
      _roPending = true;
      requestAnimationFrame(() => { _roPending = false; _resizeCanvas(); });
    });
    ro.observe(canvas.parentElement);
    window.addEventListener('resize', () => {
      if (_roPending) return;
      _roPending = true;
      requestAnimationFrame(() => { _roPending = false; _resizeCanvas(); });
    });

    // ============================================================
    // 测量工具 (Measurement tool · drag-to-measure on liq heatmap)
    // 与主图测量工具的体感一致：toggle 按钮 → 拖拽 → 显示 ΔPrice / ΔPct /
    // 时间长度。测量激活时禁用 hover tooltip 和右键菜单，避免冲突。
    // ============================================================
    const measureBtn = els.liqHeatmapMeasure;
    const measureLayer = document.createElement('div');
    measureLayer.style.cssText =
      'position:absolute;inset:0;display:none;z-index:7;pointer-events:none;';
    const measureCanvas = document.createElement('canvas');
    measureCanvas.style.cssText =
      'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;';
    measureLayer.appendChild(measureCanvas);
    const measureLabel = document.createElement('div');
    measureLabel.className = 'measure-label';
    measureLabel.style.display = 'none';
    measureLayer.appendChild(measureLabel);
    if (canvas.parentElement) canvas.parentElement.appendChild(measureLayer);

    let measureActive = false;
    let measureDrag = null;
    let measureResult = null;

    function _resizeMeasureCanvas() {
      const parent = canvas.parentElement;
      if (!parent) return;
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      if (w <= 0 || h <= 0) return;
      const dpr = window.devicePixelRatio || 1;
      measureCanvas.width = Math.round(w * dpr);
      measureCanvas.height = Math.round(h * dpr);
      measureCanvas.style.width = w + 'px';
      measureCanvas.style.height = h + 'px';
      const ctx2 = measureCanvas.getContext('2d');
      ctx2.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    function _clearMeasureCanvas() {
      const ctx2 = measureCanvas.getContext('2d');
      ctx2.setTransform(1, 0, 0, 1, 0, 0);
      ctx2.clearRect(0, 0, measureCanvas.width, measureCanvas.height);
      const dpr = window.devicePixelRatio || 1;
      ctx2.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function _measurePoint(ev) {
      const rect = canvas.getBoundingClientRect();
      const cx = ev.clientX - rect.left;
      const cy = ev.clientY - rect.top;
      const { x: ox, y: oy, w: pw, h: ph } = state.plot;
      const d = state.data;
      // clamp 到绘图区，防止边界外取到无意义价格
      const clampedCx = Math.max(ox, Math.min(ox + pw, cx));
      const clampedCy = Math.max(oy, Math.min(oy + ph, cy));
      let price = NaN, time = NaN;
      if (d && d.priceMax > d.priceMin) {
        price = d.priceMin + (d.priceMax - d.priceMin) * (1 - (clampedCy - oy) / ph);
      }
      if (d && d.toMs > d.fromMs) {
        time = d.fromMs + (d.toMs - d.fromMs) * ((clampedCx - ox) / pw);
      }
      // x/y 用相对 measureCanvas 的像素（与 canvas 的相对 parentElement 对齐）
      return { x: cx, y: cy, price, time };
    }

    function _drawMeasure(start, end) {
      _resizeMeasureCanvas();
      const ctx2 = measureCanvas.getContext('2d');
      const w = measureCanvas.width / (window.devicePixelRatio || 1);
      const h = measureCanvas.height / (window.devicePixelRatio || 1);
      ctx2.clearRect(0, 0, w, h);
      const x0 = Math.min(start.x, end.x);
      const x1 = Math.max(start.x, end.x);
      const y0 = Math.min(start.y, end.y);
      const y1 = Math.max(start.y, end.y);
      const isUp = end.price >= start.price;
      const fill = isUp ? 'rgba(74, 222, 128, 0.14)' : 'rgba(248, 113, 113, 0.14)';
      const stroke = isUp ? 'rgba(74, 222, 128, 0.95)' : 'rgba(248, 113, 113, 0.95)';
      ctx2.fillStyle = fill;
      ctx2.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx2.strokeStyle = stroke;
      ctx2.lineWidth = 1;
      ctx2.setLineDash([4, 3]);
      ctx2.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      ctx2.setLineDash([]);
      ctx2.lineWidth = 1.4;
      ctx2.beginPath();
      ctx2.moveTo(start.x, start.y);
      ctx2.lineTo(end.x, end.y);
      ctx2.stroke();
      ctx2.fillStyle = stroke;
      [[start.x, start.y], [end.x, end.y]].forEach(([px, py]) => {
        ctx2.beginPath();
        ctx2.arc(px, py, 3.5, 0, Math.PI * 2);
        ctx2.fill();
      });
    }

    function _fmtMeasureDuration(ms) {
      const s = Math.abs(Number(ms) / 1000 || 0);
      if (s < 60) return Math.round(s) + ' s';
      if (s < 3600) return (s / 60).toFixed(1) + ' min';
      if (s < 86400) return (s / 3600).toFixed(2) + ' h';
      return (s / 86400).toFixed(2) + ' d';
    }
    function _fmtSigned(n, digits) {
      const sign = n >= 0 ? '+' : '';
      return sign + Number(n).toFixed(digits);
    }
    function _measureFmtPrice(p) {
      if (!Number.isFinite(p)) return '-';
      const ap = Math.abs(p);
      const digits = ap >= 1000 ? 2 : ap >= 1 ? 4 : 6;
      return p.toFixed(digits);
    }

    function _updateMeasureLabel(start, end) {
      const dPrice = end.price - start.price;
      const pct = (Number.isFinite(start.price) && start.price !== 0)
        ? (dPrice / start.price) * 100 : 0;
      const dTimeMs = (Number.isFinite(end.time) && Number.isFinite(start.time))
        ? (end.time - start.time) : 0;
      const isUp = dPrice >= 0;
      const arrow = isUp ? '▲' : '▼';
      const color = isUp ? 'var(--accent)' : 'var(--accent-down)';
      const ap = Math.max(Math.abs(start.price || 0), Math.abs(end.price || 0));
      const digits = ap >= 1000 ? 2 : ap >= 1 ? 4 : 6;
      measureLabel.innerHTML =
        `<div class="ml-headline" style="color:${color}">`
          + `${arrow} ${_fmtSigned(dPrice, digits)} (${_fmtSigned(pct, 2)}%)`
        + `</div>`
        + `<div class="ml-row"><span class="ml-k">起 / From</span><span class="ml-v">${_measureFmtPrice(start.price)}</span></div>`
        + `<div class="ml-row"><span class="ml-k">止 / To</span><span class="ml-v">${_measureFmtPrice(end.price)}</span></div>`
        + `<div class="ml-row"><span class="ml-k">时长 / Duration</span><span class="ml-v">${_fmtMeasureDuration(dTimeMs)}</span></div>`
        + `<div class="ml-hint">Esc 清除 / clear · 再次点击按钮退出</div>`;
      measureLabel.style.display = 'block';
      measureLabel.style.left = '0px';
      measureLabel.style.top = '0px';
      const lr = measureLabel.getBoundingClientRect();
      const parent = canvas.parentElement;
      const cw = parent ? parent.clientWidth  : 800;
      const ch = parent ? parent.clientHeight : 400;
      const padX = 12, padY = 12;
      let lx = end.x + padX;
      let ly = end.y + padY;
      if (lx + lr.width  > cw - 4) lx = end.x - lr.width  - padX;
      if (ly + lr.height > ch - 4) ly = end.y - lr.height - padY;
      if (lx < 4) lx = 4;
      if (ly < 4) ly = 4;
      measureLabel.style.left = lx + 'px';
      measureLabel.style.top  = ly + 'px';
    }

    function _setMeasureActive(on) {
      measureActive = !!on;
      if (measureActive) {
        if (measureBtn) {
          measureBtn.classList.add('active');
          measureBtn.textContent = '📏 测量中 / Measuring';
        }
        measureLayer.style.display = 'block';
        measureLayer.style.pointerEvents = 'auto';
        measureLayer.style.cursor = 'crosshair';
      } else {
        if (measureBtn) {
          measureBtn.classList.remove('active');
          measureBtn.textContent = '📏 测量 / Measure';
        }
        measureLayer.style.pointerEvents = 'none';
        measureDrag = null;
        measureResult = null;
        _clearMeasureCanvas();
        measureLabel.style.display = 'none';
        measureLayer.style.display = 'none';
      }
    }
    function _clearCurrentMeasure() {
      measureDrag = null;
      measureResult = null;
      _clearMeasureCanvas();
      measureLabel.style.display = 'none';
    }

    if (measureBtn) {
      measureBtn.addEventListener('click', () => _setMeasureActive(!measureActive));
    }
    measureLayer.addEventListener('mousedown', (ev) => {
      if (!measureActive || ev.button !== 0) return;
      ev.preventDefault();
      _resizeMeasureCanvas();
      const start = _measurePoint(ev);
      if (!Number.isFinite(start.price)) return;
      measureDrag = { start, end: start };
      measureResult = null;
      _drawMeasure(start, start);
      _updateMeasureLabel(start, start);
    });
    measureLayer.addEventListener('mousemove', (ev) => {
      if (!measureActive || !measureDrag) return;
      const end = _measurePoint(ev);
      if (!Number.isFinite(end.price)) return;
      measureDrag.end = end;
      _drawMeasure(measureDrag.start, end);
      _updateMeasureLabel(measureDrag.start, end);
    });
    window.addEventListener('mouseup', (ev) => {
      if (!measureActive || !measureDrag) return;
      const end = _measurePoint(ev);
      if (Number.isFinite(end.price)) {
        measureDrag.end = end;
        _drawMeasure(measureDrag.start, end);
        _updateMeasureLabel(measureDrag.start, end);
      }
      measureResult = measureDrag;
      measureDrag = null;
    });
    document.addEventListener('keydown', (ev) => {
      if (ev.key !== 'Escape' || !measureActive) return;
      if (measureDrag || measureResult) _clearCurrentMeasure();
      else _setMeasureActive(false);
    });
    // resize 时清空（坐标系会变，旧像素位置已不可信）
    new ResizeObserver(() => { if (measureActive) _clearCurrentMeasure(); })
      .observe(canvas.parentElement);

    // ============================================================
    // 价格穿越警报 (Liquidation cross / reclaim alert · sound + Feishu)
    //
    // 两种独立事件 + 两种声音：
    //   • CROSS   — close 价穿过 peak 立即触发（破位事件 · 电子警报声）
    //                调 POST /api/alerts/liquidation-cross with eventType=cross
    //                ⚠️ 所有窗口（15m/1h/4h/24h）都会触发
    //   • RECLAIM — 价格穿过 peak 后又回到墙的另一侧（sweep + reclaim · 三段上扬音）
    //                long  reclaim = 跌穿 L↓ 又收回墙上方 → 做多机会
    //                short reclaim = 涨穿 S↑ 又回到墙下方 → 做空机会
    //                调 POST /api/alerts/liquidation-cross with eventType=reclaim
    //                ⭐ 仅在选 4h / 24h 窗口时触发 — 短窗口的局部小 peak 频繁漂移
    //                   导致 reclaim 假信号过多；4h/24h peak 才有结构性意义。
    //                   窗口列表见 RECLAIM_ALLOWED_WINDOWS_MS 常量。
    //
    // 关键特性 — 瞬间插针捕获：
    //   reclaim 检测同时用 K 线 high/low + close 轮询，所以即使整个"插针 + 收回"
    //   发生在一根 K 线内（close 价没穿过 peak），只要 K 线 high/low 已经穿了 + 当前
    //   close 已经回到墙内，就会触发 INSTANT-RECLAIM（同采样周期 idle→swept→reclaim
    //   一步到位，不必等下一次轮询）。这是修复"500ms 之间错过插针"的关键 bug。
    //
    // 配置（balanced 默认 · 都可在 .env 里覆盖前端常量重打包后生效）：
    //   - 穿越深度阈值: 0.1%（防抖，避免毛刺触发）
    //   - 回到墙内阈值: 0.1%
    //   - 穿越窗口: 30 分钟（跨多根 K 线 sweep 的最大间隔；单根 K 线插针不受此限）
    //   - 同 side 同事件冷却: cross 5 分钟、reclaim 10 分钟（前后端各一道）
    //
    // peak 价位 / 索引发生显著漂移时（重新计算主峰），自动重置该 side 的状态机。
    // 用户切换窗口（如 24h → 1h）时也会自动重置 reclaim 状态机，避免跨窗口污染。
    // ============================================================
    // 警报状态、声音、按钮渲染由 IIFE 顶层的全局警报模块统一管理；
    // 这里只把本卡的按钮注册进去即可。
    const ALERT_COOLDOWN_MS = 5 * 60_000;
    const RECLAIM_COOLDOWN_MS = 10 * 60_000;
    const RECLAIM_PIERCE_MIN_PCT = 0.001;   // 0.1%
    const RECLAIM_BACK_MIN_PCT   = 0.001;   // 0.1%
    const RECLAIM_WINDOW_MS      = 30 * 60_000;
    const PEAK_DRIFT_RESET_PCT   = 0.0015;  // 0.15% 漂移视为新 peak，重置状态机
    // 仅以下清算热图窗口启用 reclaim 警报：4h / 24h
    // 短窗口（15m / 1h）的主峰是噪音级局部高低，reclaim 假信号过多。
    // 用户若想放宽，把对应毫秒值加进这个 Set 即可（例如加 3_600_000 = 启用 1h）。
    const RECLAIM_ALLOWED_WINDOWS_MS = new Set([4 * 3600_000, 24 * 3600_000]);
    function _isReclaimWindowAllowed(windowMs) {
      return RECLAIM_ALLOWED_WINDOWS_MS.has(Number(windowMs));
    }
    // 上次见到的窗口，用来检测用户切换 → 重置 reclaim 状态机
    let _lastSeenWindowMs = null;
    let _alertPrevPrice = null;
    const _alertLastAt = { long: 0, short: 0 };
    const _reclaimLastAt = { long: 0, short: 0 };
    // 每个 side 的 reclaim 状态机
    //   phase: 'idle' | 'swept'
    //   pierceExt: 'long' = 穿越达到的最低价 · 'short' = 穿越达到的最高价
    //   pierceAt:  swept 进入时间戳（用于窗口超时）
    //   trackedPeak: 进入 swept 时锁定的 peak（用来检测 peak 漂移后重置）
    const _reclaimState = {
      long:  { phase: 'idle', pierceExt: null, pierceAt: 0, trackedPeak: null },
      short: { phase: 'idle', pierceExt: null, pierceAt: 0, trackedPeak: null }
    };
    const _playAlertSound = playAlertSound; // 别名，下方调用代码不变
    registerAlertButton(els.liqHeatmapAlert);

    function _readLatestPrice() {
      // 优先用主图 SSE 推送的最新 K 线 close（更新最高频）；
      // 其次用本图 d.midPrice（fetch 时同步的当前价，频率较低）
      try {
        if (Array.isArray(lastCandles) && lastCandles.length) {
          const c = lastCandles[lastCandles.length - 1];
          const v = Number(c && c.close);
          if (Number.isFinite(v) && v > 0) return v;
        }
      } catch (_) {}
      const d = state.data;
      const m = d && Number(d.midPrice);
      return Number.isFinite(m) && m > 0 ? m : null;
    }

    // 读最新 K 线的完整 OHLC，用于检测"瞬间插针"——单根 K 线内 high/low
    // 已穿越 peak 但 close 已收回的场景，仅靠 close 价的轮询会漏掉。
    function _readLatestCandle() {
      try {
        if (Array.isArray(lastCandles) && lastCandles.length) {
          const c = lastCandles[lastCandles.length - 1];
          const open = Number(c && c.open);
          const high = Number(c && c.high);
          const low = Number(c && c.low);
          const close = Number(c && c.close);
          const time = Number(c && (c.openTime || c.time)) || 0;
          if (Number.isFinite(high) && Number.isFinite(low) && Number.isFinite(close)) {
            return { open, high, low, close, time };
          }
        }
      } catch (_) {}
      return null;
    }

    async function _triggerAlarm(side, peakPrice, peakValue, prevPrice, curPrice) {
      // eslint-disable-next-line no-console
      console.log(`[liq-cross] cross ${side} @ ${peakPrice} · ${prevPrice} → ${curPrice}`);
      _playAlertSound();
      const sym = els.symbol ? els.symbol.value.toUpperCase() : 'BTCUSDT';
      const market = els.market ? els.market.value : 'futures';
      const body = {
        symbol: sym, market,
        mode: 'predicted',
        eventType: 'cross',
        side,
        peakPrice, peakValue,
        prevPrice, curPrice,
        crossDirection: curPrice < prevPrice ? 'down' : 'up',
        timestamp: Date.now()
      };
      try {
        await fetch('/api/alerts/liquidation-cross', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[liq-cross] feishu push failed:', err.message);
      }
    }

    async function _triggerReclaim(side, peakPrice, peakValue, prevPrice, curPrice, sweepExt, sweepAt) {
      const pierceDepthPct = peakPrice > 0 ? Math.abs((peakPrice - sweepExt) / peakPrice) : 0;
      const reclaimDepthPct = peakPrice > 0 ? Math.abs((curPrice - peakPrice) / peakPrice) : 0;
      const sweepDurationMs = Date.now() - (sweepAt || Date.now());
      // eslint-disable-next-line no-console
      console.log(
        `[liq-cross] RECLAIM ${side} @ peak=${peakPrice} ext=${sweepExt} ` +
        `cur=${curPrice} pierce=${(pierceDepthPct * 100).toFixed(3)}% ` +
        `back=${(reclaimDepthPct * 100).toFixed(3)}% dur=${Math.round(sweepDurationMs / 1000)}s`
      );
      playReclaimSound();
      const sym = els.symbol ? els.symbol.value.toUpperCase() : 'BTCUSDT';
      const market = els.market ? els.market.value : 'futures';
      const body = {
        symbol: sym, market,
        mode: 'predicted',
        eventType: 'reclaim',
        side,
        peakPrice, peakValue,
        prevPrice, curPrice,
        crossDirection: curPrice < prevPrice ? 'down' : 'up',
        sweepExtreme: sweepExt,
        sweepDurationMs,
        pierceDepthPct,
        reclaimDepthPct,
        timestamp: Date.now()
      };
      try {
        await fetch('/api/alerts/liquidation-cross', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[liq-reclaim] feishu push failed:', err.message);
      }
    }

    function _resetReclaim(side) {
      _reclaimState[side].phase = 'idle';
      _reclaimState[side].pierceExt = null;
      _reclaimState[side].pierceAt = 0;
      _reclaimState[side].trackedPeak = null;
    }

    function _checkCross() {
      if (!isAlertEnabled()) { _alertPrevPrice = _readLatestPrice(); return; }
      const d = state.data;
      if (!d || !d.prices || !d.prices.length) return;
      const cur = _readLatestPrice();
      if (!Number.isFinite(cur)) return;
      const prev = _alertPrevPrice;
      _alertPrevPrice = cur;
      // 注意：close 价相等（prev === cur）也要继续 reclaim 检测，因为
      // 同一根 K 线内可能有"插针 + 收回"，即使 close 没变，K 线 high/low 已经穿了。
      // 仅当 cur 无效时跳过。
      const candle = _readLatestCandle();
      const now = Date.now();
      // cross 警报仍需要 prev 不同于 cur（破位事件本质是 close 价变化）
      const hasPrev = Number.isFinite(prev) && prev !== cur;

      // 窗口切换检测：用户切到不同窗口（如 24h → 1h）→ 重置 reclaim 状态机
      // 避免上一个窗口的 swept 状态污染下一个窗口的判断
      const curWindowMs = Number(state.windowMs) || 0;
      if (_lastSeenWindowMs !== null && _lastSeenWindowMs !== curWindowMs) {
        _resetReclaim('long');
        _resetReclaim('short');
        // eslint-disable-next-line no-console
        console.log(`[liq-reclaim] window changed ${_lastSeenWindowMs} → ${curWindowMs}, state reset`);
      }
      _lastSeenWindowMs = curWindowMs;
      // reclaim 仅在 4h / 24h 窗口启用（短窗口的 peak 是局部噪音）
      const reclaimEnabled = _isReclaimWindowAllowed(curWindowMs);

      const checkOne = (side, pi, val) => {
        if (pi == null || pi < 0) {
          _resetReclaim(side); // peak 失效，重置状态机
          return;
        }
        const peak = d.prices[pi];
        if (!Number.isFinite(peak) || peak <= 0) {
          _resetReclaim(side);
          return;
        }
        const peakVal = val || 0;

        // ---- 1. Reclaim 状态机（先处理，独立于 cross 警报）----
        // 短窗口（15m/1h）不启用 reclaim：保证状态机始终 idle，跳过整段
        if (!reclaimEnabled) {
          if (_reclaimState[side].phase !== 'idle') _resetReclaim(side);
        } else {
        const st = _reclaimState[side];
        // peak 显著漂移（重算主峰位置）→ 当前 swept 状态作废
        if (st.trackedPeak != null && peak > 0) {
          const drift = Math.abs(peak - st.trackedPeak) / peak;
          if (drift > PEAK_DRIFT_RESET_PCT) _resetReclaim(side);
        }
        // 超时清空（30 分钟未 reclaim）
        if (st.phase === 'swept' && now - st.pierceAt > RECLAIM_WINDOW_MS) {
          _resetReclaim(side);
        }

        // 触发 reclaim 的统一出口（含冷却检查 + 重置状态）
        const _fireReclaim = (sideKey, pierceExt, pierceAt, prevPx, curPx) => {
          if (now - (_reclaimLastAt[sideKey] || 0) >= RECLAIM_COOLDOWN_MS) {
            _reclaimLastAt[sideKey] = now;
            _triggerReclaim(sideKey, peak, peakVal, prevPx, curPx, pierceExt, pierceAt);
          }
          _resetReclaim(sideKey);
        };

        if (side === 'long') {
          // L↓ : 跌穿 peak * (1 - PIERCE_MIN_PCT) 以下；收回 peak * (1 + BACK_MIN_PCT) 以上
          // 关键修复：综合 K 线 low + prev/cur close → 用真实最低价（捕获瞬间插针）
          const pierceThreshold = peak * (1 - RECLAIM_PIERCE_MIN_PCT);
          const reclaimThreshold = peak * (1 + RECLAIM_BACK_MIN_PCT);
          const candleLow = candle ? candle.low : Infinity;
          const closeLow = hasPrev ? Math.min(prev, cur) : cur;
          const effectiveLow = Math.min(candleLow, closeLow);

          if (st.phase === 'idle') {
            if (Number.isFinite(effectiveLow) && effectiveLow <= pierceThreshold) {
              st.phase = 'swept';
              st.pierceExt = effectiveLow;
              st.pierceAt = now;
              st.trackedPeak = peak;
              // eslint-disable-next-line no-console
              console.log(`[liq-reclaim] long SWEPT peak=${peak} ext=${effectiveLow}`);
              // ⭐ 同采样周期检测：插针 + 收回都已发生（瞬间插针场景）
              if (cur >= reclaimThreshold) {
                // eslint-disable-next-line no-console
                console.log(`[liq-reclaim] long INSTANT-RECLAIM same tick · cur=${cur} >= ${reclaimThreshold.toFixed(2)}`);
                _fireReclaim('long', effectiveLow, now, hasPrev ? prev : cur, cur);
                return;
              }
            }
          } else { // swept
            if (Number.isFinite(effectiveLow) && effectiveLow < (st.pierceExt != null ? st.pierceExt : Infinity)) {
              st.pierceExt = effectiveLow; // 继续往下扎，更新最深
            }
            if (cur >= reclaimThreshold) {
              _fireReclaim('long', st.pierceExt, st.pierceAt, hasPrev ? prev : cur, cur);
              return;
            }
          }
        } else { // short
          // S↑ : 涨穿 peak * (1 + PIERCE_MIN_PCT) 以上；收回 peak * (1 - BACK_MIN_PCT) 以下
          const pierceThreshold = peak * (1 + RECLAIM_PIERCE_MIN_PCT);
          const reclaimThreshold = peak * (1 - RECLAIM_BACK_MIN_PCT);
          const candleHigh = candle ? candle.high : -Infinity;
          const closeHigh = hasPrev ? Math.max(prev, cur) : cur;
          const effectiveHigh = Math.max(candleHigh, closeHigh);

          if (st.phase === 'idle') {
            if (Number.isFinite(effectiveHigh) && effectiveHigh >= pierceThreshold) {
              st.phase = 'swept';
              st.pierceExt = effectiveHigh;
              st.pierceAt = now;
              st.trackedPeak = peak;
              // eslint-disable-next-line no-console
              console.log(`[liq-reclaim] short SWEPT peak=${peak} ext=${effectiveHigh}`);
              if (cur <= reclaimThreshold) {
                // eslint-disable-next-line no-console
                console.log(`[liq-reclaim] short INSTANT-RECLAIM same tick · cur=${cur} <= ${reclaimThreshold.toFixed(2)}`);
                _fireReclaim('short', effectiveHigh, now, hasPrev ? prev : cur, cur);
                return;
              }
            }
          } else { // swept
            if (Number.isFinite(effectiveHigh) && effectiveHigh > (st.pierceExt != null ? st.pierceExt : -Infinity)) {
              st.pierceExt = effectiveHigh;
            }
            if (cur <= reclaimThreshold) {
              _fireReclaim('short', st.pierceExt, st.pierceAt, hasPrev ? prev : cur, cur);
              return;
            }
          }
        }
        } // end if(reclaimEnabled)

        // ---- 2. 原 cross 警报（保留：close 价穿过 peak 立即触发）----
        // cross 仍需要 close 价变化（破位事件 = close 真的穿过 peak）
        if (!hasPrev) return;
        const crossed = (prev < peak && cur >= peak) || (prev > peak && cur <= peak);
        if (!crossed) return;
        if (now - (_alertLastAt[side] || 0) < ALERT_COOLDOWN_MS) return;
        _alertLastAt[side] = now;
        _triggerAlarm(side, peak, peakVal, prev, cur);
      };
      checkOne('long',  state._peakLongPi,  state._peakLongVal);
      checkOne('short', state._peakShortPi, state._peakShortVal);
    }
    // 500ms 轮询：足够快响应主图价格跳动，cpu 占用可忽略
    setInterval(_checkCross, 500);

    // 周期 30s 自动刷新（清算事件比快照高频，重要事件不容延迟）
    setInterval(() => scheduleFetch(0), 30_000);

    _setVisibility();
    _resizeCanvas();
    scheduleFetch(800);

    return {
      refresh: () => scheduleFetch(0),
      setAnchor: setLiqHeatmapAnchor,
      resize: () => _resizeCanvas(),
      onSymbolMarketChange: () => {
        _setVisibility();
        state.data = null;
        state.lastFetchKey = '';
        state.anchorMs = null;
        if (typeof _clearCurrentMeasure === 'function') _clearCurrentMeasure();
        _draw();
        if (_isApplicable()) scheduleFetch(300);
      }
    };
  })();

  // ---- 十字准星 (Crosshair) 跨图联动 ----
  // 一个图上 hover → 其他图同位置画一根垂直线，方便对照同一时刻的指标。
  // (Sync crosshair across main / volume / CVD / OI charts so hovering one
  //  shows where you are on the others.)
  //
  // 实现要点：
  //   - subscribeCrosshairMove 在鼠标进入 / 移动时回调 param={time, point, seriesData}
  //   - 鼠标离开图表时 param.time === undefined → 调 clearCrosshairPosition
  //   - setCrosshairPosition(price, time, series) 中的 price 只决定水平线位置，
  //     我们关心的是垂直线（时间线），所以传该图自己 series 上的 price 即可：
  //       * 主图 candleSeries：取 close
  //       * histogram/area/line series：取 value
  //     没数据时退化用 0，不会报错（4.1.x 接受任意数）。
  //   - 用 _syncingCrosshair 防回环
  const _crossPairs = [
    { chart: mainChart,   series: candleSeries,  container: els.mainChart  },
    { chart: volumeChart, series: volumeSeries,  container: els.volumePane },
    { chart: cvdChart,    series: cvdSeries,     container: els.cvdPane    },
    { chart: oiChart,     series: oiCandleSeries, container: els.oiPane    }
  ];
  let _syncingCrosshair = false;
  // 跟踪鼠标"真实"是否 hover 在 chart 上。Lightweight Charts 在数据 update
  // (SSE 推送新 K 线)时会触发 subscribeCrosshairMove(param) with
  // param.time === undefined —— 即使鼠标仍在 chart 上没动。把这种"伪 leave"
  // 当真 leave 处理就会让 hover 中的 crosshair 莫名消失。
  // 解法：清理逻辑改由 mouseleave 触发，cross-move 只处理 time != null 的真移动。
  const _hoveredCharts = new WeakSet();
  // 缓存每个 chart 当前鼠标位置（time + price）。任何 series API（setData /
  // update / setMarkers / createPriceLine ...）都可能让 lightweight-charts
  // 内部 crosshair 状态被重置 → hover 中虚线消失。
  const _lastHover = new WeakMap(); // chart → { time, price, series }
  // 同时缓存原生鼠标坐标，用于派发 mousemove 让 lightweight-charts 走原生
  // hover 路径 —— setCrosshairPosition 只画十字线和"价格 label"，**不画 X 轴
  // 上的时间 label**（这是 lightweight-charts 4.x 已知行为：programmatic
  // crosshair 不带 time-axis label）。要让时间 label 也显示，必须模拟原生
  // mousemove 事件。
  const _lastMousePos = new WeakMap(); // container → { clientX, clientY }

  function _dispatchMouseMoveTo(container, pos) {
    if (!container || !pos) return;
    // 派发到 container 内**所有** canvas 元素，让事件冒泡到 lightweight-charts
    // 内部 paneWidget 的 mouseEventHandler。dispatch 到 container 本身不行，
    // 因为冒泡是从内向外 —— container 是最外层，不会触发其子孙的 listener。
    const canvases = container.querySelectorAll('canvas');
    const targets = canvases.length ? Array.from(canvases) : [container];
    for (const target of targets) {
      try {
        target.dispatchEvent(new MouseEvent('mousemove', {
          clientX: pos.clientX,
          clientY: pos.clientY,
          button: 0,
          buttons: 0,
          bubbles: true,
          cancelable: true,
          view: window
        }));
      } catch (_) { /* noop */ }
    }
  }

  // 数据更新后恢复 hover crosshair：先用 setCrosshairPosition 立即画上十字线
  // 和价格 label；再用 rAF 推到下一帧 dispatch mousemove —— 因为如果在本帧
  // setData 期间立刻 dispatch，lightweight-charts 下一次内部 redraw 会把
  // hover state 又清掉（这是上一轮"一闪就消失"的真因）。
  // 不用持续心跳是为了避免每次心跳触发 redraw 引起的视觉闪烁。
  let _restorePending = false;
  function _restoreHoverCrosshairs() {
    for (const t of _crossPairs) {
      if (!_hoveredCharts.has(t.chart)) continue;
      const last = _lastHover.get(t.chart);
      if (last) {
        try { t.chart.setCrosshairPosition(last.price, last.time, last.series); }
        catch (_) { /* time/price 不在数据范围 */ }
      }
    }
    if (_restorePending) return;
    _restorePending = true;
    requestAnimationFrame(() => {
      _restorePending = false;
      for (const t of _crossPairs) {
        if (!_hoveredCharts.has(t.chart)) continue;
        _dispatchMouseMoveTo(t.container, _lastMousePos.get(t.container));
      }
    });
  }

  function _seriesPriceAt(pair, param) {
    const sd = param.seriesData;
    if (!sd) return 0;
    // Map 或 plain object 都兼容
    let v;
    if (typeof sd.get === 'function') v = sd.get(pair.series);
    else v = sd[pair.series];
    if (!v) return 0;
    if (Number.isFinite(v.close)) return v.close;
    if (Number.isFinite(v.value)) return v.value;
    return 0;
  }

  function _onChartMouseLeave(srcChart) {
    _lastHover.delete(srcChart);
    if (_syncingCrosshair) return;
    _syncingCrosshair = true;
    try {
      for (const t of _crossPairs) {
        if (t.chart === srcChart) continue;
        try { t.chart.clearCrosshairPosition(); } catch (_) { /* noop */ }
      }
      // 主图离开 → 复位 baseline 锚点 (取消热图的联动)
      if (srcChart === mainChart) {
        if (typeof setObBaselineHoverAnchor === 'function') setObBaselineHoverAnchor(null);
        // if (heatmap && heatmap.setAnchor) heatmap.setAnchor(null);
        // if (liqHeatmap && liqHeatmap.setAnchor) liqHeatmap.setAnchor(null);
      }
    } finally {
      _syncingCrosshair = false;
    }
  }

  for (const src of _crossPairs) {
    if (src.container) {
      src.container.addEventListener('mouseenter', () => _hoveredCharts.add(src.chart));
      src.container.addEventListener('mouseleave', () => {
        _hoveredCharts.delete(src.chart);
        _lastMousePos.delete(src.container);
        _onChartMouseLeave(src.chart);
      });
      // 缓存最后真实鼠标位置（仅 trusted 事件，避免我们派发的 untrusted
      // mousemove 反过来更新缓存）。用于渲染后恢复 hover state。
      src.container.addEventListener('mousemove', (ev) => {
        if (!ev.isTrusted) return;
        _lastMousePos.set(src.container, { clientX: ev.clientX, clientY: ev.clientY });
      });
    }
    src.chart.subscribeCrosshairMove((param) => {
      if (_syncingCrosshair) return;
      // 关键：只在"有时间"时同步。time == null 通常是数据 update 引发的
      // 伪 callback，鼠标可能仍 hover 在 chart 上 —— 此时不能 clear，否则
      // 主图静止 hover 时会因 SSE 推送 K 线而 crosshair 消失。
      if (!param || param.time == null) return;
      const price = _seriesPriceAt(src, param);
      // 缓存最后 hover 位置，供 _restoreHoverCrosshairs 恢复用
      _lastHover.set(src.chart, { time: param.time, price, series: src.series });
      _syncingCrosshair = true;
      try {
        const time = param.time;
        for (const t of _crossPairs) {
          if (t === src) continue;
          try { t.chart.setCrosshairPosition(price, time, t.series); }
          catch (_) { /* 目标图无该时间数据 */ }
          // 同时缓存联动到的 chart 当前位置
          _lastHover.set(t.chart, { time, price, series: t.series });
        }
        // 主图 hover → 把订单簿基线锁到该时刻 (取消热图的联动)
        // time 单位是秒（lightweight-charts UTC seconds），转回毫秒
        if (src.chart === mainChart) {
          const ms = Number(time) * 1000;
          if (typeof setObBaselineHoverAnchor === 'function') setObBaselineHoverAnchor(ms);
          // if (heatmap && heatmap.setAnchor) heatmap.setAnchor(ms);
          // if (liqHeatmap && liqHeatmap.setAnchor) liqHeatmap.setAnchor(ms);
        }
      } finally {
        _syncingCrosshair = false;
      }
    });
  }

  // ---- 订单簿深度图 (Order book · 累积阶梯深度图 / cumulative depth chart) ----
  // 设计 (Design)：
  //   X 轴 = 价格 (linear scale)，Y 轴 = 从最优档累积的名义额 (USDT)。
  //   两条阶梯曲线：
  //     - bids 从 best bid 出发往低价方向累积，stepped:'before' 渲染为
  //       右高左低的"绿色买墙"。
  //     - asks 从 best ask 出发往高价方向累积，stepped:'after' 渲染为
  //       左低右高的"红色卖墙"。
  //   这种图天然适合展示 100~500+ 档，远比逐档条形图易读。
  // (Replaced the per-level horizontal bar with a classic depth-book curve
  //  so hundreds of levels render cleanly and price scale stays continuous.)
  let orderbookChart = null;
  // mid 价垂直参考线 plugin（订单簿专用）
  // (Vertical mid-price guide line plugin for the order-book chart only.)
  const obMidLinePlugin = {
    id: 'obMidLine',
    afterDatasetsDraw(chart, _args, opts) {
      const mid = opts && opts.mid;
      if (mid == null || !Number.isFinite(mid)) return;
      const xScale = chart.scales.x;
      const yScale = chart.scales.y;
      if (!xScale || !yScale) return;
      const x = xScale.getPixelForValue(mid);
      if (x < xScale.left || x > xScale.right) return;
      const ctx = chart.ctx;
      ctx.save();
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.65)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(x, yScale.top);
      ctx.lineTo(x, yScale.bottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(250, 204, 21, 0.85)';
      ctx.font = '10px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('mid ' + Number(mid).toLocaleString('en-US', { maximumFractionDigits: 2 }),
                   x, yScale.top + 10);
      ctx.restore();
    }
  };

  function ensureOrderbookChart() {
    if (orderbookChart) return orderbookChart;
    const ctx = els.orderbookCanvas.getContext('2d');
    orderbookChart = new Chart(ctx, {
      type: 'line',
      data: {
        // 数据集索引（顺序对外保证）：
        //   0: 当前买单累计  (Current bids · 实线 + 半透明绿)
        //   1: 当前卖单累计  (Current asks · 实线 + 半透明红)
        //   2: 基线买单累计  (Baseline bids · 虚线 + 无填充)
        //   3: 基线卖单累计  (Baseline asks · 虚线 + 无填充)
        // 渲染顺序：先画基线在底，再叠加当前 → 当前线高于基线 = 增厚（看墙堆出）
        datasets: [
          {
            label: '当前买单累计 / Bids now (USDT)',
            data: [],
            backgroundColor: 'rgba(74, 222, 128, 0.18)',
            borderColor: 'rgba(74, 222, 128, 0.95)',
            borderWidth: 1.5,
            stepped: 'before',
            fill: 'origin',
            pointRadius: 0,
            pointHoverRadius: 3,
            tension: 0,
            order: 1
          },
          {
            label: '当前卖单累计 / Asks now (USDT)',
            data: [],
            backgroundColor: 'rgba(248, 113, 113, 0.18)',
            borderColor: 'rgba(248, 113, 113, 0.95)',
            borderWidth: 1.5,
            stepped: 'after',
            fill: 'origin',
            pointRadius: 0,
            pointHoverRadius: 3,
            tension: 0,
            order: 1
          },
          {
            label: '基线买单 / Bids baseline',
            data: [],
            borderColor: 'rgba(74, 222, 128, 0.55)',
            borderWidth: 1,
            borderDash: [4, 3],
            stepped: 'before',
            fill: false,
            pointRadius: 0,
            pointHoverRadius: 0,
            tension: 0,
            order: 0,
            hidden: true
          },
          {
            label: '基线卖单 / Asks baseline',
            data: [],
            borderColor: 'rgba(248, 113, 113, 0.55)',
            borderWidth: 1,
            borderDash: [4, 3],
            stepped: 'after',
            fill: false,
            pointRadius: 0,
            pointHoverRadius: 0,
            tension: 0,
            order: 0,
            hidden: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        parsing: false,
        animation: false,
        normalized: true,
        interaction: { mode: 'nearest', axis: 'x', intersect: false },
        plugins: {
          legend: { labels: { color: '#9aa7b8', boxWidth: 12 } },
          tooltip: {
            mode: 'nearest',
            axis: 'x',
            intersect: false,
            backgroundColor: '#11161f',
            borderColor: '#1f2837',
            borderWidth: 1,
            titleColor: '#e6edf3',
            bodyColor: '#9aa7b8',
            callbacks: {
              title: (items) => items.length
                ? '价位 / Price: ' + Number(items[0].parsed.x)
                    .toLocaleString('en-US', { maximumFractionDigits: 4 })
                : '',
              label: (item) =>
                `${item.dataset.label}: ${Number(item.parsed.y)
                  .toLocaleString('en-US', { maximumFractionDigits: 0 })}`
            }
          },
          obMidLine: { mid: null }
        },
        scales: {
          x: {
            type: 'linear',
            ticks: {
              color: '#5e6b7c',
              maxTicksLimit: 6,
              callback: (v) => Number(v).toLocaleString('en-US', { maximumFractionDigits: 2 })
            },
            grid: { color: '#1f2837' }
          },
          y: {
            type: 'linear',
            beginAtZero: true,
            ticks: {
              color: '#9aa7b8',
              callback: (v) => {
                const n = Number(v);
                if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
                if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
                return n.toFixed(0);
              }
            },
            grid: { color: '#1f2837' }
          }
        }
      },
      plugins: [obMidLinePlugin]
    });
    return orderbookChart;
  }

  // ---- 工具函数 (Helpers) ----
  function setStatus(text, isError = false) {
    els.status.textContent = text;
    els.status.classList.toggle('error', !!isError);
  }

  function fmt(n, digits = 2) {
    if (n === null || n === undefined || Number.isNaN(n)) return '-';
    if (Math.abs(n) >= 1000) return Number(n).toLocaleString('en-US', { maximumFractionDigits: digits });
    if (Math.abs(n) < 0.01 && n !== 0) return Number(n).toExponential(2);
    return Number(n).toFixed(digits);
  }

  function fmtPct(n, digits = 2) {
    if (n === null || n === undefined || Number.isNaN(n)) return '-';
    return (Number(n) * 100).toFixed(digits) + '%';
  }

  function toLwSeconds(ms) {
    return Math.floor(Number(ms) / 1000);
  }

  /*
   * Viridis colormap helper —— CoinGlass 风格的"紫→蓝→青→绿→黄"渐变。
   * 输入 t ∈ [0,1]，返回 'rgb(r,g,b)' 字符串。
   * 5 个锚点之间线性插值。Alpha 由调用方决定（背景已是深紫，色块用 1.0）。
   */
  const VIRIDIS_STOPS = [
    [0.00,  68,  1, 84],
    [0.25,  59, 82, 139],
    [0.50,  33, 144, 140],
    [0.75,  93, 200,  99],
    [1.00, 253, 231,  37]
  ];
  function viridisColor(t, alpha) {
    if (!Number.isFinite(t)) return 'rgba(68,1,84,0)';
    const x = Math.max(0, Math.min(1, t));
    let i = 0;
    while (i < VIRIDIS_STOPS.length - 1 && x > VIRIDIS_STOPS[i + 1][0]) i += 1;
    const [t0, r0, g0, b0] = VIRIDIS_STOPS[i];
    const [t1, r1, g1, b1] = VIRIDIS_STOPS[Math.min(i + 1, VIRIDIS_STOPS.length - 1)];
    const span = (t1 - t0) || 1;
    const f = (x - t0) / span;
    const r = Math.round(r0 + (r1 - r0) * f);
    const g = Math.round(g0 + (g1 - g0) * f);
    const b = Math.round(b0 + (b1 - b0) * f);
    if (Number.isFinite(alpha)) return `rgba(${r},${g},${b},${alpha.toFixed(3)})`;
    return `rgb(${r},${g},${b})`;
  }
  /** 把 (value, normMax) 映射成 viridis 色 + log 拉伸 */
  function viridisFromValue(value, normMax) {
    if (!(value > 0) || !(normMax > 0)) return null;
    // sqrt 色阶（CoinGlass 风格）：让低/中等强度也能映射到青蓝/青绿，
    // 使整张图有"晕染层次"而非只有少数亮点。
    // log 太"陡"会把所有信号挤到顶端；线性又把弱信号压到 0；sqrt 是折中。
    let t;
    if (value <= normMax) {
      t = Math.sqrt(value / normMax);
      t = 0.08 + 0.82 * t; // 0.08~0.90，基线 0.08 让有信号格 ≠ 纯紫背景
    } else {
      const extra = Math.min(1, Math.sqrt(value / normMax) - 1);
      t = Math.min(1, 0.90 + 0.10 * extra);
    }
    return viridisColor(t, 0.95);
  }

  // 容错获取 (Soft): 失败返回 null + console.warn，不影响其它面板。
  // 把上一轮失败原因暂存到 fetchJsonSoft.lastErrors，方便状态栏展示。
  // (Soft fetch: returns null on failure and stashes the reason on
  //  fetchJsonSoft.lastErrors so the status bar can display it.)
  fetchJsonSoft.lastErrors = {};
  fetchJsonSoft.cacheInfo = {};
  // 单次软请求超时（毫秒）。超过即 abort，避免请求挂死到网关 504 才返回
  // HTML 错误页（那会让 r.json() 抛 "Unexpected token '<'" 这种难懂的报错）。
  const SOFT_FETCH_TIMEOUT_MS = 15000;
  // 瞬时网关错误（502/504 非 JSON 响应、网络断连）在同一轮内立即重试一次，
  // 而不是把"部分失败"晾给用户等下一轮 10s 轮询。仅重试网关/网络层错误；
  // 应用层 success:false 与 15s abort（说明链路本身很慢）不重试。
  const SOFT_FETCH_RETRY_DELAY_MS = 600;
  async function fetchJsonSoft(url, _attempt = 0) {
    const canRetry = _attempt < 1;
    const retry = async () => {
      await new Promise((resolve) => setTimeout(resolve, SOFT_FETCH_RETRY_DELAY_MS));
      return fetchJsonSoft(url, _attempt + 1);
    };
    const ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), SOFT_FETCH_TIMEOUT_MS) : null;
    try {
      const r = await fetch(url, ctrl ? { signal: ctrl.signal } : undefined);
      // 先看响应是不是 JSON：网关超时 / 502 / 504 常返回 HTML 错误页，
      // 直接 r.json() 会抛 "Unexpected token '<'"。这里给出更可读的提示。
      const ct = (r.headers.get('content-type') || '').toLowerCase();
      if (!ct.includes('json')) {
        const msg = `HTTP ${r.status} 非 JSON 响应（可能超时/网关错误，稍后自动重试）`;
        // eslint-disable-next-line no-console
        console.warn('soft-fetch non-json:', url, msg, canRetry ? '→ retrying' : '');
        if (canRetry) return retry();
        fetchJsonSoft.lastErrors[url] = msg;
        return null;
      }
      const j = await r.json();
      if (r.status === 401) {
        window.dispatchEvent(new Event('payment-access-revoked'));
        return null;
      }
      if (!j || !j.success) {
        // eslint-disable-next-line no-console
        console.warn('soft-fetch failed:', url, j && j.error);
        fetchJsonSoft.lastErrors[url] = (j && j.error) || `HTTP ${r.status}`;
        return null;
      }
      delete fetchJsonSoft.lastErrors[url];
      fetchJsonSoft.cacheInfo[url] = j.cache || null;
      return j.data;
    } catch (err) {
      const isAbort = err && err.name === 'AbortError';
      if (!isAbort && canRetry) {
        // eslint-disable-next-line no-console
        console.warn('soft-fetch threw:', url, (err && err.message) || 'fetch error', '→ retrying');
        return retry();
      }
      const msg = isAbort
        ? `请求超时 (>${SOFT_FETCH_TIMEOUT_MS / 1000}s，已中止，稍后自动重试)`
        : (err && err.message) || 'fetch error';
      // eslint-disable-next-line no-console
      console.warn('soft-fetch threw:', url, msg);
      fetchJsonSoft.lastErrors[url] = msg;
      return null;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  // ---- 主图右键菜单 / 复制价格 (Main chart context menu) ----
  // 缓存最近一次渲染的 K 线，便于右键时定位 OHLC
  // (Cache last-rendered candles so context menu can show OHLC for the
  //  bar under the cursor.)
  let ctxMenuEl = null;
  let copyToastEl = null;
  let copyToastTimer = null;

  function getMainSymbolMeta() {
    return {
      symbol: (els.symbol.value || '').trim().toUpperCase() || 'BTCUSDT',
      market: els.market.value,
      interval: els.interval.value
    };
  }

  // 自动决定价格小数位：>=1000 取 2 位，>=1 取 4 位，更小取 6 位
  // (Auto-pick price precision so BTC/SOL/小币 都得到合理的显示。)
  function pickPriceDigits(price) {
    if (price == null || !Number.isFinite(price)) return 4;
    const ap = Math.abs(price);
    if (ap >= 1000) return 2;
    if (ap >= 1) return 4;
    if (ap >= 0.01) return 5;
    return 8;
  }
  function fmtPrice(price) {
    if (price == null || !Number.isFinite(price)) return '-';
    return Number(price).toFixed(pickPriceDigits(price));
  }

  async function copyToClipboard(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) { /* fall through */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (_) {
      return false;
    }
  }

  function showCopyToast(text, isError = false) {
    if (!copyToastEl) {
      copyToastEl = document.createElement('div');
      copyToastEl.className = 'copy-toast';
      document.body.appendChild(copyToastEl);
    }
    copyToastEl.textContent = text;
    copyToastEl.classList.toggle('error', !!isError);
    void copyToastEl.offsetWidth;
    copyToastEl.classList.add('show');
    if (copyToastTimer) clearTimeout(copyToastTimer);
    copyToastTimer = setTimeout(() => {
      if (copyToastEl) copyToastEl.classList.remove('show');
    }, 1400);
  }

  function hideCtxMenu() {
    if (ctxMenuEl && ctxMenuEl.parentNode) {
      ctxMenuEl.parentNode.removeChild(ctxMenuEl);
    }
    ctxMenuEl = null;
  }

  function findCandleByTime(timeSec) {
    if (!Array.isArray(lastCandles) || lastCandles.length === 0 || timeSec == null) {
      return null;
    }
    let best = null;
    let bestDiff = Infinity;
    for (const c of lastCandles) {
      const ts = toLwSeconds(c.openTime);
      const d = Math.abs(ts - timeSec);
      if (d < bestDiff) { bestDiff = d; best = c; }
    }
    return best;
  }

  function buildCtxMenu(items, header) {
    hideCtxMenu();
    const menu = document.createElement('div');
    menu.className = 'ctx-menu';
    if (header) {
      const h = document.createElement('div');
      h.className = 'ctx-header';
      h.textContent = header;
      menu.appendChild(h);
    }
    items.forEach((it, idx) => {
      if (it === 'divider') {
        const d = document.createElement('div');
        d.className = 'ctx-divider';
        menu.appendChild(d);
        return;
      }
      const row = document.createElement('div');
      row.className = 'ctx-item';
      row.innerHTML =
        `<span class="ctx-label">${it.label}</span>` +
        `<span class="ctx-value">${it.display ?? it.value}</span>`;
      row.addEventListener('click', async () => {
        const ok = await copyToClipboard(String(it.value));
        if (ok) showCopyToast(`已复制 / Copied · ${it.label}: ${it.display ?? it.value}`);
        else showCopyToast('复制失败 / Copy failed', true);
        hideCtxMenu();
      });
      menu.appendChild(row);
    });
    return menu;
  }

  function showCtxMenuAt(clientX, clientY, items, header) {
    const menu = buildCtxMenu(items, header);
    menu.style.left = '0px';
    menu.style.top = '0px';
    menu.style.visibility = 'hidden';
    document.body.appendChild(menu);
    ctxMenuEl = menu;
    const rect = menu.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let x = clientX;
    let y = clientY;
    if (x + rect.width + 8 > vw) x = vw - rect.width - 8;
    if (y + rect.height + 8 > vh) y = vh - rect.height - 8;
    if (x < 4) x = 4;
    if (y < 4) y = 4;
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
    menu.style.visibility = 'visible';
  }

  function onMainChartContextMenu(ev) {
    ev.preventDefault();
    const rect = els.mainChart.getBoundingClientRect();
    const x = ev.clientX - rect.left;
    const y = ev.clientY - rect.top;

    // Y 轴坐标 -> 价格（鼠标位置对应的纵轴价位）
    const cursorPrice = candleSeries.coordinateToPrice(y);
    // X 轴坐标 -> 时间，找到对应 K 线
    const ts = mainChart.timeScale().coordinateToTime(x);
    const candle = findCandleByTime(typeof ts === 'number' ? ts : null);

    const meta = getMainSymbolMeta();
    const items = [];
    if (cursorPrice != null && Number.isFinite(cursorPrice)) {
      const v = Number(cursorPrice).toFixed(pickPriceDigits(cursorPrice));
      items.push({
        label: '光标价 / Cursor Price',
        value: v,
        display: v
      });
    }
    if (candle) {
      items.push('divider');
      items.push({ label: '开 / Open',  value: fmtPrice(candle.open),  display: fmtPrice(candle.open) });
      items.push({ label: '高 / High',  value: fmtPrice(candle.high),  display: fmtPrice(candle.high) });
      items.push({ label: '低 / Low',   value: fmtPrice(candle.low),   display: fmtPrice(candle.low) });
      items.push({ label: '收 / Close', value: fmtPrice(candle.close), display: fmtPrice(candle.close) });
      if (candle.vwap != null && Number.isFinite(candle.vwap)) {
        items.push({ label: 'VWAP', value: fmtPrice(candle.vwap), display: fmtPrice(candle.vwap) });
      }
    }
    if (items.length === 0) {
      // 没有可用价格（比如鼠标在空白区域），仍然给一个提示项
      items.push({ label: '无价格 / No price', value: '', display: '-' });
    }

    let header = `${meta.symbol} · ${meta.market} · ${meta.interval}`;
    if (candle) {
      header += ` · ${fmtBJShortDateTime(candle.openTime)} (UTC+8)`;
    }
    showCtxMenuAt(ev.clientX, ev.clientY, items, header);
  }

  els.mainChart.addEventListener('contextmenu', onMainChartContextMenu);
  // 在菜单上右键也阻止默认浏览器菜单（保持自定义菜单一致）
  document.addEventListener('contextmenu', (e) => {
    if (ctxMenuEl && ctxMenuEl.contains(e.target)) e.preventDefault();
  });
  // 任意位置点击 / Esc / 滚动 / 失焦 都关闭菜单
  document.addEventListener('mousedown', (e) => {
    if (ctxMenuEl && !ctxMenuEl.contains(e.target)) hideCtxMenu();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideCtxMenu();
  });
  window.addEventListener('blur', hideCtxMenu);
  window.addEventListener('resize', hideCtxMenu);
  els.mainChart.addEventListener('wheel', hideCtxMenu, { passive: true });

  // ============================================================
  // 测量工具 (Measurement tool · drag-to-measure on main chart)
  // ============================================================
  const measureBtn = document.getElementById('measure-toggle');

  // 在主图容器内创建覆盖层 (overlay layer) ----------------------
  // mainChart 容器的 position 已由 lightweight-charts 内部设置成 relative
  const measureLayer = document.createElement('div');
  measureLayer.style.cssText =
    'position:absolute;inset:0;display:none;z-index:5;pointer-events:none;';

  const measureCanvas = document.createElement('canvas');
  measureCanvas.style.cssText =
    'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;';
  measureLayer.appendChild(measureCanvas);

  const measureLabel = document.createElement('div');
  measureLabel.className = 'measure-label';
  measureLabel.style.display = 'none';
  measureLayer.appendChild(measureLabel);

  els.mainChart.appendChild(measureLayer);

  let measureActive = false;
  let measureDrag = null;     // 拖拽中的测量
  let measureResult = null;   // 上一次完成的测量（用于 resize 重绘）

  // 把 K 线周期映射成秒，用于估算"几根 K 线"
  // (Map interval string to seconds so we can compute bar counts.)
  function intervalToSeconds(intervalStr) {
    const m = String(intervalStr || '').match(/^(\d+)([smhdw])$/i);
    if (!m) return 3600;
    const n = Number(m[1]);
    const unit = m[2].toLowerCase();
    const mult = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[unit] || 60;
    return n * mult;
  }

  function fmtDuration(seconds) {
    const s = Math.abs(Number(seconds) || 0);
    if (s < 60) return Math.round(s) + ' s';
    if (s < 3600) return (s / 60).toFixed(1) + ' min';
    if (s < 86400) return (s / 3600).toFixed(2) + ' h';
    return (s / 86400).toFixed(2) + ' d';
  }

  function fmtSigned(n, digits) {
    const sign = n >= 0 ? '+' : '';
    return sign + Number(n).toFixed(digits);
  }

  function resizeMeasureCanvas() {
    const w = els.mainChart.clientWidth;
    const h = els.mainChart.clientHeight;
    if (w <= 0 || h <= 0) return;
    const dpr = window.devicePixelRatio || 1;
    measureCanvas.width = Math.round(w * dpr);
    measureCanvas.height = Math.round(h * dpr);
    measureCanvas.style.width = w + 'px';
    measureCanvas.style.height = h + 'px';
    const ctx = measureCanvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function clearMeasureCanvas() {
    const ctx = measureCanvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, measureCanvas.width, measureCanvas.height);
    const dpr = window.devicePixelRatio || 1;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function drawMeasure(start, end) {
    resizeMeasureCanvas();
    const ctx = measureCanvas.getContext('2d');
    const w = els.mainChart.clientWidth;
    const h = els.mainChart.clientHeight;
    ctx.clearRect(0, 0, w, h);

    const x0 = Math.min(start.x, end.x);
    const x1 = Math.max(start.x, end.x);
    const y0 = Math.min(start.y, end.y);
    const y1 = Math.max(start.y, end.y);

    const isUp = end.price >= start.price;
    const fill = isUp ? 'rgba(74, 222, 128, 0.14)' : 'rgba(248, 113, 113, 0.14)';
    const stroke = isUp ? 'rgba(74, 222, 128, 0.85)' : 'rgba(248, 113, 113, 0.85)';

    ctx.fillStyle = fill;
    ctx.fillRect(x0, y0, x1 - x0, y1 - y0);

    ctx.strokeStyle = stroke;
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
    ctx.setLineDash([]);

    // 起点->终点 实线连线
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();

    // 起止圆点
    ctx.fillStyle = stroke;
    [[start.x, start.y], [end.x, end.y]].forEach(([px, py]) => {
      ctx.beginPath();
      ctx.arc(px, py, 3.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  function updateMeasureLabel(start, end) {
    const dPrice = end.price - start.price;
    const pct = start.price !== 0 && Number.isFinite(start.price)
      ? (dPrice / start.price) * 100
      : 0;
    const intervalSec = intervalToSeconds(els.interval.value);
    const dTimeSec = (end.time != null && start.time != null)
      ? (end.time - start.time)
      : 0;
    const bars = intervalSec ? Math.round(Math.abs(dTimeSec) / intervalSec) : 0;

    const isUp = dPrice >= 0;
    const arrow = isUp ? '▲' : '▼';
    const color = isUp ? 'var(--accent)' : 'var(--accent-down)';
    const digits = pickPriceDigits(Math.max(Math.abs(start.price || 0), Math.abs(end.price || 0)));

    measureLabel.innerHTML = `
      <div class="ml-headline" style="color:${color}">
        ${arrow} ${fmtSigned(dPrice, digits)} (${fmtSigned(pct, 2)}%)
      </div>
      <div class="ml-row"><span class="ml-k">起 / From</span><span class="ml-v">${fmtPrice(start.price)}</span></div>
      <div class="ml-row"><span class="ml-k">止 / To</span><span class="ml-v">${fmtPrice(end.price)}</span></div>
      <div class="ml-row"><span class="ml-k">时长 / Duration</span><span class="ml-v">${fmtDuration(dTimeSec)}</span></div>
      <div class="ml-row"><span class="ml-k">K 线 / Bars</span><span class="ml-v">${bars}</span></div>
      <div class="ml-hint">Esc 清除 / clear · 再次点击按钮退出</div>
    `;

    // 定位标签：跟随终点，避免越界
    measureLabel.style.display = 'block';
    measureLabel.style.left = '0px';
    measureLabel.style.top = '0px';
    const lr = measureLabel.getBoundingClientRect();
    const cw = els.mainChart.clientWidth;
    const ch = els.mainChart.clientHeight;
    const padX = 12, padY = 12;
    let lx = end.x + padX;
    let ly = end.y + padY;
    if (lx + lr.width > cw - 4) lx = end.x - lr.width - padX;
    if (ly + lr.height > ch - 4) ly = end.y - lr.height - padY;
    if (lx < 4) lx = 4;
    if (ly < 4) ly = 4;
    measureLabel.style.left = lx + 'px';
    measureLabel.style.top = ly + 'px';
  }

  function getMeasurePoint(ev) {
    const rect = els.mainChart.getBoundingClientRect();
    const x = Math.max(0, Math.min(els.mainChart.clientWidth, ev.clientX - rect.left));
    const y = Math.max(0, Math.min(els.mainChart.clientHeight, ev.clientY - rect.top));
    const price = candleSeries.coordinateToPrice(y);
    const t = mainChart.timeScale().coordinateToTime(x);
    return { x, y, price: Number(price), time: typeof t === 'number' ? t : null };
  }

  function setMeasureActive(on) {
    measureActive = !!on;
    if (measureActive) {
      measureBtn.classList.add('active');
      measureBtn.textContent = '📏 测量中 / Measuring';
      measureLayer.style.display = 'block';
      measureLayer.style.pointerEvents = 'auto';
      measureLayer.style.cursor = 'crosshair';
      // 暂停 chart 的拖拽与缩放，避免与测量手势冲突
      mainChart.applyOptions({ handleScroll: false, handleScale: false });
    } else {
      measureBtn.classList.remove('active');
      measureBtn.textContent = '📏 测量 / Measure';
      measureLayer.style.pointerEvents = 'none';
      // 退出时清除残留并隐藏覆盖层
      measureDrag = null;
      measureResult = null;
      clearMeasureCanvas();
      measureLabel.style.display = 'none';
      measureLayer.style.display = 'none';
      mainChart.applyOptions({ handleScroll: true, handleScale: true });
    }
  }

  function clearCurrentMeasure() {
    measureDrag = null;
    measureResult = null;
    clearMeasureCanvas();
    measureLabel.style.display = 'none';
  }

  if (measureBtn) {
    measureBtn.addEventListener('click', () => setMeasureActive(!measureActive));
  }

  measureLayer.addEventListener('mousedown', (ev) => {
    if (!measureActive || ev.button !== 0) return;
    ev.preventDefault();
    resizeMeasureCanvas();
    const start = getMeasurePoint(ev);
    if (!Number.isFinite(start.price)) return;
    measureDrag = { start, end: start };
    measureResult = null;
    drawMeasure(start, start);
    updateMeasureLabel(start, start);
  });

  measureLayer.addEventListener('mousemove', (ev) => {
    if (!measureActive || !measureDrag) return;
    const end = getMeasurePoint(ev);
    if (!Number.isFinite(end.price)) return;
    measureDrag.end = end;
    drawMeasure(measureDrag.start, end);
    updateMeasureLabel(measureDrag.start, end);
  });

  // 在 window 上监听 mouseup，让用户在覆盖层外松开也能完成测量
  window.addEventListener('mouseup', (ev) => {
    if (!measureActive || !measureDrag) return;
    const end = getMeasurePoint(ev);
    if (Number.isFinite(end.price)) {
      measureDrag.end = end;
      drawMeasure(measureDrag.start, end);
      updateMeasureLabel(measureDrag.start, end);
    }
    measureResult = measureDrag;
    measureDrag = null;
  });

  document.addEventListener('keydown', (ev) => {
    if (ev.key !== 'Escape') return;
    if (!measureActive) return;
    if (measureDrag || measureResult) {
      clearCurrentMeasure();
    } else {
      setMeasureActive(false);
    }
  });

  window.addEventListener('resize', () => {
    if (!measureActive) return;
    // resize 后图表坐标系会变，旧测量像素位置已不可信，直接清空。
    clearCurrentMeasure();
    resizeMeasureCanvas();
  });

  // 切换交易对/市场/周期/刷新数据时清空测量结果，避免错位
  if (els.symbol)   els.symbol.addEventListener('change', clearCurrentMeasure);
  if (els.market)   els.market.addEventListener('change', clearCurrentMeasure);
  if (els.interval) els.interval.addEventListener('change', clearCurrentMeasure);
  if (els.refresh)  els.refresh.addEventListener('click', clearCurrentMeasure);

  // 主图是否已经做过初次 fitContent。
  // 切换 symbol/market/interval 或点刷新时 reset，让下次 render 重新 fit；
  // 实时增量更新（SSE 推送）不会 reset，保留用户拖动 / 缩放的位置。
  // (Track whether we've fitted the time scale already; live updates must
  //  not reset the user's drag/zoom state.)
  let chartsFitted = false;
  function markChartsNeedFit() { chartsFitted = false; }

  // 主图「还原适应窗口」按钮：手动缩放/拖动后一键恢复
  //   - 左右：timeScale().fitContent() 让所有 K 线进入可视区
  //   - 上下：rightPriceScale.autoScale=true 让 Y 轴按可见 K 线高低价自适应
  //     （用户手动拖动 Y 轴会切成手动模式，这里重置回 autoScale）
  if (els.fitContentBtn) {
    els.fitContentBtn.addEventListener('click', () => {
      try {
        mainChart.priceScale('right').applyOptions({
          autoScale: true,
          scaleMargins: { top: 0.1, bottom: 0.1 }
        });
      } catch (_) { /* noop */ }
      try { mainChart.timeScale().fitContent(); } catch (_) { /* noop */ }
      try { syncSubChartsToMain(); } catch (_) { /* noop */ }
    });
  }

  // ---- 各种渲染器 (Renderers) ----

  // 增量 series 更新 helper：避免每次 SSE 推送都用 setData 全量重设
  // —— setData 会清掉 lightweight-charts 的内部 crosshair，导致 hover
  // 中坐标轴标签消失（用户报告"hover x坐标只要鼠标停下就消失"的根因）。
  // 策略：
  //   - 数据集换了（第一根 time 不同）or 长度跨度大 → setData
  //   - 同长度 → update 最后一根
  //   - 多 1 根 → update 倒数第 2 根（settle）+ update 最后一根（new）
  //   - 多 2-5 根（间隔补帧）→ 逐根 update
  // 用 WeakMap 给每个 series 独立缓存 prev，自动 GC。
  const _seriesPrev = new WeakMap();
  function _smartUpdateSeries(series, points) {
    if (!series) return;
    const prev = _seriesPrev.get(series);
    const newLen = points.length;
    if (newLen === 0) {
      series.setData([]);
      _seriesPrev.set(series, { firstTime: null, len: 0 });
      return;
    }
    const newFirstTime = points[0].time;
    if (!prev || prev.firstTime !== newFirstTime || prev.len === 0) {
      series.setData(points);
    } else {
      const diff = newLen - prev.len;
      if (diff === 0) {
        series.update(points[newLen - 1]);
      } else if (diff >= 1 && diff <= 5) {
        // 倒数第 (diff+1) 根开始逐根 update：settled 的 + 新加的
        const start = Math.max(0, prev.len - 1);
        for (let i = start; i < newLen; i += 1) {
          try { series.update(points[i]); } catch (_) { /* time 顺序异常时退化全量 */
            series.setData(points); break;
          }
        }
      } else {
        series.setData(points);
      }
    }
    _seriesPrev.set(series, { firstTime: newFirstTime, len: newLen });
  }

  // ============================================================
  // 历史 K 线动态加载 (drag-to-load older candles)
  // ============================================================
  // 主图初始只有 KLINE_LIMIT(200) 根；用户向左拖拽越过最早一根时，
  // 自动向后端翻页拉取更早的 HIST_CHUNK 根（带 endTime，直连 REST），
  // 前置拼接到 histState.candles。renderMain 每次渲染都把
  // 历史缓冲 + 实时窗口合并后再画，FVG 也在合并后的全量 K 线上动态识别。
  const histState = {
    key: '',        // symbol|market|interval —— 变了自动清空缓冲
    candles: [],    // 已加载的更早历史（升序，严格早于实时窗口）
    loading: false,
    noMore: false   // 交易所返回空 → 拉到头了
  };

  function _histKey() {
    const symbol = (els.symbol.value || 'BTCUSDT').trim().toUpperCase();
    return `${symbol}|${els.market.value}|${els.interval.value}`;
  }

  function _histReset() {
    histState.key = _histKey();
    histState.candles = [];
    histState.loading = false;
    histState.noMore = false;
  }

  // 合并历史缓冲与实时窗口（边界按 openTime 去重，历史只保留严格更早的部分）
  function _mergeWithHistory(candles) {
    const key = _histKey();
    if (key !== histState.key) _histReset();
    if (!histState.candles.length || !candles.length) return candles;
    const firstLive = Number(candles[0].openTime);
    const older = histState.candles.filter((c) => Number(c.openTime) < firstLive);
    return older.length ? older.concat(candles) : candles;
  }

  // FVG 三根 K 线缺口识别（与后端 detectFVGs 同一算法）。
  // 放到前端做是为了在"历史缓冲 + 实时窗口"合并后的全量 K 线上动态识别 ——
  // 拖拽加载更早历史后，旧区间的上涨/下跌 FVG 也会即时补上。
  function detectFVGsClient(candles) {
    const gaps = [];
    for (let i = 0; i < candles.length - 2; i += 1) {
      const c1 = candles[i];
      const c3 = candles[i + 2];
      if (c1.high < c3.low) {
        gaps.push({
          type: 'bullish', lower: c1.high, upper: c3.low,
          startTime: c1.openTime, endTime: c3.closeTime, index: i + 1
        });
      } else if (c1.low > c3.high) {
        gaps.push({
          type: 'bearish', lower: c3.high, upper: c1.low,
          startTime: c1.openTime, endTime: c3.closeTime, index: i + 1
        });
      }
    }
    return gaps;
  }

  // 流动性空白识别（与后端 detectLiquidityVoids 同一算法）：
  // 连续 ≥ minLength 根 K 线，影线区间整体重合度 ≤ overlapPct 的紧密整理段。
  // 与 FVG 一样在前端对"历史缓冲 + 实时窗口"合并后的全量 K 线动态识别，
  // 拖拽加载更早历史后旧区间的空白带也会即时补上。
  function detectLiquidityVoidsClient(candles, minLength = 5, overlapPct = 0.005) {
    if (!candles.length) return [];
    const voids = [];
    let runStart = 0;
    let runHigh = candles[0].high;
    let runLow = candles[0].low;

    function flushRun(endExclusive) {
      const length = endExclusive - runStart;
      if (length < minLength) return;
      const mid = (runHigh + runLow) / 2 || 1;
      if ((runHigh - runLow) / mid <= overlapPct) {
        voids.push({
          startTime: candles[runStart].openTime,
          endTime: candles[endExclusive - 1].closeTime,
          lower: runLow,
          upper: runHigh,
          length
        });
      }
    }

    for (let i = 1; i < candles.length; i += 1) {
      const c = candles[i];
      const newHigh = Math.max(runHigh, c.high);
      const newLow = Math.min(runLow, c.low);
      const mid = (newHigh + newLow) / 2 || 1;
      if ((newHigh - newLow) / mid <= overlapPct) {
        runHigh = newHigh;
        runLow = newLow;
      } else {
        flushRun(i);
        runStart = i;
        runHigh = c.high;
        runLow = c.low;
      }
    }
    flushRun(candles.length);
    return voids;
  }

  async function loadOlderCandles() {
    if (histState.loading || histState.noMore) return;
    if (!lastCandles.length) return;
    if (histState.candles.length >= HIST_MAX_BARS) return;
    const key = _histKey();
    if (key !== histState.key) _histReset();
    histState.loading = true;
    try {
      const symbol = (els.symbol.value || 'BTCUSDT').trim().toUpperCase();
      const market = els.market.value;
      const interval = els.interval.value;
      const oldest = Number((histState.candles[0] || lastCandles[0]).openTime);
      if (!Number.isFinite(oldest) || oldest <= 0) return;
      const resp = await fetchJsonSoft(
        `/api/klines?symbol=${symbol}&interval=${interval}&limit=${HIST_CHUNK}` +
        `&market=${market}&endTime=${oldest - 1}&detectPatterns=false&notify=false`
      );
      // 拉取期间用户切换了 symbol/market/interval → 丢弃本次结果
      if (key !== _histKey()) return;
      // 网络/网关失败：不标记 noMore，等下次拖拽重试
      if (!resp || !Array.isArray(resp.candles)) return;
      const older = resp.candles
        .filter((c) => Number(c.openTime) < oldest)
        .sort((a, b) => a.openTime - b.openTime);
      if (!older.length) {
        // 真拿到了响应但没有更早数据 → 上市之初，拉到头了
        histState.noMore = true;
        return;
      }
      histState.candles = older.concat(histState.candles);
      // 用最近一次主图数据立即重绘（renderMain 内部会做历史合并）；
      // 先记住可视时间范围，setData 全量重置后恢复，避免视图跳动。
      if (renderMain._lastArgs) {
        const vr = mainChart.timeScale().getVisibleRange();
        renderMain(renderMain._lastArgs);
        if (vr) {
          try { mainChart.timeScale().setVisibleRange(vr); } catch (_) { /* noop */ }
          syncSubChartsToMain();
        }
      }
    } finally {
      histState.loading = false;
    }
  }

  // 向左拖拽越过最早一根（logical index < -1，出现左侧空白）→ 翻页加载
  mainChart.timeScale().subscribeVisibleLogicalRangeChange((r) => {
    if (!r || r.from >= -1) return;
    loadOlderCandles();
  });

  function renderMain(klinesData) {
    const { candles, summary } = klinesData;
    if (!candles.length) return;
    // 记住最近一次数据源，供历史翻页加载后立即重绘（loadOlderCandles）
    renderMain._lastArgs = klinesData;
    // 历史缓冲 + 实时窗口合并（拖拽加载的更早 K 线在前）
    const merged = _mergeWithHistory(candles);
    lastCandles = merged;

    const mapped = merged.map((c) => ({
      time: toLwSeconds(c.openTime),
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close
    }));
    _smartUpdateSeries(candleSeries, mapped);
    
    if (heatmap && heatmap.redraw) {
      heatmap.redraw();
    }

    // VWAP 兜底：SSE 推送的 candle 没有 vwap 字段（hub 缓存的是 raw kline）；
    // 加载了历史后各分页的 vwap 是各自窗口累积的、边界会跳变 ——
    // 两种情况都在本地对合并后的全量 K 线重新累积计算一次，保证曲线连续。
    if (histState.candles.length || merged.some((c) => !Number.isFinite(c.vwap))) {
      let cumPV = 0;
      let cumVol = 0;
      for (const c of merged) {
        const tp = (Number(c.high) + Number(c.low) + Number(c.close)) / 3;
        const v = Number(c.volume) || 0;
        cumPV += tp * v;
        cumVol += v;
        c.vwap = cumVol > 0 ? cumPV / cumVol : tp;
      }
    }
    const vwapPoints = merged
      .map((c) => ({ time: toLwSeconds(c.openTime), value: c.vwap }))
      .filter((p) => p.value !== null && Number.isFinite(p.value));
    _smartUpdateSeries(vwapSeries, vwapPoints);

    // FVG 动态识别：不用后端窗口内的结果，而是对"已加载的全部 K 线"
    // （历史缓冲 + 实时窗口）前端实时检测 —— 拖拽加载更早历史后，
    // 旧区间的上涨/下跌 FVG 会即时补上（与后端 detectFVGs 同一算法）。
    // 注：主图保持实时口径（含未收盘 K 线）；"关键价位"面板则只用
    // 已收盘 K 线（确认制），两者定位不同，属预期差异。
    const fvgs = detectFVGsClient(merged);
    // 流动性空白同样对全量已加载 K 线动态识别（不再依赖后端窗口内的结果）
    const liquidityVoids = detectLiquidityVoidsClient(merged);

    // 在主 K 线上绘制 FVG / 流动性空白的标记
    // (Markers for FVGs and liquidity voids on the candle series.)
    // 历史 FVG 全量画箭头标记：拖拽加载多少历史，就标多少（识别与显示同步扩展）。
    // 上限只是内存/渲染安全阀（5200 根 K 线的 FVG 通常 ~1300 个，远够）；
    // setMarkers 有 hash 缓存，数据不变不会重复重绘。
    const FVG_MARKER_CAP = 2000; // FVG 箭头标记安全上限
    const FVG_ZONE_CAP = 8;      // FVG 区间上下沿（价格线）只画最近几个，避免横线铺满全图
    const markers = [];
    for (const f of fvgs.slice(-FVG_MARKER_CAP)) {
      const ts = toLwSeconds(f.startTime);
      markers.push({
        time: ts,
        position: f.type === 'bullish' ? 'belowBar' : 'aboveBar',
        color: f.type === 'bullish' ? '#4ade80' : '#f87171',
        shape: f.type === 'bullish' ? 'arrowUp' : 'arrowDown',
        text: 'FVG'
      });
    }
    // 流动性空白全量画标记（紧密整理段本身稀少，500 上限只是安全阀）
    const VOID_MARKER_CAP = 500;
    for (const v of liquidityVoids.slice(-VOID_MARKER_CAP)) {
      markers.push({
        time: toLwSeconds(v.startTime),
        position: 'inBar',
        color: '#facc15',
        shape: 'circle',
        text: 'VOID'
      });
    }
    // 关键 ①：setMarkers 要求整个数组按 time 升序 —— FVG 与 VOID 两组
    // 各自有序但拼接后整体乱序，lightweight-charts 内部按序二分决定视口内
    // 画哪些标记，乱序会导致缩放/平移时历史标记时隐时现。统一排序修复。
    markers.sort((a, b) => a.time - b.time);
    // 关键 ②：setMarkers 会触发主图重绘并清掉 lightweight-charts 内部 hover
    // state（导致 X 轴 hover label 闪烁）。FVG / liquidity voids 在历史区间，
    // 短时间内不变，每秒 SSE 推一次完全没必要重设 markers。
    // 用 hash 缓存：相同则跳过。
    const markersHash = JSON.stringify(markers);
    if (renderMain._lastMarkersHash !== markersHash) {
    candleSeries.setMarkers(markers);
      renderMain._lastMarkersHash = markersHash;
    }

    // 用横向价格线模拟 FVG 区间上下沿
    // (Price lines: outline FVG zones using horizontal price lines on the
    //  candlestick series. lightweight-charts standalone build has no
    //  native rectangle API, so we approximate with price lines.)
    // 同样缓存：FVG 没变就不 remove + 重 create（这两个 API 也清 hover state）。
    const fvgZones = fvgs.slice(-FVG_ZONE_CAP);
    const priceLinesHash = JSON.stringify(fvgZones.map((f) => ({
      u: f.upper, l: f.lower, t: f.type
    })));
    if (renderMain._lastPriceLinesHash !== priceLinesHash) {
    if (renderMain._priceLines) {
      for (const pl of renderMain._priceLines) candleSeries.removePriceLine(pl);
    }
    const priceLines = [];
      for (const f of fvgZones) {
      priceLines.push(candleSeries.createPriceLine({
        price: f.upper,
        color: f.type === 'bullish' ? 'rgba(74, 222, 128, 0.6)' : 'rgba(248, 113, 113, 0.6)',
        lineStyle: LightweightCharts.LineStyle.Dashed,
        lineWidth: 1,
        axisLabelVisible: false,
        title: `FVG ${f.type === 'bullish' ? '↑' : '↓'} top`
      }));
      priceLines.push(candleSeries.createPriceLine({
        price: f.lower,
        color: f.type === 'bullish' ? 'rgba(74, 222, 128, 0.4)' : 'rgba(248, 113, 113, 0.4)',
        lineStyle: LightweightCharts.LineStyle.Dotted,
        lineWidth: 1,
        axisLabelVisible: false,
        title: `FVG ${f.type === 'bullish' ? '↑' : '↓'} bot`
      }));
    }
    renderMain._priceLines = priceLines;
      renderMain._lastPriceLinesHash = priceLinesHash;
    }

    // Volume Profile（POC/VAH/VAL/LVN）独立维护 priceLines，缓存防止反复重建
    _renderVolumeProfilePriceLines(_lastVolumeProfile);

    els.mainMeta.textContent =
      `${summary.symbol} · ${summary.market} · ${summary.interval} · ${merged.length} bars`;

    const volumeData = merged.map((c) => ({
      time: toLwSeconds(c.openTime),
      value: c.volume,
      color: c.close >= c.open ? 'rgba(74, 222, 128, 0.6)' : 'rgba(248, 113, 113, 0.6)'
    }));

    // 计算成交量 20 周期均线 (Volume MA20)
    const volMaPoints = [];
    const MA_PERIOD = 20;
    let sumVol = 0;
    for (let i = 0; i < merged.length; i++) {
      sumVol += merged[i].volume;
      if (i >= MA_PERIOD) {
        sumVol -= merged[i - MA_PERIOD].volume;
      }
      if (i >= MA_PERIOD - 1) {
        volMaPoints.push({
          time: toLwSeconds(merged[i].openTime),
          value: sumVol / MA_PERIOD
        });
      }
    }

    _smartUpdateSeries(volumeSeries, volumeData);
    _smartUpdateSeries(volumeMASeries, volMaPoints);
    // 新周期 K 线 + 成交量已渲染 → 揭开这两个图的 loading
    hideChartLoading(els.mainChart);
    hideChartLoading(els.volumePane);

    // CVD 副图：合并模式用后端多合约 delta，单一模式与主图 K 线同源派生
    // (Merged: backend multi-contract delta; Single: derive from same candles.)
    refreshCvdDisplay(merged);

    // OI 副图：主图 K 线变化后用最近一次 OI 响应重新按 openTime 对齐
    // (Realign cached OI samples to the new candle grid.)
    if (_lastOiResp) renderOpenInterest(_lastOiResp, merged);

    // 只在首次渲染或用户主动重置时 fitContent，避免实时刷新打断用户拖动
    // 主图 fit 后立即把所有副图拉到主图当前可见范围（联动同步）
    if (!chartsFitted) {
    mainChart.timeScale().fitContent();
      chartsFitted = true;
    }
    syncSubChartsToMain();
    // 数据更新可能让 lightweight-charts 内部 crosshair 状态被重置
    // (setData / setMarkers / createPriceLine 都会触发 chart 重绘)，
    // 用缓存的 hover 位置主动恢复，确保 hover 中的虚线和坐标标签不消失。
    _restoreHoverCrosshairs();
  }

  // ============================================================
  // 成交量分布 / Volume Profile（VAH + VAL + LVN 价格线，POC 已按需求移除）
  // ============================================================
  //
  // 用 lightweight-charts 的 PriceLine 在主 K 线图上标注关键价位：
  //   - VAH/VAL  (Value Area H/L,    紫色虚线)  · 70% 成交分布区上下沿
  //   - LVN-N    (Low Volume Node,   红色点线)  · 前 3 个最深的真空带中线
  //                                              价格回测时常作翻转位
  //
  // 拉取频率：每 30 秒（K 线 1m 级别下，VP 分布短时间不会显著变化）
  // 缓存：hash 防止反复 remove/create（lightweight-charts API 调用会清掉 crosshair）
  //
  let _lastVolumeProfile = null;
  let _vpInFlight = false;
  let _vpPriceLines = [];
  let _vpLastHash = '';
  const VP_TOP_LVN_COUNT = 3;            // 只画最深的 N 个 LVN，避免主图太乱
  const VP_POLL_INTERVAL_MS = 30_000;    // 30s 一次
  const VP_BUCKETS = 100;                // 桶数（精度）
  const VP_LIMIT = 500;                  // K 线数量（覆盖窗口）

  async function _fetchVolumeProfile() {
    if (_vpInFlight) return;
    const symbol = (els.symbol.value || 'BTCUSDT').trim().toUpperCase();
    const market = els.market.value;
    const interval = els.interval.value || '1h';
    _vpInFlight = true;
    try {
      const params = new URLSearchParams({
        symbol, market, interval,
        limit: String(VP_LIMIT),
        buckets: String(VP_BUCKETS),
        includeBuckets: 'false'   // 我们只用 poc/vah/val/lvnZones，桶明细暂时不需要
      });
      const data = await fetchJsonSoft(`/api/indicators/volume-profile?${params.toString()}`);
      if (data) {
        _lastVolumeProfile = data;
        _renderVolumeProfilePriceLines(data);
      }
    } finally {
      _vpInFlight = false;
    }
  }

  function _renderVolumeProfilePriceLines(vp) {
    if (!vp || !candleSeries) return;
    const lvnZones = Array.isArray(vp.lvnZones) ? vp.lvnZones.slice(0, VP_TOP_LVN_COUNT) : [];
    // hash 防止反复重建（VAH/VAL/LVN 变化频率很低）
    const hash = JSON.stringify({
      h: vp.vah,
      l: vp.val,
      z: lvnZones.map((z) => [+z.priceMid.toFixed(2), +z.depth.toFixed(3)])
    });
    if (hash === _vpLastHash) return;
    _vpLastHash = hash;

    // 清旧
    for (const pl of _vpPriceLines) {
      try { candleSeries.removePriceLine(pl); } catch (_) { /* ignore */ }
    }
    _vpPriceLines = [];

    // VAH / VAL（紫色虚线，价值区上下沿）
    if (Number.isFinite(vp.vah)) {
      _vpPriceLines.push(candleSeries.createPriceLine({
        price: vp.vah,
        color: 'rgba(168, 85, 247, 0.6)',
        lineStyle: LightweightCharts.LineStyle.Dashed,
        lineWidth: 1,
        axisLabelVisible: false,
        title: `VAH ${vp.vah.toFixed(2)}`
      }));
    }
    if (Number.isFinite(vp.val)) {
      _vpPriceLines.push(candleSeries.createPriceLine({
        price: vp.val,
        color: 'rgba(168, 85, 247, 0.6)',
        lineStyle: LightweightCharts.LineStyle.Dashed,
        lineWidth: 1,
        axisLabelVisible: false,
        title: `VAL ${vp.val.toFixed(2)}`
      }));
    }
    // 前 N 个 LVN（红色点线，按 depth 排序最强的）
    lvnZones.forEach((z, i) => {
      if (!Number.isFinite(z.priceMid)) return;
      const depthPct = (z.depth * 100).toFixed(0);
      _vpPriceLines.push(candleSeries.createPriceLine({
        price: z.priceMid,
        color: 'rgba(248, 113, 113, 0.7)',
        lineStyle: LightweightCharts.LineStyle.Dotted,
        lineWidth: 1,
        axisLabelVisible: false,
        title: `LVN${i + 1} ${z.priceMid.toFixed(2)} (${depthPct}% empty)`
      }));
    });
  }

  // 启动：先 fetch 一次，随后每 30 秒刷新；切换 symbol/market/interval 立即重拉
  _fetchVolumeProfile();
  setInterval(_fetchVolumeProfile, VP_POLL_INTERVAL_MS);
  if (els.symbol)   els.symbol.addEventListener('change', () => { _vpLastHash = ''; _fetchVolumeProfile(); });
  if (els.market)   els.market.addEventListener('change', () => { _vpLastHash = ''; _fetchVolumeProfile(); });
  if (els.interval) els.interval.addEventListener('change', () => { _vpLastHash = ''; _fetchVolumeProfile(); });

  // ---- OI 副图：把 OI 数据按 K 线 openTime 对齐后渲染 ----
  // (Align OI samples to candle openTimes so OI bar count matches the main
  //  chart and the synced logical range stays accurate.)
  //
  // 当 OI 接口 period 与 K 线 interval 不一致（例如选了 1m K 线，OI 最小 5m）
  // 时，每根 K 线取「该 K 线区间内最后一条 OI 样本」，缺失则向前继承上一个值。
  //
  // 口径（unit）可切换，对照 Coinglass 时选同样单位：
  //   'usd'  → sumOpenInterestValue（USD 名义价值 = 币数 × 价格，跟随价格起伏）
  //   'coin' → sumOpenInterest（币数 BTC，纯仓位量，不含价格因素）
  // 互为缺失时用 close 价互算兜底。
  let _lastOiResp = null;
  let _oiUnit = 'usd'; // 'usd' | 'coin'
  // 统计范围：true = 合并三类合约 (USDT-M + USDC-M + COIN-M)，对齐 Coinglass 币安口径
  //           false = 仅当前 USDT 合约（单一来源）
  let _oiAggregate = true;
  // 显示模式：'candle' = 合成 K 线（绿增红减）；'area' = 面积曲线
  let _oiMode = 'candle';
  function oiAggregateParam() {
    return _oiAggregate ? '&aggregate=binance' : '';
  }

  // CVD 统计范围：true = 合并三类合约 (USDT-M + USDC-M + COIN-M) 主动买卖差相加
  //              false = 仅当前 USDT 合约（与主图 K 线实时同源）
  // 合并模式由 poll 拉 /api/cvd 得到每根 delta，缓存在 _lastCvdMerged。
  let _cvdAggregate = true;
  let _lastCvdMerged = null;
  // CVD 口径：'coin' = 币数(BTC)；'usd' = 报价额/名义价值（对照 Coinglass 选 USD）
  // 默认 USD，与持仓量 OI 口径保持一致、对齐 Coinglass 币安聚合口径
  let _cvdUnit = 'usd';
  let _cvdReverse = false;

  // 取单条 OI 样本在当前口径下的数值；互为缺失时用 close 价互算兜底。
  function _oiSampleValue(sample, close) {
    const usd = Number(sample.openInterestValue);
    const coin = Number(sample.openInterest);
    if (_oiUnit === 'coin') {
      if (Number.isFinite(coin) && coin > 0) return coin;
      if (Number.isFinite(usd) && usd > 0 && Number.isFinite(close) && close > 0) return usd / close;
      return NaN;
    }
    // 默认 USD 名义价值
    if (Number.isFinite(usd) && usd > 0) return usd;
    if (Number.isFinite(coin) && coin > 0 && Number.isFinite(close) && close > 0) return coin * close;
    return NaN;
  }

  // 取单条 OI 样本的「币数 / 仓位量」（合约数，价格无关）。
  // ⚠️ K 线"增仓/减仓"必须用这个，而不是 USD 名义价值：
  //    USD 名义 = 币数 × 价格，价格大跌时即使空头在加仓(币数↑)，USD 名义也可能↓，
  //    会把"增仓"画成红色"减仓" —— 这正是用户反馈的问题根源。
  function _oiCoinValue(sample, close) {
    const coin = Number(sample.openInterest);
    if (Number.isFinite(coin) && coin > 0) return coin;
    const usd = Number(sample.openInterestValue);
    if (Number.isFinite(usd) && usd > 0 && Number.isFinite(close) && close > 0) return usd / close;
    return NaN;
  }

  function renderOpenInterest(resp, candles) {
    _lastOiResp = resp || _lastOiResp;
    if (!resp) return;
    // 有响应就揭开 loading（unsupported 也算：现货无 OI，清空即最终状态）
    hideChartLoading(els.oiPane);
    if (!resp.supported) {
      _smartUpdateSeries(oiSeries, []);
      _smartUpdateSeries(oiCandleSeries, []);
      return;
    }
    const oi = (resp.data || []).slice().sort((a, b) => a.openTime - b.openTime);
    const cands = Array.isArray(candles) && candles.length ? candles : lastCandles;
    if (!oi.length || !cands.length) {
      _smartUpdateSeries(oiSeries, []);
      _smartUpdateSeries(oiCandleSeries, []);
      return;
    }
    const points = [];      // 面积曲线：按 _oiUnit 口径（USD 名义 / 币数）
    const coinPoints = [];  // K 线专用：始终币数(仓位量)，价格无关 → 增减仓判断才正确
    let oiIdx = 0;
    let lastSample = null;
    for (let i = 0; i < cands.length; i += 1) {
      const c = cands[i];
      // 该 K 线右边界：closeTime；缺失则用下一根 openTime - 1
      const right = c.closeTime
        ? Number(c.closeTime)
        : (cands[i + 1] ? Number(cands[i + 1].openTime) - 1 : Number(c.openTime));
      // 推进 oiIdx 收集所有 ts <= right 的 OI 样本，记最后一个
      while (oiIdx < oi.length && oi[oiIdx].openTime <= right) {
        lastSample = oi[oiIdx];
        oiIdx += 1;
      }
      if (lastSample) {
        const cl = Number(c.close);
        const t = toLwSeconds(c.openTime);
        const v = _oiSampleValue(lastSample, cl);
        if (Number.isFinite(v) && v > 0) points.push({ time: t, value: v });
        const coinV = _oiCoinValue(lastSample, cl);
        if (Number.isFinite(coinV) && coinV > 0) coinPoints.push({ time: t, value: coinV });
      }
    }
    // 合成 K 线：open = 上一周期持仓量，close = 本周期持仓量；用「币数(仓位量)」，
    // 故 close ≥ open = 绿（真·增仓），close < open = 红（真·减仓），不受价格涨跌干扰。
    // （之前用 USD 名义价值，价格大跌时会把"空头加仓"误画成"减仓"。）
    const candlePoints = [];
    for (let i = 0; i < coinPoints.length; i += 1) {
      const close = coinPoints[i].value;
      const open = i > 0 ? coinPoints[i - 1].value : close;
      candlePoints.push({
        time: coinPoints[i].time,
        open,
        high: Math.max(open, close),
        low: Math.min(open, close),
        close
      });
    }
    // 只给当前模式的 series 灌数据，另一条清空。
    // 原因：K 线用币数(可能 ~9万 BTC)，面积可能用 USD(~90亿)，量级差极大。
    // 两条都在右轴上，若同时有数据会互相污染自动缩放（把 K 线压成贴边直线）。
    if (_oiMode === 'candle') {
      _smartUpdateSeries(oiCandleSeries, candlePoints);
      _smartUpdateSeries(oiSeries, []);
    } else {
      _smartUpdateSeries(oiSeries, points);
      _smartUpdateSeries(oiCandleSeries, []);
    }
    _applyOiMode();
    // OI 副图永远跟随主图，不再 fitContent —— 否则 OI 数据后到时会把主图也拉跑
    syncSubChartsToMain();
  }

  // 按当前显示模式切换面积 / K 线两条 series 的可见性
  function _applyOiMode() {
    const candle = _oiMode === 'candle';
    if (oiCandleSeries) oiCandleSeries.applyOptions({ visible: candle });
    if (oiSeries) oiSeries.applyOptions({ visible: !candle });
  }

  // OI 口径切换 (USD ⟷ Coin)：更新状态、按钮文案、标题，并用缓存数据立即重绘
  function setOiUnit(unit) {
    _oiUnit = unit === 'coin' ? 'coin' : 'usd';
    const btn = document.getElementById('oi-unit-toggle');
    if (btn) {
      btn.textContent = _oiUnit === 'coin' ? 'OI·Coin' : 'OI·USD';
      btn.title = _oiUnit === 'coin'
        ? '当前：Coin 币数(BTC)。点击切回 USD 名义价值。⚠️ 此口径只作用于「面积」模式；K 线增减仓始终按币数(仓位量)判断。'
        : '当前：USD 名义价值。点击切到 Coin 币数(BTC)。⚠️ 此口径只作用于「面积」模式；K 线增减仓始终按币数(仓位量)判断。';
    }
    const title = document.getElementById('oi-title');
    if (title) {
      title.textContent = _oiUnit === 'coin'
        ? '持仓量 / Open Interest · 币数 BTC（仅合约）'
        : '持仓量 / Open Interest · USD 价值（仅合约）';
    }
    if (_lastOiResp) renderOpenInterest(_lastOiResp, lastCandles);
  }

  {
    const oiUnitBtn = document.getElementById('oi-unit-toggle');
    if (oiUnitBtn) {
      oiUnitBtn.addEventListener('click', () => {
        setOiUnit(_oiUnit === 'usd' ? 'coin' : 'usd');
      });
    }
  }

  // OI 范围切换 (合并三类合约 ⟷ 单一 USDT)：需要重新请求后端
  async function setOiScope(aggregate) {
    _oiAggregate = !!aggregate;
    const btn = document.getElementById('oi-scope-toggle');
    if (btn) {
      btn.textContent = _oiAggregate ? 'OI合并' : 'OI单一';
      btn.title = _oiAggregate
        ? '当前：合并 USDT-M + USDC-M + 币本位 COIN-M 三类合约（对齐 Coinglass 币安口径）。点击切到单一 USDT。'
        : '当前：仅当前 USDT 合约（单一来源）。点击切到合并三类合约。';
    }
    try {
      const symbol = (els.symbol.value || 'BTCUSDT').trim().toUpperCase();
      const market = els.market.value;
      const interval = els.interval.value || '1h';
      const resp = await fetchJsonSoft(
        `/api/openInterest?symbol=${symbol}&market=${market}&interval=${interval}&limit=${SUBCHART_LIMIT}${oiAggregateParam()}`
      );
      if (resp) renderOpenInterest(resp, lastCandles);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.warn('[oi-scope] refetch failed:', err.message);
    }
  }

  {
    const oiScopeBtn = document.getElementById('oi-scope-toggle');
    if (oiScopeBtn) {
      oiScopeBtn.addEventListener('click', () => setOiScope(!_oiAggregate));
    }
  }

  // CVD 范围切换 (合并三类合约 ⟷ 单一 USDT)
  async function setCvdScope(aggregate) {
    _cvdAggregate = !!aggregate;
    const btn = document.getElementById('cvd-scope-toggle');
    if (btn) {
      btn.textContent = _cvdAggregate ? 'CVD合并' : 'CVD单一';
      btn.title = _cvdAggregate
        ? '当前：合并 USDT-M + USDC-M + 币本位 COIN-M 三类合约主动买卖差（对齐 Coinglass 币安口径，按 poll 周期刷新）。点击切到单一 USDT。'
        : '当前：仅当前 USDT 合约（与主图 K 线实时同源、更即时）。点击切到合并三类合约。';
    }
    refreshSubTitles();
    if (!_cvdAggregate) {
      // 切回单一：丢弃合并缓存，立即用主图 K 线重绘
      _lastCvdMerged = null;
      _seriesPrev.delete(cvdSeries);
      refreshCvdDisplay(lastCandles);
      return;
    }
    // 切到合并：立即拉一次，避免等到下个 poll 周期
    try {
      const symbol = (els.symbol.value || 'BTCUSDT').trim().toUpperCase();
      const market = els.market.value;
      const interval = els.interval.value || '1h';
      if (market !== 'futures') {
        // 现货无合并意义，回退单一
        _lastCvdMerged = null;
        _seriesPrev.delete(cvdSeries);
        refreshCvdDisplay(lastCandles);
        return;
      }
      const resp = await fetchJsonSoft(
        `/api/cvd?symbol=${symbol}&market=${market}&interval=${interval}&limit=${SUBCHART_LIMIT}&aggregate=binance`
      );
      _lastCvdMerged = (resp && resp.supported && Array.isArray(resp.data)) ? resp.data : null;
      _seriesPrev.delete(cvdSeries);
      refreshCvdDisplay(lastCandles);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.warn('[cvd-scope] refetch failed:', err.message);
      _seriesPrev.delete(cvdSeries);
      refreshCvdDisplay(lastCandles);
    }
  }

  {
    const cvdScopeBtn = document.getElementById('cvd-scope-toggle');
    if (cvdScopeBtn) {
      cvdScopeBtn.addEventListener('click', () => setCvdScope(!_cvdAggregate));
    }
  }

  // CVD 口径切换 (Coin 币数 ⟷ USD 报价额)：纯前端，两种口径数据都在手，重绘即可
  function setCvdUnit(unit) {
    _cvdUnit = unit === 'usd' ? 'usd' : 'coin';
    const btn = document.getElementById('cvd-unit-toggle');
    if (btn) {
      btn.textContent = _cvdUnit === 'usd' ? 'CVD·USD' : 'CVD·Coin';
      btn.title = _cvdUnit === 'usd'
        ? '当前：USD 报价额/名义价值（对照 Coinglass 选 USD）。点击切到 Coin 币数(BTC)。'
        : '当前：Coin 币数(BTC)。点击切到 USD 报价额/名义价值。对照 Coinglass 时选 USD。';
    }
    refreshSubTitles();
    _seriesPrev.delete(cvdSeries);
    refreshCvdDisplay(lastCandles);
  }

  {
    const cvdUnitBtn = document.getElementById('cvd-unit-toggle');
    if (cvdUnitBtn) {
      cvdUnitBtn.addEventListener('click', () => setCvdUnit(_cvdUnit === 'coin' ? 'usd' : 'coin'));
    }
  }

  // CVD 反向切换：纯前端，重绘即可
  function setCvdReverse(rev) {
    _cvdReverse = !!rev;
    const btn = document.getElementById('cvd-reverse-toggle');
    if (btn) {
      btn.textContent = _cvdReverse ? 'CVD反向:开' : 'CVD反向:关';
    }
    _seriesPrev.delete(cvdSeries);
    refreshCvdDisplay(lastCandles);
  }

  {
    const cvdReverseBtn = document.getElementById('cvd-reverse-toggle');
    if (cvdReverseBtn) {
      cvdReverseBtn.addEventListener('click', () => setCvdReverse(!_cvdReverse));
    }
  }

  // OI 显示模式切换 (K 线 ⟷ 面积)：纯前端，切 series 可见性即可，无需重新请求
  function setOiMode(mode) {
    _oiMode = mode === 'area' ? 'area' : 'candle';
    const btn = document.getElementById('oi-mode-toggle');
    if (btn) {
      btn.textContent = _oiMode === 'candle' ? 'OI·K线' : 'OI·面积';
      btn.title = _oiMode === 'candle'
        ? '当前：持仓量增减 K 线（绿=增仓 / 红=减仓，按币数·仓位量，价格无关）。点击切到面积曲线。'
        : '当前：持仓量规模面积曲线（按上方 USD/Coin 口径）。点击切回增减 K 线。';
    }
    // 切模式后要给新激活的 series 灌数据（另一条是空的），用缓存重绘
    if (_lastOiResp) renderOpenInterest(_lastOiResp, lastCandles);
    else _applyOiMode();
  }

  {
    const oiModeBtn = document.getElementById('oi-mode-toggle');
    if (oiModeBtn) {
      oiModeBtn.addEventListener('click', () => setOiMode(_oiMode === 'candle' ? 'area' : 'candle'));
    }
  }

  // ---- CVD 副图：从 K 线 takerBuyBase 派生 (Derive CVD from K-line takerBuyBase) ----
  // Binance K 线带有 `takerBuyBase`（主动买的基础币量），
  // 因此每根 K 线的"主动买 - 主动卖" = 2 * takerBuyBase - volume，
  // 累积起来就是与该周期一一对应的 CVD 序列。
  // 这样 CVD 副图就能和主图 K 线时间轴严格对齐，并随 interval 切换。
  // (Derive bar delta = 2*takerBuyBase - volume so the resulting CVD curve
  //  shares the exact bar grid with the main chart for the chosen interval.)
  // CVD 渲染分发：合并模式优先用后端缓存的多合约 delta；缓存未到位时
  // 回退到单合约（主图 K 线派生），保证副图任何时候都不空白。
  function refreshCvdDisplay(candles) {
    if (_cvdAggregate && Array.isArray(_lastCvdMerged) && _lastCvdMerged.length) {
      renderCvdMerged(_lastCvdMerged);
    } else {
      renderCvdFromCandles(candles);
    }
    hideChartLoading(els.cvdPane);
  }

  // 用后端返回的每根 delta 累加成 CVD 曲线；口径随 _cvdUnit 取 delta 或 deltaUsd
  function renderCvdMerged(series) {
    const points = [];
    let cum = 0;
    let lastTs = -Infinity;
    for (const d of series || []) {
      let delta = _cvdUnit === 'usd' ? Number(d.deltaUsd) : Number(d.delta);
      if (!Number.isFinite(delta)) continue;
      if (_cvdReverse) delta = -delta;
      cum += delta;
      const ts = toLwSeconds(d.openTime);
      if (ts > lastTs) {
        points.push({ time: ts, value: cum });
        lastTs = ts;
      } else if (points.length) {
        points[points.length - 1].value = cum;
      }
    }
    _smartUpdateSeries(cvdSeries, points);
    syncSubChartsToMain();
  }

  function renderCvdFromCandles(candles) {
    const points = [];
    let cum = 0;
    let lastTs = -Infinity;
    for (const c of candles || []) {
      let delta;
      if (_cvdUnit === 'usd') {
        const tbQ = Number(c.takerBuyQuote);
        const qv = Number(c.quoteVolume);
        if (!Number.isFinite(tbQ) || !Number.isFinite(qv)) continue;
        delta = 2 * tbQ - qv;
      } else {
        const tb = Number(c.takerBuyBase);
        const v = Number(c.volume);
        if (!Number.isFinite(tb) || !Number.isFinite(v)) continue;
        delta = 2 * tb - v;
      }
      if (_cvdReverse) delta = -delta;
      cum += delta;
      const ts = toLwSeconds(c.openTime);
      if (ts > lastTs) {
        points.push({ time: ts, value: cum });
        lastTs = ts;
      } else if (points.length) {
        points[points.length - 1].value = cum;
      }
    }
    _smartUpdateSeries(cvdSeries, points);
    // CVD 副图永远跟随主图，避免自己 fitContent 反过来影响主图视图
    syncSubChartsToMain();
  }

  /**
   * 把 [price, qty] 数组转成 X 升序的累积曲线点数组。
   * side='bid' → 从 best bid 往低价累，asks 类似。返回 X 升序便于 chart.js 渲染。
   */
  function _accumulateOrderBookSide(rows, side) {
    const filtered = (rows || [])
      .map((l) => [Number(l[0]), Number(l[1])])
      .filter(([p, q]) => Number.isFinite(p) && Number.isFinite(q) && q > 0);
    if (side === 'bid') filtered.sort((a, b) => b[0] - a[0]); // best 优先
    else filtered.sort((a, b) => a[0] - b[0]);
    let cum = 0;
    const pts = [];
    for (const [p, q] of filtered) {
      cum += p * q;
      pts.push({ x: p, y: cum });
    }
    return pts.sort((a, b) => a.x - b.x);
  }

  /**
   * 渲染订单簿主图层（当前盘口的两条实线）。
   * baseline 由 _renderOrderBookBaseline 单独维护，避免互相覆盖。
   */
  // 缓存"当前实时盘口"的最新一份，用于 baseline 切换 / hover 触发重绘时复用
  let _lastObBook = null;
  function renderOrderBook(book) {
    const chart = ensureOrderbookChart();
    _lastObBook = book;
    if (els.orderbookCanvas) hideChartLoading(els.orderbookCanvas.parentElement);

    chart.data.datasets[0].data = _accumulateOrderBookSide(book.bids, 'bid');
    chart.data.datasets[1].data = _accumulateOrderBookSide(book.asks, 'ask');

    // mid 价：优先用后端给的 midPrice，缺失则用 bestBid/bestAsk 中点
    const mid = Number.isFinite(Number(book.midPrice))
      ? Number(book.midPrice)
      : (Number.isFinite(Number(book.bestBid)) && Number.isFinite(Number(book.bestAsk))
        ? (Number(book.bestBid) + Number(book.bestAsk)) / 2
        : null);
    chart.options.plugins.obMidLine.mid = mid;

    chart.update('none');
  }

  // ============================================================
  // 订单簿基线对比 (Order Book baseline rolling-window compare)
  // ============================================================
  // 设计：
  //   - 用户选择 windowMs (15m / 1h / 4h / 24h) 作为对比窗口
  //   - 默认锚点是 now，每 30 秒刷新一次基线（拉 now-windowMs 时刻的快照）
  //   - 主图 hover 任一根 K 线时锚点切到 hoverTime（仍取 anchor-windowMs 的快照）
  //     debounce 200ms 减少请求；离开 hover 后回到 now 锚点
  //   - 对比方式：在订单簿图上叠加两条虚线（基线买/卖墙），与当前实线对比
  //     当前线高于基线 = 该价位挂单"增厚"（新墙堆出）
  //     当前线低于基线 = 该价位挂单"撤离"（被撤单 / 被吃掉）
  //   - 状态文字显示"基线时刻 / 与请求时刻差值"，提醒用户基线的真实时间
  const _obBaselineState = {
    windowMs: 0,        // 0 = 关闭
    anchorMs: null,     // null = 用 now；hover 时为 hover 的毫秒时间
    snapshot: null,
    snapshotAt: null,
    requestedAt: null,
    fetching: false,
    autoTimer: null,
    hoverDebounce: null
  };

  function _obBaselineInfoText() {
    const s = _obBaselineState;
    if (!s.windowMs) return '基线已关闭 / Baseline off';
    if (!s.snapshot) {
      return s.fetching ? '基线加载中… / Loading baseline…'
                        : '尚无基线数据（录盘窗口未覆盖）/ No baseline yet';
    }
    const ageMin = Math.round(Math.max(0, (s.requestedAt || Date.now()) - s.snapshotAt) / 60000);
    const tag = s.anchorMs ? `锚定 hover` : `锚定 now`;
    return `基线: ${fmtBJShortDateTime(s.snapshotAt)} (${tag}, 距请求 ${ageMin} min)`;
  }

  function _renderObBaselineLines() {
    const chart = ensureOrderbookChart();
    const snap = _obBaselineState.snapshot;
    if (!snap) {
      chart.data.datasets[2].data = [];
      chart.data.datasets[3].data = [];
      chart.data.datasets[2].hidden = true;
      chart.data.datasets[3].hidden = true;
    } else {
      chart.data.datasets[2].data = _accumulateOrderBookSide(snap.bids, 'bid');
      chart.data.datasets[3].data = _accumulateOrderBookSide(snap.asks, 'ask');
      chart.data.datasets[2].hidden = false;
      chart.data.datasets[3].hidden = false;
    }
    if (els.obBaselineInfo) els.obBaselineInfo.textContent = _obBaselineInfoText();
    chart.update('none');
  }

  /**
   * 拉一次基线快照。anchorMs 为 null 表示用 now。
   * 防抖：fetching=true 时直接 skip。
   */
  async function _fetchObBaseline() {
    const s = _obBaselineState;
    if (!s.windowMs) {
      s.snapshot = null;
      s.snapshotAt = null;
      s.requestedAt = null;
      _renderObBaselineLines();
      return;
    }
    if (s.fetching) return;
    s.fetching = true;
    if (els.obBaselineInfo) els.obBaselineInfo.textContent = _obBaselineInfoText();
    try {
      const symbol = (els.symbol.value || 'BTCUSDT').toUpperCase();
      const market = els.market ? els.market.value : 'futures';
      // 录盘只对 BTCUSDT futures，所以非该 symbol/market 直接清空
      if (symbol !== 'BTCUSDT' || market !== 'futures') {
        s.snapshot = null; s.snapshotAt = null; s.requestedAt = null;
        if (els.obBaselineInfo) {
          els.obBaselineInfo.textContent = '基线仅支持 BTCUSDT 合约 / Baseline available only for BTCUSDT futures';
        }
        _renderObBaselineLines();
        return;
      }
      const anchor = s.anchorMs || Date.now();
      const at = anchor - s.windowMs;
      s.requestedAt = at;
      const url = `/api/orderbook/snapshot?symbol=${symbol}&market=${market}&at=${at}`;
      const data = await fetchJsonSoft(url);
      if (!data || !data.found) {
        s.snapshot = null;
        s.snapshotAt = null;
      } else {
        s.snapshot = { bids: data.bids, asks: data.asks };
        s.snapshotAt = data.snapshotAt;
      }
      _renderObBaselineLines();
    } finally {
      s.fetching = false;
    }
  }

  function _scheduleObBaselineAuto() {
    const s = _obBaselineState;
    if (s.autoTimer) { clearInterval(s.autoTimer); s.autoTimer = null; }
    if (!s.windowMs) return;
    // 30s 刷新一次"now 锚定"的基线（hover 锚定不会被 timer 触发）
    s.autoTimer = setInterval(() => {
      if (!s.anchorMs) _fetchObBaseline();
    }, 30_000);
  }

  function setObBaselineWindow(windowMs) {
    if (_obBaselineState.hoverDebounce) clearTimeout(_obBaselineState.hoverDebounce);
    _obBaselineState.windowMs = Number(windowMs) || 0;
    _obBaselineState.anchorMs = null; // 切窗口时回到 now 锚定
    _scheduleObBaselineAuto();
    _fetchObBaseline();
  }

  /**
   * 主图 hover 时把锚点切到 hoverTime（debounce 200ms 减少请求）。
   * hoverMs 为 null 表示离开 hover → 恢复 now 锚定。
   */
  function setObBaselineHoverAnchor(hoverMs) {
    const s = _obBaselineState;
    if (!s.windowMs) return; // 关闭状态不响应 hover
    const nextAnchor = (hoverMs && Number.isFinite(hoverMs)) ? hoverMs : null;
    if (s.anchorMs === nextAnchor) return;
    if (s.hoverDebounce) clearTimeout(s.hoverDebounce);
    s.hoverDebounce = setTimeout(() => {
      s.anchorMs = nextAnchor;
      _fetchObBaseline();
    }, 200);
  }

  // 关键价位 / 清算磁极信号 / 双层共振信号 面板已移除（性能优化）。
  // 信号计算改由后端 services/signalPoller.js 定时轮询，飞书推送 + autoTrade 不受影响。

  // ============================================================
  // SSE 实时模式 (Server-Sent Events realtime mode)
  // ============================================================
  // 当浏览器支持 EventSource 时，主图 K 线 / 订单簿改由 SSE 驱动，
  // 实时推送（K 线每秒 1-N 次，订单簿 100ms 节流）；
  // 信号 / 报警 / 指标快照仍走 10s 轮询（10s 内变化对决策不敏感）。
  // SSE 异常会自动 fallback：状态栏标红 + 继续依赖 10s 轮询数据。
  // ============================================================
  const SSE_RENDER_THROTTLE_MS = 200;
  // K 线静默超过此阈值 → 主动重连 SSE（而非降级到 10s 轮询）
  // 选择 30s 是因为 1m / 15m / 1h K 线在该时间内必有更新
  const KLINE_STALE_MS = 30_000;
  // watchdog 检查频率
  const WATCHDOG_INTERVAL_MS = 5_000;
  // 覆盖服务端 20s 初始化预算，避免客户端抢先反复打断 seed。
  const SSE_INIT_TIMEOUT_MS = 25_000;
  let dataGeneration = 0;

  const sseState = {
    supported: typeof EventSource !== 'undefined',
    es: null,
    active: false,
    ready: false,           // 当前是否处于推送中
    everReady: false,       // 是否至少 ready 过一次（用于决定 poll 是否还需要做主图 seed）
    candles: [],            // 由 SSE 推送维护的 K 线序列
    summary: null,
    renderTimer: null,
    lastBookAt: 0,
    lastHeartbeatAt: 0,
    lastKlineAt: 0,
    lastErrorAt: 0,
    reconnectTimer: null,
    watchdogTimer: null,
    initTimer: null,
    backoffMs: 1000,
    // 调试可观察
    klineEventCount: 0,
    bookEventCount: 0,
    snapshotCount: 0,
    openedAt: 0
  };

  // 主图当前是否由 SSE 实时驱动；用于 poll 内决定是否跳过订单簿请求
  function isSSEDriving() {
    return sseState.active && sseState.ready;
  }
  // 主图是否已经由 SSE 接管渲染（即便 SSE 此刻断线，K 线也不再让 poll 周期性跳动）
  function sseOwnsMainChart() {
    return sseState.everReady;
  }

  // 浏览器侧直连 Binance WS（旧的 directKlineWS）已被移除：
  // 改由服务端 binanceStream + /api/stream/sse 统一推送 K 线 / 订单簿，
  // 让用户本地网络抖动时也不影响数据流（仅依赖到本服务的 SSE 长连接）。
  //
  // 之前路径错（@kline 在升级后只走 /market/ws/）导致 K 线一直收不到，
  // 现已修复 services/binanceStream.js 的 FUTURES_WS_BASE 走 /market/stream，
  // 服务端 ws hub 的 'kline' 事件会通过 SSE 'kline' event 推送到浏览器。

  function buildSSEUrl() {
    const symbol = (els.symbol.value || '').trim().toUpperCase() || 'BTCUSDT';
    const market = els.market.value;
    const interval = els.interval.value;
    const depth = obDepthForInterval(interval);
    const params = new URLSearchParams({
      symbol,
      market,
      interval,
      limit: String(KLINE_LIMIT),
      depth: String(depth),
      aggLimit: '200'
    });
    return `/api/stream/sse?${params.toString()}`;
  }

  function scheduleSSERender() {
    if (sseState.renderTimer) return;
    sseState.renderTimer = setTimeout(() => {
      sseState.renderTimer = null;
      if (!isSSEDriving()) return;
      renderMain({
        candles: sseState.candles,
        summary: sseState.summary || { symbol: '', market: '', interval: '', count: sseState.candles.length }
      });
    }, SSE_RENDER_THROTTLE_MS);
  }

  // 把 SSE book 推送的纯档位数据转换成 renderOrderBook 期望的形状
  function renderOrderBookFromSSE(book) {
    if (!book || !book.bids || !book.asks) return;
    const topBid = book.bids[0];
    const topAsk = book.asks[0];
    const bestBid = topBid ? Number(topBid[0]) : null;
    const bestAsk = topAsk ? Number(topAsk[0]) : null;
    const mid = (Number.isFinite(bestBid) && Number.isFinite(bestAsk))
      ? (bestBid + bestAsk) / 2
      : null;
    renderOrderBook({
      bids: book.bids,
      asks: book.asks,
      bestBid,
      bestAsk,
      midPrice: mid
    });
  }

  function setSSELiveStatus(extra = '') {
    const cnt = sseState.klineEventCount;
    const tag = cnt > 0 ? ` · K线 ${cnt} 条` : '';
    setStatus(`实时 / Live · ${nowBJTimeHMS()} (UTC+8) · 服务端推送${tag}${extra}`);
  }

  function startSSE(preserveData = false) {
    if (!sseState.supported) return false;
    stopSSE(preserveData);
    sseState.active = true;
    sseState.ready = false;
    if (!preserveData) {
      sseState.candles = [];
      sseState.summary = null;
    }
    sseState.klineEventCount = 0;
    sseState.bookEventCount = 0;
    sseState.snapshotCount = 0;
    sseState.openedAt = Date.now();
    sseState.lastHeartbeatAt = 0;
    sseState.lastBookAt = 0;
    setStatus('建立实时连接… / Connecting SSE…');

    const url = buildSSEUrl();
    // eslint-disable-next-line no-console
    console.info('[sse] connecting', url);

    let es;
    try {
      es = new EventSource(url);
    } catch (err) {
      sseState.active = false;
      setStatus('SSE 不可用，使用轮询 / SSE unavailable, falling back', true);
      return false;
    }
    sseState.es = es;

    sseState.initTimer = setTimeout(() => {
      sseState.initTimer = null;
      if (sseState.snapshotCount === 0 && sseState.active) {
        // eslint-disable-next-line no-console
        console.warn(`[sse] init timeout (${SSE_INIT_TIMEOUT_MS}ms) — no snapshot received, force reconnect`);
        setStatus('实时连接超时，重连中… / SSE init timeout, retrying', true);
        scheduleSSEReconnect();
      }
    }, SSE_INIT_TIMEOUT_MS);

    es.addEventListener('open', () => {
      // eslint-disable-next-line no-console
      console.info(`[sse] open · readyState=${es.readyState} latency=${Date.now() - sseState.openedAt}ms`);
    });

    es.addEventListener('snapshot', (ev) => {
      if (sseState.es !== es) return;
      try {
        const d = JSON.parse(ev.data);
        sseState.candles = Array.isArray(d.klines) ? d.klines.slice() : [];
        sseState.summary = {
          symbol: d.symbol, market: d.market, interval: d.interval,
          count: sseState.candles.length
        };
        sseState.ready = true;
        sseState.everReady = true;
        sseState.snapshotCount += 1;
        sseState.lastKlineAt = Date.now(); // snapshot 视为一次 fresh K 线
        sseState.backoffMs = 1000;
        if (sseState.initTimer) {
          clearTimeout(sseState.initTimer);
          sseState.initTimer = null;
        }
        startWatchdog();
        renderMain({
          candles: sseState.candles,
          summary: sseState.summary
        });
        renderOrderBookFromSSE(d.book);
        setSSELiveStatus(' · snapshot OK');
        // eslint-disable-next-line no-console
        console.info(
          `[sse] snapshot received · symbol=${d.symbol} market=${d.market}`
          + ` interval=${d.interval} klines=${sseState.candles.length}`
        );
        // 主图 K 线增量完全交由本 SSE 连接的 'kline' event 推送，
        // 不再启动浏览器侧直连 binance ws（避免本地网络抖动 / 区域限制）
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[sse] snapshot parse error', err);
      }
    });

    es.addEventListener('kline', (ev) => {
      if (sseState.es !== es) return;
      try {
        const d = JSON.parse(ev.data);
        const c = d.candle;
        if (!c || !sseState.summary) return;
        if (d.interval !== sseState.summary.interval) return; // 不同周期忽略
        const idx = sseState.candles.findIndex((x) => x.openTime === c.openTime);
        if (idx >= 0) sseState.candles[idx] = c;
        else sseState.candles.push(c);
        if (sseState.candles.length > 1500) {
          sseState.candles.splice(0, sseState.candles.length - 1500);
        }
        sseState.lastKlineAt = Date.now();
        sseState.klineEventCount += 1;
        if (sseState.klineEventCount === 1) {
          // eslint-disable-next-line no-console
          console.info(`[sse] first kline arrived after ${Date.now() - sseState.openedAt}ms`);
        }
        scheduleSSERender();
      } catch (_) { /* swallow */ }
    });

    es.addEventListener('book', (ev) => {
      if (sseState.es !== es) return;
      try {
        const d = JSON.parse(ev.data);
        renderOrderBookFromSSE(d);
        sseState.lastBookAt = Date.now();
        sseState.bookEventCount += 1;
      } catch (_) { /* swallow */ }
    });

    es.addEventListener('access-revoked', () => {
      stopSSE();
      stopAutoPoll();
      window.dispatchEvent(new Event('payment-access-revoked'));
    });
    es.addEventListener('heartbeat', () => {
      if (sseState.es === es) sseState.lastHeartbeatAt = Date.now();
    });
    es.addEventListener('error', (ev) => {
      if (sseState.es !== es) return;
      // 任何 error 都立刻 ready=false，停掉 pending 渲染。
      // 主图不再降级到 poll —— 等 EventSource 自动重连成功后 snapshot 会再来。
      sseState.ready = false;
      if (sseState.renderTimer) {
        clearTimeout(sseState.renderTimer);
        sseState.renderTimer = null;
      }
      // 服务端通过 `event: error\ndata: ...` 主动报错（init 失败之类）
      // 这种事件 ev.data 会有内容；普通连接错误 data 为空。
      const serverErr = ev && ev.data ? (() => {
        try { return JSON.parse(ev.data); } catch (_) { return ev.data; }
      })() : null;
      // eslint-disable-next-line no-console
      console.warn(
        '[sse] error · readyState=' + (es && es.readyState),
        'serverErr=', serverErr,
        'klineEvents=', sseState.klineEventCount,
        'bookEvents=', sseState.bookEventCount
      );
      // 状态文本节流，避免每秒刷屏
      const nowMs = Date.now();
      if (nowMs - sseState.lastErrorAt >= 3000) {
        sseState.lastErrorAt = nowMs;
        setStatus('实时连接暂断，保留最近数据并稍后重连', true);
      }
      scheduleSSEReconnect();
    });
    return true;
  }

  function stopSSE(preserveData = false) {
    if (sseState.es) {
      try { sseState.es.close(); } catch (_) { /* noop */ }
    }
    sseState.es = null;
    sseState.active = false;
    sseState.ready = false;
    if (!preserveData) {
      sseState.everReady = false;
      sseState.candles = [];
    }
    if (sseState.renderTimer) {
      clearTimeout(sseState.renderTimer);
      sseState.renderTimer = null;
    }
    if (sseState.reconnectTimer) {
      clearTimeout(sseState.reconnectTimer);
      sseState.reconnectTimer = null;
    }
    if (sseState.initTimer) {
      clearTimeout(sseState.initTimer);
      sseState.initTimer = null;
    }
    stopWatchdog();
  }

  // ---- Watchdog：监控 K 线推送活性，必要时主动重连 ------------------
  // 主图完全由 SSE 驱动；如果 SSE 仍 active+ready 但 K 线静默 > 30s，
  // 视为推送中断（路径阻塞 / Binance 限流 / 反代 buffer 等），
  // 直接 close + 重新建立连接，而不是降级到 10s 轮询。
  // (Main chart is SSE-driven only. If SSE looks alive but no kline arrived
  //  for 30s, force a reconnect instead of falling back to polling.)
  function startWatchdog() {
    stopWatchdog();
    sseState.watchdogTimer = setInterval(() => {
      if (!sseState.active || !sseState.ready) return;
      const idle = Date.now() - Math.max(sseState.lastKlineAt || 0, sseState.lastBookAt || 0, sseState.lastHeartbeatAt || 0);
      if (idle > KLINE_STALE_MS) {
        // eslint-disable-next-line no-console
        console.warn(`[sse] watchdog: K-line idle ${idle}ms, forcing reconnect`);
        setStatus(`实时静默 ${Math.round(idle / 1000)}s，强制重连 / SSE idle, force reconnect`, true);
        scheduleSSEReconnect();
      } else if (Date.now() - sseState.lastKlineAt > KLINE_STALE_MS) {
        setStatus('行情源 K 线更新延迟，保留最近数据；连接仍正常', true);
      }
    }, WATCHDOG_INTERVAL_MS);
  }
  function stopWatchdog() {
    if (sseState.watchdogTimer) {
      clearInterval(sseState.watchdogTimer);
      sseState.watchdogTimer = null;
    }
  }

  // SSE 自动重连：使用退避避免请求风暴
  function scheduleSSEReconnect() {
    if (sseState.reconnectTimer) return;
    stopSSE(true);
    const delay = Math.min(sseState.backoffMs, 30_000) + Math.random() * 500;
    sseState.reconnectTimer = setTimeout(() => {
      sseState.reconnectTimer = null;
      sseState.backoffMs = Math.min(sseState.backoffMs * 2, 30_000);
      startSSE(true);
    }, delay);
  }

  // 用户主动 restart（切换 symbol/market/interval / 点刷新）
  function restartSSE() {
    dataGeneration += 1;
    if (!sseState.supported) return;
    stopSSE();
    sseState.backoffMs = 1000;
    startSSE();
  }

  // ---- 主轮询循环 (Main poll cycle) ----
  let inFlight = false;
  let pollPending = false;
  async function poll() {
    if (inFlight) {
      pollPending = true;
      return;
    }
    inFlight = true;
    pollPending = false;
    const symbol = els.symbol.value.trim().toUpperCase() || 'BTCUSDT';
    const market = els.market.value;
    const interval = els.interval.value;
    const generation = dataGeneration;
    // 仅在 SSE 还没接管的"首屏 / 降级"模式下显示 fetching 提示，
    // 避免在实时模式下每 10s 把"实时 / Live"覆盖成"请求数据中"。
    if (!sseOwnsMainChart()) {
    setStatus('请求数据中… / Fetching…');
    }
    const startedAt = Date.now();
    try {
      // 用 fetchJsonSoft，单一端点失败不会拖垮整个面板
      // (Use soft fetch so a single failed endpoint doesn't blank the dashboard.)
      // 订单簿深度档位随 interval 自适应（短周期看细盘 / 长周期看深盘）
      // (Order-book depth scales with interval so longer timeframes show
      //  more levels and shorter ones zoom in on the touch.)
      const obDepth = obDepthForInterval(interval);
      const requestedUrls = [];
      const request = url => { requestedUrls.push(url); return fetchJsonSoft(url); };
      // 主图归 SSE 管：一旦 SSE 成功过一次，就不再拉订单簿（避免 10s 跳动 + 节省请求）
      // (Once SSE has succeeded at least once, the main chart and order book
      //  are owned by SSE; poll skips fetching them entirely.)
      const sseOwns = sseOwnsMainChart();
      const obFetch = sseOwns
        ? Promise.resolve(null)
        : request(`/api/orderbook/indicators?symbol=${symbol}&depth=${obDepth}&market=${market}&interval=${interval}`);
      // OI 仅合约支持；现货时直接传 spot，后端会回 supported:false，前端清空
      const oiFetch = request(
        `/api/openInterest?symbol=${symbol}&market=${market}&interval=${interval}&limit=${SUBCHART_LIMIT}${oiAggregateParam()}`
      );
      // CVD 合并模式：仅合约 + 开关打开时拉多合约 delta；否则前端用主图 K 线派生
      const cvdFetch = (market === 'futures' && _cvdAggregate)
        ? request(`/api/cvd?symbol=${symbol}&market=${market}&interval=${interval}&limit=${SUBCHART_LIMIT}&aggregate=binance`)
        : Promise.resolve(null);
      // 🧲 清算磁极 / 共振信号已改由后端 signalPoller 定时轮询（飞书 + autoTrade），
      // 前端不再拉取信号接口 → 每轮 poll 少 1-2 个重计算请求。
      const [kData, obData, oiData, cvdData] = await Promise.all([
        sseOwns ? Promise.resolve(null) : request(`/api/klines?symbol=${symbol}&interval=${interval}&limit=${KLINE_LIMIT}&market=${market}&detectPatterns=false&notify=false`),
        obFetch,
        oiFetch,
        cvdFetch
      ]);

      // 防御并发竞争：如果等待过程中参数发生了改变（例如用户切换了 symbol），则丢弃当前请求结果，避免串图
      const currentSymbol = els.symbol.value.trim().toUpperCase() || 'BTCUSDT';
      const currentMarket = els.market.value;
      const currentInterval = els.interval.value;
      if (generation !== dataGeneration || symbol !== currentSymbol || market !== currentMarket || interval !== currentInterval) {
        return;
      }

      const failed = [];
      if (kData) {
        // FVG / 流动性空白已全部由前端在 renderMain 里对合并后的
        // 全量 K 线动态识别，poll 不再需要搬运后端 patterns。
        if (!sseOwnsMainChart()) {
          // 启动后首屏：SSE 还没成功过，poll 负责一次性把主图 seed 出来
          renderMain(kData);
        }
      } else if (!sseOwns && !sseOwnsMainChart()) failed.push('klines');

      if (!sseOwnsMainChart()) {
        if (obData) renderOrderBook(obData);
        else failed.push('orderbook');
      }
      // OI：拿到响应就用最新 lastCandles 对齐渲染；失败不阻塞，标 partial
      if (oiData) renderOpenInterest(oiData, lastCandles);
      else failed.push('openInterest');
      // CVD 合并模式：更新多合约 delta 缓存并重绘（失败保留旧缓存，不空白）
      if (_cvdAggregate) {
        if (cvdData && cvdData.supported && Array.isArray(cvdData.data)) {
          _lastCvdMerged = cvdData.data;
        } else if (cvdData === null && market === 'futures') {
          failed.push('cvd');
        }
        refreshCvdDisplay(lastCandles);
      }
      fitCharts();
      // 任何 series setData/update + chart.resize 都可能让 lightweight-charts
      // 内部 crosshair 状态被擦掉 → hover 中虚线消失。统一在这里恢复。
      try { _restoreHoverCrosshairs(); } catch (_) { /* noop */ }

      const elapsed = Date.now() - startedAt;
      if (failed.length) {
        const firstErr = requestedUrls.map(url => fetchJsonSoft.lastErrors[url]).find(Boolean) || '';
        const detail = firstErr ? ` — ${firstErr}` : '';
        setStatus(
          `部分数据暂未更新（保留最近数据）: ${failed.join(',')} · ${nowBJTimeHMS()} (UTC+8) (${elapsed}ms)${detail}`,
          true
        );
      } else if (requestedUrls.some(url => fetchJsonSoft.cacheInfo[url]?.stale)) {
        setStatus(`部分指标使用缓存，后台更新中 · ${nowBJTimeHMS()} (UTC+8)`, true);
      } else if (isSSEDriving()) {
        // SSE 在线时刷新一次"实时 / Live"标签里的时间戳，让用户能看到面板还活着
        setSSELiveStatus();
      } else if (!sseOwns) {
        setStatus(`已更新 / Updated · ${nowBJTimeHMS()} (UTC+8) (${elapsed}ms)`);
      }
    } catch (err) {
      setStatus('错误 / Error: ' + err.message, true);
      // eslint-disable-next-line no-console
      console.error(err);
    } finally {
      inFlight = false;
      if (pollPending) {
        poll();
      }
    }
  }

  function startAutoPoll() {
    stopAutoPoll();
    pollTimer = setInterval(() => {
      if (!inFlight && !document.hidden) poll();
    }, POLL_INTERVAL_MS);
  }
  function stopAutoPoll() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  }

  /**
   * Binance USDⓈ-M Futures 不支持 1 秒 K 线（最小 1m），现货才有 1s。
   * 用户切 market / interval 时，自动调整另一项保持组合合法。
   * source 标识哪个控件是用户主动改的，从而决定回退哪一边：
   *   - 'interval'：用户刚选了 1s → 把 market 改到 spot
   *   - 'market':   用户刚改了 market → 把 interval 改回 15m
   * (Keep market+interval pair compatible; futures has no 1s klines.)
   */
  function enforceIntervalMarketCompat(source) {
    const market = els.market.value;
    const interval = els.interval.value;
    if (interval !== '1s' || market !== 'futures') return false;
    if (source === 'interval') {
      els.market.value = 'spot';
      setStatus('合约不支持 1 秒 K 线，已切换到现货 / Futures has no 1s kline, switched to Spot', true);
    } else {
      els.interval.value = '15m';
      setStatus('合约不支持 1 秒 K 线，周期已切回 15m / Futures has no 1s kline, interval reset to 15m', true);
    }
    return true;
  }

  els.refresh.addEventListener('click', () => { markChartsNeedFit(); poll(); restartSSE(); });

  // ---- 统一全屏机制 (Unified fullscreen toggle) -------------------------
  // 任何元素加上 .is-fullscreen → 占满视口；同时只允许一个元素处于全屏。
  // 触发方式：
  //   1) 点击 .fs-btn[data-fs-target="<id>"]
  //   2) ESC 退出当前全屏
  // 退出 bug 关键：lightweight-charts / Chart.js / Canvas 都缓存了上次容器尺寸，
  // 浏览器 grid 重排可能在双 rAF 后仍未完成 → 必须用 rAF×2 + setTimeout 多重
  // 兜底，强制按真实 clientWidth/Height 重新 resize，否则会"看起来没回到原位置"。
  function _resizeAllAfterFullscreen() {
    const doResize = () => {
      try { fitCharts(); } catch (_) { /* noop */ }
      try { syncSubChartsToMain(); } catch (_) { /* noop */ }
      try {
        if (typeof orderbookChart !== 'undefined' && orderbookChart && els.orderbookCanvas) {
          const p = els.orderbookCanvas.parentElement;
          if (p) {
            const w = p.clientWidth, h = p.clientHeight;
            // 显式带 w/h 强制 Chart.js 同步重设 canvas 像素缓冲区，
            // 否则其内部 throttled ResizeObserver 可能漏更新一次。
            if (w > 0 && h > 0) orderbookChart.resize(w, h);
            else orderbookChart.resize();
          } else {
            orderbookChart.resize();
          }
        }
      } catch (_) { /* noop */ }
      try { if (heatmap && typeof heatmap.resize === 'function') heatmap.resize(); } catch (_) { /* noop */ }
      try { if (typeof liqHeatmap !== 'undefined' && liqHeatmap && typeof liqHeatmap.resize === 'function') liqHeatmap.resize(); } catch (_) { /* noop */ }
    };
    // 双 rAF：等 layout 提交
    requestAnimationFrame(() => requestAnimationFrame(doResize));
    // 兜底 1：grid 重排有时比双 rAF 还慢（特别是 fixed → grid 回流）
    setTimeout(doResize, 120);
    // 兜底 2：极端情况（屏幕重绘 + 字体变化等）
    setTimeout(doResize, 350);
    // 兜底 3：Chart.js 内部 throttled ResizeObserver 默认 250ms 节流
    setTimeout(doResize, 700);
  }

  function toggleFullscreen(target, btn, force) {
    if (!target) return;
    const next = typeof force === 'boolean' ? force : !target.classList.contains('is-fullscreen');
    // 互斥：进入新全屏前，先把所有 .is-fullscreen 退出（包括 .card 与 .sub-pane）
    if (next) {
      document.querySelectorAll('.is-fullscreen').forEach((el) => {
        if (el !== target) {
          el.classList.remove('is-fullscreen');
          const b = el.querySelector(':scope > .card-header .fs-btn, :scope > .sub-pane-header .fs-btn');
          if (b) { b.textContent = '⛶'; b.classList.remove('active'); b.title = b.dataset.fsTitleNormal || '全屏 / Fullscreen'; }
        }
      });
    }
    target.classList.toggle('is-fullscreen', next);
    if (btn) {
      if (!btn.dataset.fsTitleNormal) btn.dataset.fsTitleNormal = btn.title || '全屏 / Fullscreen';
      btn.textContent = next ? '⤢' : '⛶';
      btn.classList.toggle('active', next);
      btn.title = next ? '退出全屏 / Exit fullscreen (Esc)' : btn.dataset.fsTitleNormal;
    }
    _resizeAllAfterFullscreen();
  }

  document.addEventListener('click', (e) => {
    const btn = e.target && e.target.closest && e.target.closest('.fs-btn[data-fs-target]');
    if (!btn) return;
    const target = document.getElementById(btn.dataset.fsTarget);
    if (!target) return;
    e.preventDefault();
    toggleFullscreen(target, btn);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    // 退出最近一次进入全屏的元素：sub-pane 优先于 card（pane 通常嵌在 card 里）
    const fsPane = document.querySelector('.sub-pane.is-fullscreen');
    if (fsPane) {
      const btn = fsPane.querySelector(':scope > .sub-pane-header .fs-btn');
      toggleFullscreen(fsPane, btn, false);
      return;
    }
    const fsCard = document.querySelector('.card.is-fullscreen');
    if (fsCard) {
      const btn = fsCard.querySelector(':scope > .card-header .fs-btn');
      toggleFullscreen(fsCard, btn, false);
    }
  });

  // ---- 统一最小化机制 (Unified minimize toggle) -------------------------
  // 任何元素加上 .is-minimized → 只显示 header；同时动态调整 main grid 的
  // 行高，让被释放的空间自动给主图。互斥：最小化时强制退出全屏。
  // 触发：点击 .min-btn[data-min-target="<id>"]。
  function _updateMainGridLayout() {
    const main = document.querySelector('main');
    if (!main) return;
    const mainCardMin = els.mainCard?.classList.contains('is-minimized');
    const heatmapMin  = document.getElementById('heatmap-card')?.classList.contains('is-minimized');
    const liqHmMin    = document.getElementById('liq-heatmap-card')?.classList.contains('is-minimized');
    const subCardMin  = els.subCard?.classList.contains('is-minimized');
    // 只有 row 内所有 card 都最小化，该 row 才收缩为 auto，主图自动膨胀
    const heatmapRowCollapsed = !!(heatmapMin && liqHmMin);
    const r1 = mainCardMin       ? 'auto' : 'minmax(320px, 1.6fr)';
    const r2 = heatmapRowCollapsed ? 'auto' : 'minmax(0, 1fr)';
    const r3 = subCardMin        ? 'auto' : 'minmax(220px, 1fr)';
    main.style.gridTemplateRows = `${r1} ${r2} ${r3}`;
  }

  function toggleMinimize(target, btn, force) {
    if (!target) return;
    const next = typeof force === 'boolean' ? force : !target.classList.contains('is-minimized');
    // 互斥：最小化和全屏不能同时存在
    if (next && target.classList.contains('is-fullscreen')) {
      const fsBtn = target.querySelector(':scope > .card-header .fs-btn, :scope > .sub-pane-header .fs-btn');
      toggleFullscreen(target, fsBtn, false);
    }
    target.classList.toggle('is-minimized', next);
    if (btn) {
      if (!btn.dataset.minTitleNormal) btn.dataset.minTitleNormal = btn.title || '最小化 / Minimize';
      btn.textContent = next ? '▢' : '⊟';
      btn.classList.toggle('active', next);
      btn.title = next ? '还原 / Restore' : btn.dataset.minTitleNormal;
    }
    _updateMainGridLayout();
    // 还原 / 最小化都会改变可视容器尺寸，触发 chart 重排
    _resizeAllAfterFullscreen();
  }

  document.addEventListener('click', (e) => {
    const btn = e.target && e.target.closest && e.target.closest('.min-btn[data-min-target]');
    if (!btn) return;
    const target = document.getElementById(btn.dataset.minTarget);
    if (!target) return;
    e.preventDefault();
    toggleMinimize(target, btn);
  });
  function _clearMainChart() {
    _smartUpdateSeries(candleSeries, []);
    _smartUpdateSeries(vwapSeries, []);
    _smartUpdateSeries(volumeSeries, []);
    _smartUpdateSeries(volumeMASeries, []);
    if (candleSeries) candleSeries.setMarkers([]);
  }

  els.symbol.addEventListener('change', () => {
    // 换 symbol 时也要清空 OI / CVD 合并缓存与历史 K 线缓冲，下一次 poll 才会拉新值
    _lastOiResp = null;
    _lastCvdMerged = null;
    _histReset();
    _clearMainChart();
    _smartUpdateSeries(oiSeries, []);
    _smartUpdateSeries(oiCandleSeries, []);
    // 订单簿基线只对 BTCUSDT futures 录盘；切到其他 symbol 时清空基线
    setObBaselineWindow(_obBaselineState.windowMs);
    if (heatmap) heatmap.onSymbolMarketChange();
    if (liqHeatmap) liqHeatmap.onSymbolMarketChange();
    markChartsNeedFit();
    restartSSE();
    poll();
  });
  els.market.addEventListener('change', () => {
    enforceIntervalMarketCompat('market');
    refreshSubTitles();
    // 切到现货时立刻清空 OI / CVD 合并旧数据与历史 K 线缓冲
    _lastOiResp = null;
    _lastCvdMerged = null;
    _histReset();
    _clearMainChart();
    _smartUpdateSeries(oiSeries, []);
    _smartUpdateSeries(oiCandleSeries, []);
    setObBaselineWindow(_obBaselineState.windowMs);
    if (heatmap) heatmap.onSymbolMarketChange();
    if (liqHeatmap) liqHeatmap.onSymbolMarketChange();
    
    // 如果下拉框显示，更新下拉框列表
    const dropdown = document.getElementById('symbol-dropdown');
    if (dropdown && dropdown.classList.contains('show')) {
      fetchSymbols().then(symbols => renderDropdown(symbols, els.symbol.value));
    }

    markChartsNeedFit();
    restartSSE();
    poll();
  });
  els.interval.addEventListener('change', () => {
    enforceIntervalMarketCompat('interval');
    refreshSubTitles();
    // 换周期后旧的合并 CVD delta（按旧 interval 的 openTime）失效，先清缓存；
    // 历史 K 线缓冲同理（openTime 网格完全不同）；OI 缓存也是旧周期网格，
    // 一并清掉 —— 否则 renderMain 会立刻用旧数据渲染并提前揭开 loading。
    _lastCvdMerged = null;
    _lastOiResp = null;
    _histReset();
    _clearMainChart();
    // 受周期影响的每个图表盖上 loading，各自的新数据渲染完成后揭开
    showIntervalLoading();
    markChartsNeedFit();
    restartSSE();
    poll();
  });
  // 订单簿基线选择 → 切窗口 / 关闭
  if (els.obBaseline) {
    els.obBaseline.addEventListener('change', () => {
      setObBaselineWindow(Number(els.obBaseline.value) || 0);
    });
  }
  // 页面加载时先把副图标题渲染成当前 interval，并按 dropdown 默认值初始化基线
  refreshSubTitles();
  if (els.obBaseline) {
    setObBaselineWindow(Number(els.obBaseline.value) || 0);
  }

  // ============================================================
  // 币种模糊搜索与切换 (Symbol Search & Switch)
  // ============================================================
  const dropdown = document.getElementById('symbol-dropdown');
  let cachedSymbols = null;

  async function fetchSymbols() {
    const market = els.market ? els.market.value : 'futures';
    if (cachedSymbols && cachedSymbols[market]) return cachedSymbols[market];
    
    try {
      const url = market === 'futures' 
        ? 'https://fapi.binance.com/fapi/v1/ticker/24hr' 
        : 'https://api.binance.com/api/v3/ticker/24hr';
      
      const res = await fetch(url);
      const data = await res.json();
      
      // 筛选 USDT/USDC 对并按 24h 成交额排序
      let symbols = data
        .filter(t => t.symbol.endsWith('USDT') || t.symbol.endsWith('USDC') || t.symbol === 'BTCUSD_PERP')
        .sort((a, b) => Number(b.quoteVolume) - Number(a.quoteVolume))
        .map(t => ({
          symbol: t.symbol,
          vol: (Number(t.quoteVolume) / 1000000).toFixed(1) + 'M'
        }));
        
      if (!cachedSymbols) cachedSymbols = {};
      cachedSymbols[market] = symbols;
      return symbols;
    } catch (err) {
      console.error('Failed to fetch symbols', err);
      return [];
    }
  }

  function renderDropdown(list, query) {
    if (!list || list.length === 0) {
      dropdown.classList.remove('show');
      return;
    }
    
    const q = (query || '').toUpperCase();
    const filtered = q ? list.filter(item => item.symbol.includes(q)) : list.slice(0, 100);
    
    if (filtered.length === 0) {
      dropdown.innerHTML = '<div class="dropdown-item" style="color:var(--fg-2);cursor:default;">无匹配结果</div>';
    } else {
      dropdown.innerHTML = filtered.slice(0, 50).map(item => {
        const regex = new RegExp(`(${q})`, 'gi');
        const highlighted = q ? item.symbol.replace(regex, '<span style="color:var(--accent-blue)">$1</span>') : item.symbol;
        return `<div class="dropdown-item" data-symbol="${item.symbol}">
          <span>${highlighted}</span>
          <span class="vol">Vol: ${item.vol}</span>
        </div>`;
      }).join('');
    }
    dropdown.classList.add('show');
  }

  els.symbol.addEventListener('focus', async () => {
    els.symbol.select();
    const symbols = await fetchSymbols();
    renderDropdown(symbols, els.symbol.value);
  });

  els.symbol.addEventListener('input', async (e) => {
    const symbols = await fetchSymbols();
    renderDropdown(symbols, e.target.value);
  });

  dropdown.addEventListener('mousedown', (e) => {
    // 使用 mousedown 而不是 click，因为 mousedown 发生在 input 的 blur 之前
    const item = e.target.closest('.dropdown-item');
    if (!item || !item.dataset.symbol) return;
    
    els.symbol.value = item.dataset.symbol;
    dropdown.classList.remove('show');
    // 手动触发 change 事件，触发原有的更新逻辑
    els.symbol.dispatchEvent(new Event('change'));
  });

  els.symbol.addEventListener('blur', () => {
    dropdown.classList.remove('show');
  });

  // 飞书状态栏 / 自动交易开关 / 30 天回测面板已随右侧栏移除（性能优化）。
  // 自动交易运行时开关仍可通过 REST 控制：
  //   curl -X POST http://localhost:3000/api/auto-trade/toggle
  //   curl http://localhost:3000/api/auto-trade/status

  setTimeout(() => {
    fitCharts();
    poll();
    startAutoPoll(); // 10s 轮询常开（信号 / 警报 / FVG 仍需要它）
    // 启动 SSE 实时通道：浏览器不支持时静默 fallback 到 10s 轮询
    if (sseState.supported) startSSE();
  }, 100);
})();
